from pathlib import Path
import argparse,json,numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1];assets=root/'derived_data/figure_assets'
p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,default=root/'reproduced/figures');args=p.parse_args();out=args.output_dir;out.mkdir(parents=True,exist_ok=True)
rgb=np.asarray(Image.open(assets/'landcover2024_common_rgb.png'));bounds=json.loads((assets/'map_bounds.json').read_text())['bounds_5186']
fig=plt.figure(figsize=(8.77,6.43),dpi=200,facecolor='white');ax=fig.add_axes([.005,.11,.735,.82]);ax.imshow(rgb,extent=[bounds[0],bounds[2],bounds[1],bounds[3]],interpolation='nearest');ax.set_aspect('equal');ax.set_axis_off()
x0,y0=316000,274000;ax.plot([x0,x0+5000],[y0,y0],color='#303030',lw=1.8)
for x,t in [(x0,'0'),(x0+2500,'2.5'),(x0+5000,'5 km')]:ax.text(x,y0-900,t,ha='center',va='top',fontsize=6.5)
ax.annotate('N',xy=(318000,279000),xytext=(318000,276000),ha='center',fontsize=8,arrowprops={'arrowstyle':'-|>','color':'black','lw':1.1})
leg=fig.add_axes([.742,.09,.255,.79]);leg.imshow(Image.open(assets/'Figure1b_legend.png'));leg.set_axis_off();fig.text(.5,.03,'(b)',ha='center',fontsize=22,fontweight='bold');fig.savefig(out/'Figure1b_harmonized.png',dpi=200);plt.close(fig)
right=Image.open(out/'Figure1b_harmonized.png').convert('RGB').resize((877,643),Image.Resampling.LANCZOS);result=Image.new('RGB',(1747,643),'white');result.paste(Image.open(assets/'Figure1a_context.png'),(0,0));result.paste(right,(870,0));result.save(out/'Figure1_harmonized.png')
