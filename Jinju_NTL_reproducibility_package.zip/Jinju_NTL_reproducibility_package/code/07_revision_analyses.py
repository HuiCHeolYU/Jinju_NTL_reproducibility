"""Reproduce retained v2 analyses with a locally prepared monthly NTL input.
The --seasonal-only branch summarizes supplied seasonal records without refitting.
Run from any working directory: python /path/to/package/code/07_revision_analyses.py
"""
from pathlib import Path
import argparse
import json
import os
import tempfile
# Input availability is checked before optional scientific dependencies are imported.
import sys as _sys
_preflight = argparse.ArgumentParser(add_help=False)
_preflight.add_argument('--monthly-ntl', type=Path)
_preflight.add_argument('--seasonal-only', action='store_true')
_known, _unknown = _preflight.parse_known_args()
_monthly = _known.monthly_ntl.resolve() if _known.monthly_ntl else Path(__file__).resolve().parents[1] / 'derived_data/grid_monthly_ntl_2012_2024.csv'
if '--help' not in _sys.argv and '-h' not in _sys.argv and not _known.seasonal_only and not _monthly.is_file():
    _preflight.error('Monthly NTL CSV is not distributed. No monthly test was run. See processing_notes/monthly_ntl_source_workflow.txt and pass --monthly-ntl PATH. For checks using supplied inputs only, use code/run_supplied_inputs.py.')

import numpy as np
import pandas as pd
import scipy

CODES = [111,112,121,131,141,153,154,155,161,162,163]
LABELS = dict(zip(CODES, [
    "Detached housing", "Multi-family housing", "Industrial facilities",
    "Commercial and business facilities", "Amusement and leisure facilities",
    "Railroads", "Roads", "Other transportation and communication facilities",
    "Environmental infrastructure", "Educational and administrative facilities",
    "Other public facilities"]))
PERIODS = ["2012-2019", "2019-2024"]

def save(frame, path):
    frame.to_csv(path, index=False, encoding="utf-8-sig", float_format="%.17g")

def require_unique(frame, columns):
    if frame.duplicated(columns).any():
        raise ValueError(f"Duplicate key: {columns}")

def road_models(a, b, membership, out):
    import statsmodels.api as sm
    ids = membership.index[(membership.area_type == "urban") &
                           (membership.in_regression_sample == 1)]
    sample = pd.DataFrame({"grid_id": ids, "ntl_slope": membership.loc[ids, "ntl_slope"].values})
    for c in CODES:
        sample[f"darea_{c}_m2"] = (b.loc[ids, f"area_{c}_m2"] - a.loc[ids, f"area_{c}_m2"]).values
    assert len(sample) == 340 and np.isfinite(sample.to_numpy()).all()
    save(sample, out / "urban_340_fixed_sample.csv")
    y = sample.ntl_slope
    coefficients, fits = [], []
    for model, codes in [("with_road", CODES), ("without_road", [c for c in CODES if c != 154])]:
        cols = [f"darea_{c}_m2" for c in codes]
        x = sample[cols]
        fit = sm.OLS(y, sm.add_constant(x, has_constant="add"), missing="raise").fit(
            cov_type="HC3", use_t=True)
        fits.append(dict(model=model, n=int(fit.nobs), predictor_count=len(cols),
            r2=float(fit.rsquared), adjusted_r2=float(fit.rsquared_adj),
            HC3_F=float(fit.fvalue), HC3_F_p=float(fit.f_pvalue),
            df_model=int(fit.df_model), df_resid=int(fit.df_resid), HC3_use_t=True))
        for term in fit.params.index:
            c = None if term == "const" else int(term.split("_")[1])
            ci = fit.conf_int().loc[term]
            coefficients.append(dict(model=model, code=c,
                variable_en="Constant" if c is None else LABELS[c],
                B=float(fit.params[term]),
                beta=np.nan if c is None else float(fit.params[term]*x[term].std(ddof=1)/y.std(ddof=1)),
                HC3_SE=float(fit.bse[term]), HC3_t=float(fit.tvalues[term]),
                HC3_p=float(fit.pvalues[term]), CI95_B_lower=float(ci.iloc[0]),
                CI95_B_upper=float(ci.iloc[1]), significant_05=bool(fit.pvalues[term] < .05)))
    save(pd.DataFrame(coefficients), out / "urban_road_sensitivity_coefficients.csv")
    save(pd.DataFrame(fits), out / "urban_road_sensitivity_model_fit.csv")
    return fits

def grid_cases(root, a, b, membership, out, monthly_path):
    ids=membership.index[(membership.area_type=="urban") & (membership.in_regression_sample==1)]
    candidates=membership.loc[ids,["area_type","ntl_slope"]].copy()
    candidates["commercial_change_m2"]=b.loc[ids,"area_131_m2"]-a.loc[ids,"area_131_m2"]
    candidates["commercial_expansion"]=(candidates.commercial_change_m2>0).astype(int)
    candidates["negative_full_period_slope"]=(candidates.ntl_slope<0).astype(int)
    candidates["selected_illustration"]=((candidates.commercial_expansion==1)&(candidates.negative_full_period_slope==1)).astype(int)
    assert len(candidates)==340 and candidates.commercial_expansion.sum()==201
    assert candidates.index[candidates.selected_illustration==1].tolist()==[2144]
    save(candidates.reset_index(),out/"grid2144_selection.csv")
    monthly=pd.read_csv(monthly_path)
    mm=monthly[monthly.grid_id==2144].sort_values("date")
    assert len(mm)==151 and mm.ntl_mean.notna().all()
    x=(mm.year*12+mm.month).to_numpy();y=mm.ntl_mean.to_numpy();i,j=np.triu_indices(len(mm),1)
    computed=float(np.median((y[j]-y[i])/(x[j]-x[i])))
    np.testing.assert_allclose(computed,membership.loc[2144,"ntl_slope"],rtol=1e-12,atol=1e-12)
    annual=mm.groupby("year").ntl_mean.agg(["count","mean"]).reset_index()
    annual.columns=["year","valid_months","annual_mean_ntl"];annual.insert(0,"grid_id",2144)
    save(annual,out/"grid2144_annual_ntl.csv")
    land=[]
    for c in CODES:
        v1,v2=float(a.loc[2144,f"area_{c}_m2"]),float(b.loc[2144,f"area_{c}_m2"])
        land.append(dict(grid_id=2144,code=c,variable_en=LABELS[c],area_2012_m2=v1,area_2024_m2=v2,change_m2=v2-v1,source="unchanged_regression_input"))
    save(pd.DataFrame(land),out/"grid2144_landcover_original_analysis.csv")
    save(pd.DataFrame([r for r in land if r["code"] in [131,154,121]]),out/"table11_panel_A.csv")
    tt=pd.read_csv(root/"derived_data/grid_ntl_trend_results_by_period.csv")
    tr=[dict(grid_id=2144,period="2012-2024",theilsen_slope=float(membership.loc[2144,"ntl_slope"]),trend_direction="negative",existing_declining_flag=np.nan)]
    for r in tt[tt.grid_id==2144].to_dict("records"):
        tr.append(dict(grid_id=2144,period=r["period"],theilsen_slope=r["theilsen_slope"],trend_direction="negative" if r["theilsen_slope"]<0 else "positive",existing_declining_flag=r["declining_ntl_activity"]))
    save(pd.DataFrame(tr),out/"table11_panel_B.csv")
    return dict(grid_id=2144,urban_sample_n=340,commercial_expansion_n=201,expansion_negative_slope_n=1,full_period_slope_existing=float(membership.loc[2144,"ntl_slope"]),full_period_slope_checked=computed,valid_months=151,purposive_case=True)


def trend_overlap(root, trends, out):
    seasonal_path=out/"seasonal_mk_calendar_aligned_declining_grids.csv"
    if not seasonal_path.exists():
        seasonal_path=root/"supplementary_outputs/revision/seasonal_mk_calendar_aligned_declining_grids.csv"
    seasonal=pd.read_csv(seasonal_path)
    require_unique(seasonal,["period","id"])
    rows, members = [], []
    for period in PERIODS:
        t=trends[trends.period==period].set_index("grid_id")
        s=seasonal[seasonal.period==period]
        A=set(t.index[t.declining_ntl_activity==1])
        flag=s.declining_seasonal_fdr.astype(str).str.lower().eq("true")
        B=set(s.loc[flag,"id"])
        assert B<=set(t.index) and flag.all()
        assert (s.theilsen_slope<0).all() and (s.seasonal_fdr_pvalue<.05).all()
        for area in ["all","urban","non-urban"]:
            pop=set(t.index if area=="all" else t.index[t.area_type==area])
            aa,bb=A&pop,B&pop
            rows.append(dict(period=period,area_type=area,standard_n=len(aa),seasonal_n=len(bb),
                intersection_n=len(aa&bb),union_n=len(aa|bb),
                jaccard=len(aa&bb)/len(aa|bb) if aa|bb else np.nan,
                standard_only_n=len(aa-bb),seasonal_only_n=len(bb-aa)))
        for ident in sorted(t.index):
            members.append(dict(period=period,grid_id=ident,area_type=t.loc[ident,"area_type"],
                standard_declining=int(ident in A),seasonal_declining=int(ident in B)))
    save(pd.DataFrame(rows),out / "table_S1_panel_B_overlap.csv")
    save(pd.DataFrame(members),out / "standard_seasonal_membership.csv")
    return [r for r in rows if r["area_type"]=="all"]

def expansion_overlap(a,b,membership,trends,out):
    ids=membership.index[membership.area_type=="non-urban"]
    members=membership.loc[ids,["area_type"]].copy()
    for year,lc in [(2012,a),(2024,b)]:
        members[f"nodata_{year}_m2"]=lc.loc[ids,"nodata_m2"]
    members["no_recorded_nodata_both_years"]=((members.nodata_2012_m2==0)&
                                              (members.nodata_2024_m2==0)).astype(int)
    for c,label in [(121,"industrial"),(131,"commercial")]:
        for year,lc in [(2012,a),(2024,b)]:
            members[f"{label}_{year}_m2"]=lc.loc[ids,f"area_{c}_m2"]
        members[f"{label}_delta_m2"]=members[f"{label}_2024_m2"]-members[f"{label}_2012_m2"]
        members[f"{label}_expanded"]=(members[f"{label}_delta_m2"]>0).astype(int)
    for period in PERIODS:
        t=trends[trends.period==period].set_index("grid_id")
        members["declining_"+period.replace("-","_")]=t.loc[ids,"declining_ntl_activity"]
    rows,counts=[],[]
    for cohort,pop in [("all_nonurban",members),
        ("no_recorded_nodata",members[members.no_recorded_nodata_both_years==1])]:
        for c,label in [(121,"industrial"),(131,"commercial")]:
            exp=pop[f"{label}_expanded"]==1
            n1,n0=int(exp.sum()),int((~exp).sum())
            counts.append(dict(cohort=cohort,landcover_code=c,category=LABELS[c],total_n=len(pop),
                expansion_n=n1,unchanged_n=int((pop[f"{label}_delta_m2"]==0).sum()),
                contraction_n=int((pop[f"{label}_delta_m2"]<0).sum()),nonexpansion_n=n0))
            for period in PERIODS:
                dec=pop["declining_"+period.replace("-","_")]==1
                k,j=int((exp&dec).sum()),int((~exp&dec).sum())
                rows.append(dict(cohort=cohort,category=LABELS[c],landcover_code=c,period=period,
                    total_n=len(pop),declining_n=int(dec.sum()),expansion_n=n1,
                    expansion_declining_n=k,expansion_nondeclining_n=n1-k,
                    expansion_decline_pct=100*k/n1,nonexpansion_n=n0,nonexpansion_declining_n=j,
                    nonexpansion_nondeclining_n=n0-j,nonexpansion_decline_pct=100*j/n0,
                    difference_percentage_points=100*(k/n1-j/n0),
                    descriptive_rate_ratio=(k/n1)/(j/n0) if j else np.nan,
                    overlap_share_of_declining_pct=100*k/int(dec.sum())))
    save(members.reset_index(),out / "expansion_decline_membership.csv")
    save(pd.DataFrame(rows),out / "expansion_decline_comparison.csv")
    save(pd.DataFrame(counts),out / "expansion_category_counts.csv")
    return rows

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir",type=Path,help="Optional new output directory")
    parser.add_argument("--monthly-ntl",type=Path,help="Locally prepared monthly input CSV")
    parser.add_argument("--seasonal-only",action="store_true",help="Update only seasonal overlap, preserving other stored results")
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    monthly_path=args.monthly_ntl.resolve() if args.monthly_ntl else root/"derived_data/grid_monthly_ntl_2012_2024.csv"
    if not args.seasonal_only and not monthly_path.is_file():
        parser.error("Monthly input is not distributed. See processing_notes/monthly_ntl_source_workflow.txt and pass --monthly-ntl.")
    out=args.output_dir.resolve() if args.output_dir else root/"supplementary_outputs/revision"
    out.mkdir(parents=True,exist_ok=True)
    if args.seasonal_only:
        trends=pd.read_csv(root/"derived_data/grid_ntl_trend_results_by_period.csv")
        results=json.loads((root/"supplementary_outputs/revision/revision_results.json").read_text(encoding="utf-8"))
        results["trend_overlap"]=trend_overlap(root,trends,out)
        (out/"revision_results.json").write_text(json.dumps(results,indent=2,allow_nan=False)+"\n",encoding="utf-8")
        print("Completed seasonal overlap only: "+str(out))
        return
    import statsmodels
    inp=root/"derived_data/revision_inputs"
    tables=[]
    for name in ["grid_landcover_2012.csv","grid_landcover_2024.csv","regression_sample_membership.csv"]:
        t=pd.read_csv(inp/name);require_unique(t,["grid_id"])
        tables.append(t.set_index("grid_id").sort_index())
    a,b,membership=tables
    assert a.index.equals(b.index) and a.index.equals(membership.index) and len(a)==3052
    assert a.area_type.equals(b.area_type) and a.area_type.equals(membership.area_type)
    assert membership.groupby("area_type").in_regression_sample.sum().to_dict()=={"urban":340,"non-urban":2082}
    assert np.isfinite(a.drop(columns="area_type").to_numpy()).all()
    assert np.isfinite(b.drop(columns="area_type").to_numpy()).all()
    trends=pd.read_csv(root/"derived_data/grid_ntl_trend_results_by_period.csv")
    require_unique(trends,["grid_id","period"])
    for period in PERIODS:
        t=trends[trends.period==period].set_index("grid_id").sort_index()
        assert t.index.equals(membership.index) and t.area_type.equals(membership.area_type)
        flag=((t.theilsen_slope<0)&(t.fdr_pvalue<.05)).astype(int)
        assert np.array_equal(flag,t.declining_ntl_activity)
    results=dict(road_models=road_models(a,b,membership,out),
        grid_cases=grid_cases(root,a,b,membership,out,monthly_path),
        trend_overlap=trend_overlap(root,trends,out),
        expansion_overlap=expansion_overlap(a,b,membership,trends,out),
        software=dict(numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,
                      statsmodels=statsmodels.__version__))
    (out/"revision_results.json").write_text(json.dumps(results,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    print(f"Completed four revision analyses. Results: {out}")

if __name__=="__main__":
    main()
