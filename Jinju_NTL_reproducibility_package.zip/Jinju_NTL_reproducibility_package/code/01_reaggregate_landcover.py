from pathlib import Path
from zipfile import ZipFile
import sys,os,json,csv,io,time,hashlib
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
import argparse
parser=argparse.ArgumentParser(description='Reaggregate both adopted TIFFs on identical within-city valid pixels.')
parser.add_argument('--raster-2012',type=Path,required=True);parser.add_argument('--raster-2024',type=Path,required=True)
parser.add_argument('--output-dir',type=Path,default=ROOT/'reproduced/landcover')
args=parser.parse_args();OUT=args.output_dir.resolve();OUT.mkdir(parents=True,exist_ok=True)
os.environ['GDAL_DRIVER_PATH']='disable'
import numpy as np,pandas as pd,rasterio
rio=Path(rasterio.__file__).parent
for k,s in [('GDAL_DATA','gdal_data'),('PROJ_LIB','proj_data'),('PROJ_DATA','proj_data')]:
 if (rio/s).is_dir():os.environ[k]=str(rio/s)
from rasterio.features import rasterize,geometry_mask
from rasterio.windows import Window
from shapely.geometry import box,shape,mapping
from shapely.ops import unary_union,transform
from pyproj import Transformer
paths=[args.raster_2012.resolve(),args.raster_2024.resolve()]
admin=ROOT/'derived_data/spatial_inputs/jinju_admin_20230701.geojson'
ad=json.loads(admin.read_text(encoding='utf-8-sig'))
tr=Transformer.from_crs(4326,5186,always_xy=True).transform
city=unary_union([transform(tr,shape(f['geometry'])) for f in ad['features']]);assert city.is_valid
project=Transformer.from_crs(32652,5186,always_xy=True).transform
coords=pd.read_csv(ROOT/'derived_data/revision_inputs/grid_coordinates.csv').set_index('grid_id').sort_index()
assert len(coords)==3052 and coords.index.is_unique
polys=[transform(project,box(r.left,r.bottom,r.right,r.top)) for _,r in coords.iterrows()]
bounds=np.array([p.bounds for p in polys]);gm=[mapping(p) for p in polys]
rawreg=(ROOT/'derived_data/revision_inputs/regression_sample_membership.csv').read_bytes();reg=pd.read_csv(io.BytesIO(rawreg)).set_index('grid_id').loc[coords.index]
(OUT/'regression_sample_membership.csv').write_bytes(rawreg)
coords[['area_type','left','right','top','bottom']].to_csv(OUT/'grid_coordinates.csv',index_label='grid_id',encoding='utf-8-sig')
(OUT/'jinju_admin_20230701.geojson').write_bytes(admin.read_bytes())
(OUT/'analysis_grids_5186.geojson').write_text(json.dumps({'type':'FeatureCollection','name':'Reconstructed analysis grids EPSG32652 corners to EPSG5186','crs':{'type':'name','properties':{'name':'EPSG:5186'}},'features':[{'type':'Feature','properties':{'grid_id':int(gid),'area_type':coords.loc[gid,'area_type']},'geometry':gm[i]} for i,gid in enumerate(coords.index)]},ensure_ascii=False),encoding='utf-8')
codes=np.array([111,112,121,131,141,153,154,155,161,162,163,211,212,221,222,231,241,251,252,311,321,331,411,421,422,423,511,612,613,621,622,623,711,712]);C=len(codes);lut=np.zeros(1000,dtype=np.int16)-1;lut[codes]=np.arange(C)
hist=np.zeros((2,len(coords),C),dtype=np.int64);globalhist=np.zeros((2,C),dtype=np.int64)
coverage=np.zeros(len(coords),dtype=np.int64);state=np.zeros(4,dtype=np.int64)
start=time.time()
with rasterio.Env(GDAL_CACHEMAX=128*1024*1024),rasterio.open(paths[0]) as a,rasterio.open(paths[1]) as b:
 assert a.shape==b.shape and a.transform==b.transform and a.nodata==b.nodata==0 and a.crs==b.crs
 assert a.crs.to_epsg()==5186 and a.transform.a==1 and a.transform.e==-1
 meta={'shape':list(a.shape),'transform':list(a.transform),'crs':str(a.crs),'nodata':a.nodata}
 last=-1
 for row in range(0,a.height,128):
  h=min(128,a.height-row);win=Window(0,row,a.width,h);trw=a.window_transform(win)
  le,bo,ri,to=rasterio.windows.bounds(win,a.transform)
  ids=np.where((bounds[:,1]<to)&(bounds[:,3]>bo)&(bounds[:,0]<ri)&(bounds[:,2]>le))[0]
  labels=rasterize([(gm[i],int(i+1)) for i in ids],out_shape=(h,a.width),transform=trw,fill=0,dtype='uint16') if len(ids) else np.zeros((h,a.width),dtype=np.uint16)
  cm=rasterize([(mapping(city),1)],out_shape=(h,a.width),transform=trw,fill=0,dtype='uint8').astype(bool)
  ra=a.read(1,window=win);rb=b.read(1,window=win)
  av=np.isfinite(ra)&(ra!=0);bv=np.isfinite(rb)&(rb!=0)
  for k,m in enumerate([cm&av&bv,cm&av&~bv,cm&~av&bv,cm&~av&~bv]):state[k]+=int(m.sum())
  valid=cm&av&bv
  assert not np.any(valid&(labels==0)),'City support missing from grid system'
  lbs=labels[valid].astype(np.int64)-1;coverage+=np.bincount(lbs,minlength=len(coords))
  for y,ar in enumerate([ra,rb]):
   vals=ar[valid].astype(np.int16)
   assert np.equal(vals,ar[valid]).all() and (lut[vals]>=0).all()
   c=lut[vals];counts=np.bincount(lbs*C+c,minlength=len(coords)*C).reshape(len(coords),C)
   hist[y]+=counts;globalhist[y]+=np.bincount(c,minlength=C)
  pct=int((row+h)/a.height*100)//20
  if pct!=last:print('PIXEL_AGGREGATION',pct*20,'seconds',round(time.time()-start,1),flush=True);last=pct
 np.savez_compressed(OUT/'common_counts_checkpoint.npz',hist=hist,globalhist=globalhist,coverage=coverage,state=state)
 # Save exact case clips using the same geometry; all excluded positions are explicitly masked in derived clips.
 gid=2144;k=list(coords.index).index(gid);poly=polys[k]
 win=rasterio.windows.from_bounds(*poly.bounds,transform=a.transform).round_offsets().round_lengths()
 win=Window(int(np.floor((poly.bounds[0]-a.transform.c))),int(np.floor((a.transform.f-poly.bounds[3]))),int(np.ceil(poly.bounds[2]-a.transform.c))-int(np.floor(poly.bounds[0]-a.transform.c)),int(np.ceil(a.transform.f-poly.bounds[1]))-int(np.floor(a.transform.f-poly.bounds[3])) )
 gmask=geometry_mask([mapping(poly)],out_shape=(int(win.height),int(win.width)),transform=a.window_transform(win),invert=True)
 citycase=geometry_mask([mapping(city)],out_shape=gmask.shape,transform=a.window_transform(win),invert=True)
 aa=a.read(1,window=win);bb=b.read(1,window=win);validcase=gmask&citycase&(aa!=0)&(bb!=0)
 for y,ar in zip([2012,2024],[aa,bb]):
  data=np.where(validcase,ar,0).astype(np.uint16)
  with rasterio.open(OUT/f'grid2144_landcover_{y}.tif','w',driver='GTiff',height=data.shape[0],width=data.shape[1],count=1,dtype='uint16',crs=a.crs,transform=a.window_transform(win),nodata=0,compress='deflate') as dst:dst.write(data,1)
  assert np.array_equal(np.bincount(data[validcase],minlength=1000)[codes],hist[int(y==2024),k])
 for year,ar in [(2012,aa),(2024,bb)]:
  pass
 case={'grid_id':2144,'crs':'EPSG:5186','mask_pixels':int(validcase.sum()),'boundary_5186':mapping(poly),'common_support_applied':True,'area_2012':{str(c):int(v) for c,v in zip(codes,hist[0,k])},'area_2024':{str(c):int(v) for c,v in zip(codes,hist[1,k])}}
 torwgs=Transformer.from_crs(5186,4326,always_xy=True).transform
 case['boundary_wgs84']=mapping(transform(torwgs,poly));case['center_wgs84']=list(torwgs(poly.centroid.x,poly.centroid.y))
 (OUT/'grid2144_metadata.json').write_text(json.dumps(case,ensure_ascii=False,indent=2),encoding='utf-8')
for y,year in enumerate([2012,2024]):
 d=pd.DataFrame(hist[y],index=coords.index,columns=[f'area_{c}_m2' for c in codes]);d.insert(0,'area_type',coords.area_type);d.insert(1,'common_valid_m2',coverage)
 d.to_csv(OUT/f'grid_landcover_{year}.csv',index_label='grid_id',encoding='utf-8-sig')
 assert np.array_equal(hist[y].sum(axis=0),globalhist[y])
 assert np.array_equal(hist[y].sum(axis=1),coverage)
np.savez_compressed(OUT/'common_pixel_class_counts.npz',codes=codes,grid_ids=coords.index.to_numpy(),hist=hist,common_valid_m2=coverage)
sourceinfo=[]
for p in paths:
 print('HASHING',p.name,flush=True)
 with p.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 sourceinfo.append({'filename':p.name,'path':str(p),'bytes':p.stat().st_size,'sha256':sha,'mtime_ns':p.stat().st_mtime_ns})
expected=json.loads((ROOT/'processing_notes/source_manifest.json').read_text(encoding='utf-8'))['raster_inputs']
assert [s['sha256'] for s in sourceinfo]==[s['sha256'] for s in expected], 'Raster input hashes do not match adopted files'
summary={'created':'2026-11-11','analysis_dataset':'common_pixel_reanalysis_20261111_v7','sources':sourceinfo,'admin_reference':{'path':str(admin),'sha256':hashlib.sha256(admin.read_bytes()).hexdigest(),'date':'20230701'},'raster_metadata':meta,'common_valid_within_city_m2':int(state[0]),'inside_city_2012_only_m2':int(state[1]),'inside_city_2024_only_m2':int(state[2]),'inside_city_both_invalid_m2':int(state[3]),'grids':len(coords),'regression_grids':int(reg.in_regression_sample.sum()),'grids_with_zero_common_support':int((coverage==0).sum()),'regression_grids_with_zero_common_support':int(((coverage==0)&(reg.in_regression_sample.to_numpy()==1)).sum()),'rule':'Pixel-center inclusion in both reconstructed 500m grid and union of 2023 Jinju administrative polygons, with finite nonzero land-cover codes in both TIFFs. Same support used in both years. Grid cells retained.','grid_geometry':'Archived corner coordinates adopted as EPSG:32652; transformed to EPSG:5186. Diagnostic validation of 2024 original total areas against 2023 within-city geometry has RMSE 3.064 m2 per grid. Original grid PRJ not recovered.','seconds':time.time()-start,'all_class_grid_and_city_totals_match':True,'case_clip_and_grid_totals_match':True}
(OUT/'pixel_aggregation_provenance.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print('FINAL',json.dumps(summary,ensure_ascii=False),flush=True)
