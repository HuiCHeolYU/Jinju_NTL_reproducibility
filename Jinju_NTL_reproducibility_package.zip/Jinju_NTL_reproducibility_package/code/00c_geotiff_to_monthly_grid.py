"""Aggregate valid native raster pixels to supplied grid polygons and monthly CSVs.

Requires the analyst's grid GeoJSON and explicit CRS/pixel-membership rule.
No historical polygon boundaries or projection are guessed from centroid CSVs.
Outputs are written to a new directory; distributed results are never replaced.
"""
import argparse
import csv
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raster-dir',type=Path,required=True)
    p.add_argument('--grid-geojson',type=Path,required=True)
    p.add_argument('--grid-crs',required=True)
    p.add_argument('--grid-id-field',default='grid_id')
    p.add_argument('--grid-reference',type=Path,default=Path(__file__).resolve().parents[1]/'derived_data/jinju_500m_grid.csv',
                   help='CSV of expected grid_id values; defaults to the packaged study grid inventory')
    p.add_argument('--pixel-rule',choices=['center','all-touched'],required=True)
    p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--expected-grid-count',type=int,default=3052)
    p.add_argument('--start',default='2012-01')
    p.add_argument('--end',default='2024-12')
    a=p.parse_args()
    import numpy as np
    # Use the wheel runtime, not unrelated desktop GIS plugins or data files.
    os.environ['GDAL_DRIVER_PATH']='disable'
    for key in ['GDAL_DATA','PROJ_LIB','PROJ_DATA']:
        os.environ.pop(key,None)
    import rasterio
    rio=Path(rasterio.__file__).resolve().parent
    for key,sub in [('GDAL_DATA','gdal_data'),('PROJ_LIB','proj_data'),('PROJ_DATA','proj_data')]:
        if (rio/sub).is_dir():os.environ[key]=str(rio/sub)
    from rasterio.features import geometry_mask,geometry_window
    from rasterio.errors import WindowError
    from pyproj import Transformer
    from shapely.geometry import shape,mapping
    from shapely.ops import transform
    source_bytes=a.grid_geojson.read_bytes()
    fc=json.loads(source_bytes.decode('utf-8-sig'))
    if fc.get('type')!='FeatureCollection':raise ValueError('A grid FeatureCollection is required.')
    tr=Transformer.from_crs(a.grid_crs,'EPSG:4326',always_xy=True)
    grids=[];ids=set()
    for feature in fc['features']:
        gid=str(feature['properties'][a.grid_id_field]);geom=shape(feature['geometry'])
        if gid in ids or geom.is_empty or not geom.is_valid or geom.geom_type not in ['Polygon','MultiPolygon']:
            raise ValueError('Grid IDs must be unique and geometries must be valid polygons.')
        ids.add(gid);grids.append((gid,geom.bounds,mapping(transform(tr.transform,geom))))
    if len(grids)!=a.expected_grid_count:raise ValueError('Unexpected grid count.')
    reference_bytes=a.grid_reference.read_bytes()
    with a.grid_reference.open(encoding='utf-8-sig',newline='') as f:
        reference_ids=[row['grid_id'] for row in csv.DictReader(f)]
    if len(reference_ids)!=len(set(reference_ids)) or ids!=set(reference_ids):
        raise ValueError('Grid IDs do not match the reference inventory. Retain the original study identifiers.')
    files=sorted(a.raster_dir.glob('*_CleanNTL.tif'))
    if not files:raise FileNotFoundError('No prepared monthly GeoTIFFs found.')
    months=[]
    for file in files:
        m=re.fullmatch(r'(\d{4})(\d{2})_CleanNTL\.tif',file.name)
        if not m or not 1<=int(m.group(2))<=12:raise ValueError('Unexpected monthly raster name.')
        months.append((int(m.group(1)),int(m.group(2))))
    if len(set(months))!=len(months):raise ValueError('Duplicate months.')
    excluded={'2012-06','2015-06','2020-07','2020-09','2022-08'}
    current=datetime.strptime(a.start,'%Y-%m');end=datetime.strptime(a.end,'%Y-%m')
    if current>end:raise ValueError('start must not follow end')
    expected=[]
    while current<=end:
        if current.strftime('%Y-%m') not in excluded:expected.append((current.year,current.month))
        current=current.replace(year=current.year+1,month=1) if current.month==12 else current.replace(month=current.month+1)
    if months!=expected:raise ValueError('Raster months do not match the requested period and documented exclusions.')
    out=a.output_dir.resolve()
    if out.exists() and any(out.iterdir()):raise FileExistsError('Choose a new or empty output directory.')
    out.mkdir(parents=True,exist_ok=True)
    monthly_dir=out/'monthly_csv';monthly_dir.mkdir()
    combined=[];diagnostics=[]
    for file,(year,month) in zip(files,months):
        legacy=[];valid_counts=[]
        with rasterio.open(file) as ds:
            if ds.crs!=rasterio.crs.CRS.from_epsg(4326):raise ValueError('Prepared raster must use EPSG:4326.')
            for gid,bounds,geo in grids:
                gx0,gy0,gx1,gy1=shape(geo).bounds
                b=ds.bounds;eps=1e-9
                if gx0<b.left-eps or gy0<b.bottom-eps or gx1>b.right+eps or gy1>b.top+eps:
                    raise ValueError('A grid is not fully covered by the prepared raster. Expand its extent: '+gid)
                try:
                    window=geometry_window(ds,[geo],boundless=False)
                    values=ds.read(1,window=window,masked=True)
                    inside=geometry_mask([geo],out_shape=values.shape,transform=ds.window_transform(window),
                                         invert=True,all_touched=(a.pixel_rule=='all-touched'))
                    selected=inside & ~np.ma.getmaskarray(values) & np.isfinite(values.data)
                    n=int(selected.sum());mean=float(values.data[selected].mean(dtype='float64')) if n else ''
                except WindowError as exc:
                    raise ValueError('A grid lies outside the prepared raster. Expand the processing extent: '+gid) from exc
                combined.append({'grid_id':gid,'year':year,'month':month,'date':f'{year:04d}-{month:02d}','ntl_mean':mean})
                left,bottom,right,top=bounds
                legacy.append({'id':gid,'left':left,'top':top,'right':right,'bottom':bottom,'_mean':mean})
                valid_counts.append(n)
        with (monthly_dir/f'{year:04d}{month:02d}.csv').open('w',newline='',encoding='utf-8-sig') as f:
            writer=csv.DictWriter(f,fieldnames=['id','left','top','right','bottom','_mean']);writer.writeheader();writer.writerows(legacy)
        diagnostics.append({'year':year,'month':month,'grids_without_valid_pixels':sum(n==0 for n in valid_counts),
                            'source_raster':file.name,'source_sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
        print(f'{year:04d}-{month:02d}: {len(grids)} grids')
    target=out/f'grid_monthly_ntl_{a.start[:4]}_{a.end[:4]}.csv'
    with target.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=['grid_id','year','month','date','ntl_mean']);writer.writeheader();writer.writerows(combined)
    manifest={'grid_geojson_sha256':hashlib.sha256(source_bytes).hexdigest(),'grid_crs':a.grid_crs,
              'grid_reference_sha256':hashlib.sha256(reference_bytes).hexdigest(),'grid_ids_match_reference':True,
              'pixel_rule':a.pixel_rule,'grid_count':len(grids),'month_count':len(files),'rows':len(combined),
              'missing_grid_values':'blank; not converted to zero at this stage','months':diagnostics,
              'reported_results_reproduced':False}
    (out/'monthly_grid_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(target)


if __name__=='__main__':main()
