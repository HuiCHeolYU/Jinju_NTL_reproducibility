# 폴더 안의 모든 YYYYMM.csv를 읽어 연도별(_mean 연평균) CSV를 각각 생성
# - 입력: 월별 CSV 폴더 선택
# - 출력: 저장 폴더 선택 후, 연도별로 mean_YYYY 컬럼을 가진 CSV 파일 생성
#   예) 2012_mean_ntl.csv, 2013_mean_ntl.csv, ... 2024_mean_ntl.csv

import os, re, glob
import pandas as pd
from tkinter import Tk, filedialog

REQUIRED_COLS = {"id", "left", "top", "right", "bottom", "_mean"}

def pick_input_folder():
    root = Tk(); root.withdraw()
    folder = filedialog.askdirectory(title="월별 CSV 파일들이 있는 폴더를 선택하세요")
    root.destroy()
    if not folder:
        raise RuntimeError("입력 폴더를 선택하지 않았습니다.")
    return folder

def pick_output_folder():
    root = Tk(); root.withdraw()
    folder = filedialog.askdirectory(title="연도별 평균 CSV를 저장할 폴더를 선택하세요")
    root.destroy()
    if not folder:
        raise RuntimeError("저장 폴더를 선택하지 않았습니다.")
    return folder

def parse_year(path):
    m = re.search(r"(\d{6})", os.path.basename(path))
    return int(m.group(1)[:4]) if m else None

def main():
    print("1️⃣ 월별 CSV 폴더를 선택하세요.")
    in_dir = pick_input_folder()
    print("2️⃣ 결과 저장 폴더를 선택하세요.")
    out_dir = pick_output_folder()

    files = sorted(glob.glob(os.path.join(in_dir, "*.csv")))
    if not files:
        raise FileNotFoundError("선택한 폴더에서 CSV 파일을 찾지 못했습니다.")

    # 연도별로 파일 묶기
    buckets = {}
    skipped = 0
    for fp in files:
        yr = parse_year(fp)
        if yr is None:
            print(f"[건너뜀] 연월(YYYYMM) 패턴 없는 파일: {os.path.basename(fp)}")
            skipped += 1
            continue
        buckets.setdefault(yr, []).append(fp)

    if not buckets:
        raise RuntimeError("YYYYMM 패턴을 가진 파일이 없습니다.")

    print(f"[탐지된 연도] {sorted(buckets.keys())}")

    # 연도별 처리
    for yr, fps in sorted(buckets.items()):
        dfs = []
        for fp in fps:
            df = pd.read_csv(fp, encoding="utf-8-sig")
            if not REQUIRED_COLS.issubset(df.columns):
                miss = REQUIRED_COLS - set(df.columns)
                raise ValueError(f"{os.path.basename(fp)}에 필요한 열 누락: {miss}")
            df["_mean"] = df["_mean"].astype(float).fillna(0.0)
            dfs.append(df)

        year_df = pd.concat(dfs, ignore_index=True)

        # id별 연평균
        mean_df = (
            year_df
            .groupby(["id", "left", "top", "right", "bottom"], as_index=False)["_mean"]
            .mean()
            .rename(columns={"_mean": f"mean_{yr}"})
        )

        out_path = os.path.join(out_dir, f"{yr}_mean_ntl.csv")
        mean_df.to_csv(out_path, index=False, encoding="utf-8-sig")
        print(f"✅ {yr} 저장 완료: {out_path} (격자 수={len(mean_df)}, 원본 파일={len(fps)}개)")

    if skipped:
        print(f"\n[알림] 연월 패턴 없는 파일 {skipped}개는 건너뜀.")

    print("\n🎉 모든 연도 처리 완료!")

if __name__ == "__main__":
    main()
