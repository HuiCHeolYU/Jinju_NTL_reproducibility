# -*- coding: utf-8 -*-
"""
Seasonal Mann-Kendall robustness check for monthly NTL grid data

Input:
- Monthly CSV files named in YYYYMM format, e.g., 201201.csv, 201202.csv, ..., 202412.csv
- Required columns: id, left, top, right, bottom, _mean

Output:
1) seasonal_mk_all_grids_by_period.csv
2) seasonal_mk_declining_grids_by_period.csv
3) seasonal_mk_summary_by_period.csv

Main criterion for robustness check:
- Theil-Sen slope < 0
- Seasonal Mann-Kendall FDR-adjusted p-value < 0.05
"""

import os
import re
import glob
import numpy as np
import pandas as pd
from scipy.stats import theilslopes
from tkinter import Tk, filedialog, messagebox

try:
    import pymannkendall as mk
except Exception as e:
    raise RuntimeError(
        "pymannkendall가 필요합니다. 먼저 'pip install pymannkendall' 실행 후 다시 시도하세요."
    ) from e


# -----------------------------
# User settings
# -----------------------------

PERIODS = {
    "2012_2019": ("2012-01-01", "2019-12-01"),
    "2019_2024": ("2019-01-01", "2024-12-01"),
}

REQUIRED_COLS = {"id", "left", "top", "right", "bottom", "_mean"}

# 기존 분석과 일관성을 맞추기 위해 NaN을 0으로 처리
# 만약 NaN을 결측으로 유지하고 싶으면 "drop"으로 변경
MISSING_VALUE_MODE = "zero"  # "zero" or "drop"


# -----------------------------
# Dialog functions
# -----------------------------

def select_folder(title):
    root = Tk()
    root.withdraw()
    folder = filedialog.askdirectory(title=title)
    root.destroy()
    if not folder:
        raise RuntimeError("폴더를 선택하지 않았습니다.")
    return folder


def save_file_dialog(default_name):
    root = Tk()
    root.withdraw()
    file_path = filedialog.asksaveasfilename(
        title=f"{default_name} 저장 경로를 선택하세요",
        defaultextension=".csv",
        initialfile=default_name,
        filetypes=[("CSV files", "*.csv")]
    )
    root.destroy()
    if not file_path:
        raise RuntimeError("저장 경로를 지정하지 않았습니다.")
    return file_path


# -----------------------------
# Core functions
# -----------------------------

def yyyymm_from_path(path):
    base = os.path.basename(path)
    m = re.search(r"(\d{6})", base)
    if not m:
        return None
    year = int(m.group(1)[:4])
    month = int(m.group(1)[4:])
    if month < 1 or month > 12:
        return None
    return year, month


def month_index(dates):
    y = dates.dt.year.to_numpy()
    m = dates.dt.month.to_numpy()
    abs_month = y * 12 + (m - 1)
    return abs_month - abs_month.min()


def theil_sen_slope(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    x2 = x[mask]
    y2 = y[mask]

    if len(y2) < 2:
        return np.nan

    if np.nanstd(y2) == 0:
        return 0.0

    slope, intercept, low_slope, high_slope = theilslopes(y2, x2)
    return float(slope)


def seasonal_mk_test(y, period=12):
    """
    Seasonal Mann-Kendall test.
    Returns p, z, tau, s, var_s, trend, h, slope, intercept.
    """

    y = np.asarray(y, dtype=float)

    if MISSING_VALUE_MODE == "drop":
        y = y[np.isfinite(y)]

    # seasonal MK는 최소 2개 이상의 season cycle이 있어야 안정적
    if len(y) < period * 2:
        return {
            "seasonal_trend": None,
            "seasonal_h": np.nan,
            "seasonal_pvalue": np.nan,
            "seasonal_z": np.nan,
            "seasonal_tau": np.nan,
            "seasonal_s": np.nan,
            "seasonal_var_s": np.nan,
            "seasonal_slope": np.nan,
            "seasonal_intercept": np.nan,
        }

    try:
        res = mk.seasonal_test(y, period=period)
        return {
            "seasonal_trend": res.trend,
            "seasonal_h": bool(res.h),
            "seasonal_pvalue": float(res.p),
            "seasonal_z": float(res.z),
            "seasonal_tau": float(res.Tau),
            "seasonal_s": float(res.s),
            "seasonal_var_s": float(res.var_s),
            "seasonal_slope": float(res.slope),
            "seasonal_intercept": float(res.intercept),
        }
    except Exception:
        return {
            "seasonal_trend": None,
            "seasonal_h": np.nan,
            "seasonal_pvalue": np.nan,
            "seasonal_z": np.nan,
            "seasonal_tau": np.nan,
            "seasonal_s": np.nan,
            "seasonal_var_s": np.nan,
            "seasonal_slope": np.nan,
            "seasonal_intercept": np.nan,
        }


def benjamini_hochberg_fdr(pvalues):
    """
    Benjamini-Hochberg FDR correction.
    NaN p-values remain NaN.
    """

    pvalues = np.asarray(pvalues, dtype=float)
    adjusted = np.full_like(pvalues, np.nan, dtype=float)

    valid_mask = np.isfinite(pvalues)
    valid_p = pvalues[valid_mask]

    m = len(valid_p)
    if m == 0:
        return adjusted

    order = np.argsort(valid_p)
    sorted_p = valid_p[order]

    ranks = np.arange(1, m + 1)
    bh_values = sorted_p * m / ranks

    # monotonicity correction
    bh_values = np.minimum.accumulate(bh_values[::-1])[::-1]
    bh_values = np.minimum(bh_values, 1.0)

    adjusted_valid = np.empty_like(bh_values)
    adjusted_valid[order] = bh_values

    adjusted[valid_mask] = adjusted_valid
    return adjusted


def load_monthly_csvs(data_dir):
    files = sorted(glob.glob(os.path.join(data_dir, "*.csv")))
    if not files:
        raise FileNotFoundError(f"CSV 파일을 찾지 못했습니다: {data_dir}")

    frames = []
    skipped = []

    for fp in files:
        ym = yyyymm_from_path(fp)
        if ym is None:
            skipped.append(os.path.basename(fp))
            continue

        year, month = ym
        df = pd.read_csv(fp, encoding="utf-8-sig")

        missing = REQUIRED_COLS - set(df.columns)
        if missing:
            raise ValueError(f"{os.path.basename(fp)}에 필요한 컬럼이 없습니다: {missing}")

        df = df[["id", "left", "top", "right", "bottom", "_mean"]].copy()

        if MISSING_VALUE_MODE == "zero":
            df["_mean"] = pd.to_numeric(df["_mean"], errors="coerce").fillna(0.0)
        else:
            df["_mean"] = pd.to_numeric(df["_mean"], errors="coerce")

        df["year"] = year
        df["month"] = month
        df["date"] = pd.to_datetime(f"{year}-{month:02d}-01")

        frames.append(df)

    if not frames:
        raise RuntimeError("YYYYMM 패턴의 CSV가 없습니다.")

    all_df = pd.concat(frames, ignore_index=True)
    all_df = all_df.sort_values(["id", "date"])

    print(f"[읽은 CSV 수] {len(frames)}")
    print(f"[건너뛴 파일 수] {len(skipped)}")
    print(f"[전체 행 수] {len(all_df)}")
    print(f"[격자 수] {all_df['id'].nunique()}")
    print(f"[기간] {all_df['date'].min().date()} ~ {all_df['date'].max().date()}")

    if skipped:
        print("[건너뛴 파일 목록]")
        for s in skipped[:20]:
            print(f" - {s}")

    return all_df


def analyze_period(all_df, period_name, start_date, end_date):
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)

    period_df = all_df[
        (all_df["date"] >= start_date) &
        (all_df["date"] <= end_date)
    ].copy()

    if period_df.empty:
        raise RuntimeError(f"{period_name} 기간에 해당하는 데이터가 없습니다.")

    out_rows = []

    for gid, g in period_df.groupby("id", sort=False):
        g = g.sort_values("date")

        x = month_index(g["date"])
        y = g["_mean"].to_numpy(dtype=float)

        slope = theil_sen_slope(x, y)
        seasonal_result = seasonal_mk_test(y, period=12)

        base = g.iloc[0][["id", "left", "top", "right", "bottom"]].to_dict()
        base["period"] = period_name
        base["start_date"] = start_date.strftime("%Y-%m")
        base["end_date"] = end_date.strftime("%Y-%m")
        base["n_months"] = len(g)
        base["theilsen_slope"] = slope

        base.update(seasonal_result)
        out_rows.append(base)

    res = pd.DataFrame(out_rows)

    # Seasonal MK p-value에 FDR 보정 적용
    res["seasonal_fdr_pvalue"] = benjamini_hochberg_fdr(res["seasonal_pvalue"].values)

    # Robustness check 기준
    res["declining_seasonal_fdr"] = (
        (res["theilsen_slope"] < 0) &
        (res["seasonal_fdr_pvalue"] < 0.05)
    )

    return res


def make_summary(result_df):
    summary = (
        result_df
        .groupby("period", as_index=False)
        .agg(
            total_grids=("id", "count"),
            declining_grids=("declining_seasonal_fdr", "sum")
        )
    )

    summary["declining_share_percent"] = (
        summary["declining_grids"] / summary["total_grids"] * 100
    ).round(2)

    return summary


# -----------------------------
# Main
# -----------------------------

def main():
    try:
        print("1️⃣ 201201.csv ~ 202412.csv가 들어 있는 월별 CSV 폴더를 선택하세요.")
        data_dir = select_folder("월별 CSV 파일들이 있는 폴더를 선택하세요")
        print(f"[입력 폴더] {data_dir}")

        all_df = load_monthly_csvs(data_dir)

        period_results = []

        for period_name, (start_date, end_date) in PERIODS.items():
            print(f"\n[분석 중] {period_name}: {start_date} ~ {end_date}")
            res = analyze_period(all_df, period_name, start_date, end_date)
            period_results.append(res)

            n_decline = int(res["declining_seasonal_fdr"].sum())
            total = len(res)
            print(f" - Seasonal MK + FDR 감소 격자: {n_decline} / {total} ({n_decline / total * 100:.2f}%)")

        final_df = pd.concat(period_results, ignore_index=True)
        summary_df = make_summary(final_df)
        declining_df = final_df[final_df["declining_seasonal_fdr"]].copy()

        print("\n[요약]")
        print(summary_df.to_string(index=False))

        print("\n2️⃣ 전체 결과 CSV 저장 경로를 선택하세요.")
        all_out = save_file_dialog("seasonal_mk_all_grids_by_period.csv")
        final_df.to_csv(all_out, index=False, encoding="utf-8-sig")

        print("\n3️⃣ Seasonal MK + FDR 감소 격자만 저장할 CSV 경로를 선택하세요.")
        declining_out = save_file_dialog("seasonal_mk_declining_grids_by_period.csv")
        declining_df.to_csv(declining_out, index=False, encoding="utf-8-sig")

        print("\n4️⃣ 요약 CSV 저장 경로를 선택하세요.")
        summary_out = save_file_dialog("seasonal_mk_summary_by_period.csv")
        summary_df.to_csv(summary_out, index=False, encoding="utf-8-sig")

        messagebox.showinfo(
            "완료",
            "Seasonal Mann-Kendall robustness check 완료\n\n"
            f"전체 결과: {os.path.basename(all_out)}\n"
            f"감소 격자: {os.path.basename(declining_out)}\n"
            f"요약표: {os.path.basename(summary_out)}"
        )

        print("\n✅ 완료")
        print(f"- 전체 결과: {all_out}")
        print(f"- 감소 격자: {declining_out}")
        print(f"- 요약표: {summary_out}")

    except Exception as e:
        messagebox.showerror("오류", str(e))
        raise


if __name__ == "__main__":
    main()