"""Download selected NASA VNP46A3 HDF5 links exported from Earthdata Search.

No collection, region, or input files are selected implicitly. Authentication
uses EARTHDATA_TOKEN or a hidden prompt. Credentials are never written to disk.
"""
import argparse
from datetime import datetime, timezone
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import urllib.parse
import urllib.request

NAME = re.compile(r'VNP46A3\.A\d{7}\.h\d{2}v\d{2}\.(001|002)\.\d{13}\.h5$')
MAGIC = b'\x89HDF\r\n\x1a\n'


def checked_url(value, collection):
    parsed = urllib.parse.urlsplit(value)
    host = (parsed.hostname or '').lower()
    if parsed.scheme != 'https' or not host.endswith('.nasa.gov'):
        raise ValueError('Use HTTPS download links hosted by NASA, exported from Earthdata Search.')
    if parsed.username or parsed.password or parsed.fragment or parsed.query:
        raise ValueError('Use direct NASA HDF5 URLs without credentials, query parameters, or fragments.')
    filename = urllib.parse.unquote(parsed.path.rsplit('/', 1)[-1])
    match = NAME.fullmatch(filename)
    if not match or match.group(1) != collection:
        raise ValueError('Unexpected product or collection: ' + filename)
    return filename


class Redirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urllib.parse.urlsplit(newurl).scheme != 'https':
            raise ValueError('Refusing a non-HTTPS download redirect')
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        if urllib.parse.urlsplit(req.full_url).netloc != urllib.parse.urlsplit(newurl).netloc:
            redirected.remove_header('Authorization')
        return redirected


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--url-list', type=Path, required=True, help='One NASA HTTPS HDF5 URL per line')
    p.add_argument('--collection', choices=['001', '002'], required=True)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--dry-run', action='store_true', help='Validate links without authentication or download')
    a = p.parse_args()
    urls = [line.strip() for line in a.url_list.read_text(encoding='utf-8-sig').splitlines()
            if line.strip() and not line.lstrip().startswith('#')]
    names = [checked_url(url, a.collection) for url in urls]
    if not names or len(set(names)) != len(names):
        raise ValueError('The list must contain unique VNP46A3 files.')
    if a.dry_run:
        print(f'Validated {len(names)} file URLs for collection {a.collection}; no download performed.')
        return
    out = a.output_dir.resolve()
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('Choose a new or empty download directory; existing files are not overwritten.')
    token = os.environ.get('EARTHDATA_TOKEN') or getpass.getpass('NASA Earthdata download token: ')
    if not token or any(c.isspace() for c in token):
        raise ValueError('A valid Earthdata download token is required.')
    out.mkdir(parents=True, exist_ok=True)
    opener = urllib.request.build_opener(Redirects())
    records = []
    for index, (url, name) in enumerate(zip(urls, names), 1):
        target = out / name
        partial = target.with_suffix('.h5.partial')
        req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + token,
                                                   'User-Agent': 'Jinju-NTL-input-preparation/1.0'})
        sha = hashlib.sha256()
        count = 0
        with opener.open(req, timeout=120) as response, partial.open('xb') as f:
            first = response.read(8)
            if first != MAGIC:
                raise ValueError('The response is not HDF5. Check Earthdata access and the selected URL.')
            f.write(first); sha.update(first); count += len(first)
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                f.write(block); sha.update(block); count += len(block)
            length = response.headers.get('Content-Length')
            if length and count != int(length):
                raise IOError('Incomplete download: ' + name)
        os.replace(partial, target)
        records.append({'filename': name, 'url': url, 'bytes': count, 'sha256': sha.hexdigest(),
                        'collection': a.collection})
        manifest = {'downloaded_at_utc': datetime.now(timezone.utc).isoformat(), 'files': records}
        (out / 'download_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
        print(f'[{index}/{len(names)}] {name}')


if __name__ == '__main__':
    main()
