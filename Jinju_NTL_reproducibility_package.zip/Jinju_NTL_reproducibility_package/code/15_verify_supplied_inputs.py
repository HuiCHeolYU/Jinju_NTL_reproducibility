"""Verify package integrity, retained results and the supplied-input rerun scope."""
from pathlib import Path
import argparse,csv,math,subprocess,sys,json
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f);return r.fieldnames,list(r)
def eq(a,b):
    if a==b:return True
    try:
        x,y=float(a),float(b)
        return math.isnan(x) and math.isnan(y) or math.isclose(x,y,rel_tol=2e-7,abs_tol=1e-10)
    except ValueError:return False
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--results',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
cmd=[sys.executable,str(root/'code/verify_package.py')]
if a.results:cmd+=['--s1-results',str(a.results),'--fdr-results',str(a.results)]
subprocess.run(cmd,check=True)
compared=[]
if a.results:
    for expected in sorted((root/'supplementary_outputs/staged_revision').glob('*.csv')):
        fields,x=rows(expected);ff,y=rows(a.results/expected.name)
        assert fields==ff and len(x)==len(y),(expected.name,'shape')
        for i,(xx,yy) in enumerate(zip(x,y),2):
            for k in fields:assert eq(xx[k],yy[k]),(expected.name,i,k,xx[k],yy[k])
        compared.append(expected.name)
    fields,x=rows(root/'supplementary_outputs/revision/jinju_parcel_size_benchmarks.csv');ff,y=rows(a.results/'jinju_parcel_size_benchmarks.csv')
    assert fields==ff and len(x)==len(y)
    assert all(eq(xx[k],yy[k]) for xx,yy in zip(x,y) for k in fields)
print(json.dumps({'supplied_input_csvs_compared':compared,'scope':'Integrity and stated derived-input checks only; no monthly MK/seasonal MK, SGIS allocation or spatial-lag estimation.'},indent=2))
