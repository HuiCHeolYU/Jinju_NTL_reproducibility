# -*- coding: utf-8 -*-
"""
여러 CSV에서 토지이용 면적 합산 (wide/long 모두 지원)
- wide형: HISTO_*** 컬럼들이 가로로 존재 → 열별 합계 후 파일 간 누적
- long형: (code, area) 형태 → 코드별 합계 후 파일 간 누적
출력: Excel(시트 2개: By_Category, By_Code) + CSV 2개
"""

import os
import sys
import re
import pandas as pd
from tkinter import Tk, filedialog, messagebox
from datetime import datetime

# 코드 → 한글 용도지역 매핑
HISTO_MAP = {
    "HISTO_111": "단독주거지역",
    "HISTO_112": "공동주거지역",
    "HISTO_121": "공업지역",
    "HISTO_131": "상업업무지역",
    "HISTO_132": "혼합지역",
    "HISTO_141": "위락시설지역",
    "HISTO_151": "공항",
    "HISTO_152": "항만",
    "HISTO_153": "철도",
    "HISTO_154": "도로",
    "HISTO_155": "기타 교통, 통신시설",
    "HISTO_161": "환경기초시설",
    "HISTO_162": "교육. 행정시설",
    "HISTO_163": "기타 공공 시설",
    "HISTO_211": "경지정리가 된 논",
    "HISTO_212": "경지정리가 안 된 논",
    "HISTO_221": "경지정리가 된 밭",
    "HISTO_222": "경지정리가 안된 밭",
    "HISTO_231": "하우스재배지",
    "HISTO_241": "과수원",
    "HISTO_251": "목장",
    "HISTO_252": "기타재배지",
    "HISTO_311": "활엽수림",
    "HISTO_321": "침엽수림",
    "HISTO_331": "혼효림",
    "HISTO_411": "자연초지",
    "HISTO_421": "골프장",
    "HISTO_422": "묘지",
    "HISTO_423": "기타초지",
    "HISTO_511": "내륙습지",
    "HISTO_521": "갯벌",
    "HISTO_522": "염전",
    "HISTO_611": "해변",
    "HISTO_612": "강기슭",
    "HISTO_613": "암벽, 바위",
    "HISTO_621": "채광지역",
    "HISTO_622": "운동장",
    "HISTO_623": "기타나지",
    "HISTO_711": "하천",
    "HISTO_712": "호소",
    "HISTO_721": "해양수",
}

# long형 후보 컬럼명
CODE_CANDIDATES = ["HISTO", "histo", "code", "class", "landcode", "land_code", "landuse_code", "코드", "분류코드"]
AREA_CANDIDATES = ["area", "면적", "area_m2", "area_ha", "AREA", "Area", "ha", "HA", "m2", "면적_m2", "AREA_M2"]

HISTO_PAT = re.compile(r"^HISTO_\d{3}$", re.IGNORECASE)

def find_col(cols, candidates):
    lower = {c.lower(): c for c in cols}
    for cand in candidates:
        if cand.lower() in lower:
            return lower[cand.lower()]
    return None

def read_csv_any(path):
    for enc in ("utf-8", "cp949"):
        try:
            return pd.read_csv(path, encoding=enc)
        except Exception:
            pass
    # 마지막 시도: 엔진 python
    return pd.read_csv(path, encoding="utf-8", engine="python", error_bad_lines=False)

def is_wide_form(df):
    # HISTO_*** 컬럼이 3개 이상 있으면 wide형으로 판단
    histo_cols = [c for c in df.columns if HISTO_PAT.match(str(c).strip())]
    return len(histo_cols) >= 3, histo_cols

def aggregate_wide(df, histo_cols):
    # 숫자화 후 NaN=0, 열별 합계 Series 반환
    numeric = df[histo_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
    return numeric.sum(axis=0)

def aggregate_long(df):
    code_col = find_col(df.columns, CODE_CANDIDATES)
    area_col = find_col(df.columns, AREA_CANDIDATES)
    if code_col is None or area_col is None:
        raise KeyError("long형 판단이 되었지만 code/area 컬럼을 찾지 못했습니다.")
    tmp = df[[code_col, area_col]].copy()
    tmp.rename(columns={code_col: "code", area_col: "area"}, inplace=True)
    tmp["code"] = tmp["code"].astype(str).str.strip()
    tmp["area"] = pd.to_numeric(tmp["area"], errors="coerce").fillna(0)
    return tmp.groupby("code")["area"].sum()

def main():
    root = Tk(); root.withdraw()
    file_paths = filedialog.askopenfilenames(
        title="면적 합산할 CSV 파일들을 선택하세요 (여러 개 선택 가능)",
        filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
    )
    if not file_paths:
        messagebox.showerror("오류", "CSV 파일이 선택되지 않았습니다."); return

    # 파일들 누적 합계 (코드별)
    total_series = pd.Series(dtype="float64")
    unmapped_codes = set()

    for fp in file_paths:
        try:
            df = read_csv_any(fp)
        except Exception as e:
            messagebox.showerror("읽기 오류", f"{os.path.basename(fp)} 읽기 실패: {e}")
            continue

        is_wide, histo_cols = is_wide_form(df)

        if is_wide:
            part = aggregate_wide(df, histo_cols)   # index: HISTO_xxx, values: area sum
            part.index = [str(i).strip().upper() for i in part.index]
        else:
            # long형으로 시도
            try:
                part = aggregate_long(df)           # index: code, values: area sum
                part.index = [str(i).strip().upper() for i in part.index]
            except Exception as e:
                # wide도 아니고 long도 아니면 안내
                messagebox.showerror(
                    "컬럼 탐지 실패",
                    f"{os.path.basename(fp)}에서 HISTO_*** 컬럼(가로형)도, code/area(세로형)도 찾지 못했습니다.\n"
                    f"wide 예: HISTO_111, HISTO_154 ...\nlong 예: code, area"
                )
                continue

        # 누적
        total_series = total_series.add(part, fill_value=0)

    if total_series.empty:
        messagebox.showerror("오류", "유효한 데이터가 없어 합계를 만들지 못했습니다.")
        return

    # By_Code 테이블
    by_code = total_series.reset_index()
    by_code.columns = ["code", "area"]
    by_code["code"] = by_code["code"].astype(str).str.strip().str.upper()
    by_code["category"] = by_code["code"].map(HISTO_MAP)
    unmapped_codes |= set(by_code.loc[by_code["category"].isna(), "code"])
    by_code["category"] = by_code["category"].fillna("기타/미분류")
    by_code = by_code.sort_values(["category", "code"]).reset_index(drop=True)

    # By_Category 테이블
    by_cat = (
        by_code.groupby("category", as_index=False)["area"]
        .sum()
        .sort_values("area", ascending=False)
    )

    # 저장
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    default_name = f"토지이용_면적합산_{ts}.xlsx"
    save_xlsx = filedialog.asksaveasfilename(
        title="엑셀(결과) 저장 위치를 선택하세요",
        defaultextension=".xlsx",
        initialfile=default_name,
        filetypes=[("Excel files", "*.xlsx")]
    )
    if not save_xlsx:
        messagebox.showerror("오류", "저장 경로가 선택되지 않았습니다."); return

    with pd.ExcelWriter(save_xlsx, engine="xlsxwriter") as writer:
        by_cat.to_excel(writer, index=False, sheet_name="By_Category")
        by_code.to_excel(writer, index=False, sheet_name="By_Code")

        # 보너스: 매핑 안 된 코드 시트
        if unmapped_codes:
            unmapped_df = pd.DataFrame(sorted(unmapped_codes), columns=["unmapped_code"])
            unmapped_df.to_excel(writer, index=False, sheet_name="Unmapped_Codes")

    # CSV도 같이
    out_dir = os.path.dirname(save_xlsx)
    by_cat.to_csv(os.path.join(out_dir, f"토지이용_면적합산_By_Category_{ts}.csv"), index=False, encoding="utf-8-sig")
    by_code.to_csv(os.path.join(out_dir, f"토지이용_면적합산_By_Code_{ts}.csv"), index=False, encoding="utf-8-sig")

    msg = "면적 합산 완료!\n\n- Excel: {}\n- CSV: 2개 동시 저장".format(os.path.basename(save_xlsx))
    if unmapped_codes:
        msg += "\n\n※ 매핑 안 된 코드가 있어 'Unmapped_Codes' 시트에 목록을 넣었습니다."
    messagebox.showinfo("완료", msg)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        messagebox.showerror("예외 발생", str(e))
        sys.exit(1)
