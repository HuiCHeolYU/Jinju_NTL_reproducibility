# -*- coding: utf-8 -*-
"""
두 시점(2012, 2024)의 CSV를 선택하면,
- id로 병합(두 파일의 id 컬럼명이 달라도 동작)
- 'significant_grids_2012~2024_slope' (야간조도 기울기; 동일하다고 가정) 컬럼 유지/통일
- 공통 HISTO_* 면적 컬럼에 대해 Δ면적(2024-2012) 계산
- 하나의 CSV로 저장
"""

import pandas as pd
import numpy as np
from tkinter import Tk, filedialog, messagebox
from typing import Optional, List

SLOPE_KEYS = [
    "significant_grids_2012~2024_slope",
    "significant_grids_2012-2024_slope",
    "NTL_slope_2012_2024",
    "slope",
    "기울기"
]

def detect_id_col(df: pd.DataFrame) -> str:
    # id 추정
    for c in df.columns:
        cl = c.lower()
        if cl in ["id", "grid_id", "gridid", "gid"] or "격자" in c:
            return c
    return df.columns[0]

def detect_slope_col(df: pd.DataFrame) -> Optional[str]:
    for key in SLOPE_KEYS:
        for c in df.columns:
            if key.lower() in c.lower():
                return c
    for c in df.columns:
        if "slope" in c.lower() or "기울기" in c:
            return c
    return None

def get_histo_cols(df: pd.DataFrame) -> List[str]:
    return [c for c in df.columns if c.startswith("HISTO_")]

def merge_and_compute(df12: pd.DataFrame, df24: pd.DataFrame) -> pd.DataFrame:
    id12 = detect_id_col(df12)
    id24 = detect_id_col(df24)

    # id 타입 불일치 방지: 문자열로 통일
    df12[id12] = df12[id12].astype(str)
    df24[id24] = df24[id24].astype(str)

    slope12 = detect_slope_col(df12)
    slope24 = detect_slope_col(df24)
    histo12 = get_histo_cols(df12)
    histo24 = get_histo_cols(df24)
    common_histo = sorted(list(set(histo12).intersection(histo24)))

    use_cols12 = list(dict.fromkeys([id12] + ([slope12] if slope12 else []) + common_histo))
    use_cols24 = list(dict.fromkeys([id24] + ([slope24] if slope24 else []) + common_histo))

    m = df12[use_cols12].merge(
        df24[use_cols24],
        left_on=id12,
        right_on=id24,
        how="inner",
        suffixes=("_2012", "_2024")
    )

    # 출력용 id 표준화
    if id12 in m.columns:
        m = m.rename(columns={id12: "id"})
    else:
        m["id"] = m[id24]
    if id24 in m.columns and id24 != "id":
        m = m.drop(columns=[id24], errors="ignore")

    # slope 통합: 2024 우선, 없으면 2012, 둘 다 없으면 NaN
    s12 = f"{slope12}_2012" if slope12 and f"{slope12}_2012" in m.columns else None
    s24 = f"{slope24}_2024" if slope24 and f"{slope24}_2024" in m.columns else None
    if s24:
        m["significant_grids_2012~2024_slope"] = m[s24]
    elif s12:
        m["significant_grids_2012~2024_slope"] = m[s12]
    else:
        m["significant_grids_2012~2024_slope"] = np.nan

    # 총면적(공통 HISTO_*만)
    if common_histo:
        m["area_total_2012"] = m[[f"{c}_2012" for c in common_histo]].sum(axis=1)
        m["area_total_2024"] = m[[f"{c}_2024" for c in common_histo]].sum(axis=1)
    else:
        m["area_total_2012"] = 0.0
        m["area_total_2024"] = 0.0

    # Δ면적 계산: HISTO_ 뒤의 코드만 추출
    for code in common_histo:
        c12 = f"{code}_2012"
        c24 = f"{code}_2024"
        tag = code[len("HISTO_"):]  # 'HISTO_' 이후 전체를 코드로 사용
        m[f"darea_{tag}_12_24"] = m[c24].astype(float) - m[c12].astype(float)

    delta_cols = [c for c in m.columns if c.startswith("darea_")]
    out_cols = ["id", "significant_grids_2012~2024_slope", "area_total_2012", "area_total_2024"] + delta_cols
    out = m[out_cols].copy()
    return out

def main():
    root = Tk()
    root.withdraw()

    p12 = filedialog.askopenfilename(title="2012 CSV 선택", filetypes=[("CSV files","*.csv")])
    if not p12:
        messagebox.showerror("오류", "2012 CSV를 선택하지 않았습니다.")
        return

    p24 = filedialog.askopenfilename(title="2024 CSV 선택", filetypes=[("CSV files","*.csv")])
    if not p24:
        messagebox.showerror("오류", "2024 CSV를 선택하지 않았습니다.")
        return

    # 인코딩 이슈가 있으면 encoding="utf-8-sig" 또는 "cp949"로 바꿔보세요.
    df12 = pd.read_csv(p12)
    df24 = pd.read_csv(p24)

    out = merge_and_compute(df12, df24)

    save_path = filedialog.asksaveasfilename(
        title="병합/변화량 CSV 저장 경로 선택",
        defaultextension=".csv",
        filetypes=[("CSV files","*.csv")],
        initialfile="merged_landuse_delta_2012_2024.csv"
    )
    if not save_path:
        messagebox.showerror("오류", "저장 경로를 선택하지 않았습니다.")
        return

    out.to_csv(save_path, index=False, encoding="utf-8-sig")
    messagebox.showinfo("완료", f"저장됨: {save_path}")

if __name__ == "__main__":
    main()
