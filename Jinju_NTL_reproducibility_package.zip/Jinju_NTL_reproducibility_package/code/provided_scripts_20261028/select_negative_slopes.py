# slope < 0 인 격자만 추출하여 새로운 CSV로 저장
# 입력 CSV 파일과 출력 경로를 모두 사용자가 직접 지정

import pandas as pd
from tkinter import Tk, filedialog

def select_input_file():
    """입력 CSV 파일 선택"""
    root = Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="분석할 CSV 파일을 선택하세요 (slope 열 포함)",
        filetypes=[("CSV files", "*.csv")],
    )
    root.destroy()
    if not file_path:
        raise RuntimeError("입력 파일을 선택하지 않았습니다.")
    return file_path

def select_output_file(default_name="slope_negative_only.csv"):
    """출력 CSV 저장 경로 선택"""
    root = Tk()
    root.withdraw()
    file_path = filedialog.asksaveasfilename(
        title="slope < 0 인 격자만 저장할 경로를 선택하세요",
        defaultextension=".csv",
        initialfile=default_name,
        filetypes=[("CSV files", "*.csv")],
    )
    root.destroy()
    if not file_path:
        raise RuntimeError("저장 경로를 지정하지 않았습니다.")
    return file_path

def main():
    print("1️⃣ 입력 CSV 파일을 선택하세요.")
    input_csv = select_input_file()
    print(f"[입력 파일] {input_csv}")

    print("2️⃣ 결과 CSV 저장 경로를 지정하세요.")
    output_csv = select_output_file()
    print(f"[저장 경로] {output_csv}")

    # CSV 불러오기
    df = pd.read_csv(input_csv)

    # slope 열 확인
    if "slope" not in df.columns:
        raise ValueError("선택한 CSV 파일에 'slope' 열이 없습니다.")

    # slope < 0 인 격자만 추출
    shrink = df[df["slope"] < 0].copy()

    # 결과 저장
    shrink.to_csv(output_csv, index=False, encoding="utf-8-sig")

    print(f"\n✅ [완료] slope < 0 인 격자 {len(shrink)}개만 저장했습니다.")
    print(f"파일 위치: {output_csv}")

if __name__ == "__main__":
    main()
