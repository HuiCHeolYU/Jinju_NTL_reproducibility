# -*- coding: utf-8 -*-
"""
VIIRS VNP46A3 전처리 (Composite, Num, QA, Std → CleanNTL)
좌표계: EPSG:4326 대신 WKT 문자열 직접 지정
"""

import numpy as np
import rasterio
from rasterio.transform import from_origin
from tkinter import Tk, filedialog

# ---------------------------
# 타일 좌표계/범위 (예: h30v05 = 120E~130E, 30N~40N)
# ---------------------------
xmin, xmax = 120.0, 130.0
ymin, ymax = 30.0, 40.0
res = 10.0 / 2400.0   # 0.0041666667 deg (≈500m)
transform = from_origin(xmin, ymax, res, res)

# EPSG:4326을 직접 쓰지 않고, 표준 WKT 문자열 지정
wgs84_wkt = (
    'GEOGCS["WGS 84",'
    'DATUM["WGS_1984",'
    'SPHEROID["WGS 84",6378137,298.257223563]],'
    'PRIMEM["Greenwich",0],'
    'UNIT["degree",0.0174532925199433]]'
)

# ---------------------------
# 파일 선택
# ---------------------------
Tk().withdraw()
free_path = filedialog.askopenfilename(title="free 파일 선택")
num_path  = filedialog.askopenfilename(title="Num 파일 선택")
qa_path   = filedialog.askopenfilename(title="QA 파일 선택")
std_path  = filedialog.askopenfilename(title="Std 파일 선택")

# ---------------------------
# 데이터 읽기
# ---------------------------
with rasterio.open(free_path) as src:
    comp = src.read(1).astype("float32")
    height, width = comp.shape

num  = rasterio.open(num_path).read(1).astype("float32")
qa   = rasterio.open(qa_path).read(1).astype("float32")
std  = rasterio.open(std_path).read(1).astype("float32")

# ---------------------------
# 전처리 규칙
# ---------------------------
radiance_min = 0.5
min_numobs   = 3
qa_keep      = (0,)
std_thr      = np.nanpercentile(std, 95)

m1 = comp >= radiance_min
m2 = np.isin(qa, qa_keep)
m3 = num >= min_numobs
m4 = std <= std_thr

valid = m1 & m2 & m3 & m4
clean_ntl = np.where(valid, comp, 0.0).astype("float32")

# ---------------------------
# 출력 저장
# ---------------------------
out_path = filedialog.asksaveasfilename(
    title="저장할 CleanNTL 파일 이름 지정",
    defaultextension=".tif",
    filetypes=[("GeoTIFF", "*.tif")],
    initialfile="2012_01_CleanNTL.tif"
)

profile = {
    "driver": "GTiff",
    "dtype": "float32",
    "nodata": 0.0,
    "width": width,
    "height": height,
    "count": 1,
    "crs": wgs84_wkt,   # EPSG 대신 WKT 문자열 지정
    "transform": transform,
    "compress": "deflate"
}

with rasterio.open(out_path, "w", **profile) as dst:
    dst.write(clean_ntl, 1)

print(f"[OK] {out_path} 저장 완료")
print(f"  CRS=WGS84(WKT), Extent=({xmin},{ymin},{xmax},{ymax}), std_p95={std_thr:.3f}")
