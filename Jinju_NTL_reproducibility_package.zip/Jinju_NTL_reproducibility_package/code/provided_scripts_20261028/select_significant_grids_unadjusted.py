# 유의한 격자만 추출 (mk_pvalue < 0.05)
# 입력 CSV 파일과 출력 CSV 경로를 직접 선택할 수 있는 버전

import pandas as pd
from tkinter import Tk, filedialog

def select_input_file():
    """입력 CSV 파일 선택"""
    root = Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="분석할 theilsen_slope_mk.csv 파일을 선택하세요",
        filetypes=[("CSV files", "*.csv")],
    )
    root.destroy()
    if not file_path:
        raise RuntimeError("입력 파일을 선택하지 않았습니다.")
    return file_path

def select_output_file(default_name="significant_grids.csv"):
    """출력 CSV 저장 경로 선택"""
    root = Tk()
    root.withdraw()
    file_path = filedialog.asksaveasfilename(
        title="유의한 격자만 저장할 경로를 선택하세요",
        defaultextension=".csv",
        initialfile=default_name,
        filetypes=[("CSV files", "*.csv")],
    )
    root.destroy()
    if not file_path:
        raise RuntimeError("저장 경로를 지정하지 않았습니다.")
    return file_path

def main():
    print("1️⃣ theilsen_slope_mk.csv 파일을 선택하세요.")
    input_csv = select_input_file()
    print(f"[입력 파일] {input_csv}")

    print("2️⃣ 유의한 격자만 저장할 경로를 지정하세요.")
    output_csv = select_output_file()
    print(f"[저장 경로] {output_csv}")

    # CSV 불러오기
    df = pd.read_csv(input_csv)

    # 필수 열 확인
    required_cols = {"id", "left", "top", "right", "bottom", "slope", "mk_pvalue"}
    if not required_cols.issubset(df.columns):
        raise ValueError(f"필수 열이 누락되었습니다: {required_cols - set(df.columns)}")

    # mk_pvalue < 0.05인 격자만 추출
    significant = df[df["mk_pvalue"] < 0.05].copy()

    # 결과 저장
    significant.to_csv(output_csv, index=False, encoding="utf-8-sig")
    print(f"\n✅ [완료] {len(significant)}개의 유의한 격자만 저장했습니다.")
    print(f"파일 위치: {output_csv}")

if __name__ == "__main__":
    main()
