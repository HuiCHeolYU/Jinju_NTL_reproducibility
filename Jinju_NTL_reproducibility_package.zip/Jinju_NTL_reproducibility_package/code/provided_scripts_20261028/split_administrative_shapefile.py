# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 18:36:34 2024

@author: 1234
"""

import geopandas as gpd
import os
from tkinter import Tk, filedialog

# 파일 선택 창 띄우기
def select_file():
    root = Tk()
    root.withdraw()  # Tkinter GUI 창 숨기기
    file_path = filedialog.askopenfilename(
        title="SHP 파일 선택",
        filetypes=[("Shapefile", "*.shp")])
    return file_path

def select_folder():
    root = Tk()
    root.withdraw()  # Tkinter GUI 창 숨기기
    folder_path = filedialog.askdirectory(
        title="출력 폴더 선택")
    return folder_path

# SHP 파일 경로 선택
input_file = select_file()
if not input_file:
    print("SHP 파일을 선택하지 않았습니다. 프로그램을 종료합니다.")
    exit()

# 출력 폴더 경로 선택
output_folder = select_folder()
if not output_folder:
    print("출력 폴더를 선택하지 않았습니다. 프로그램을 종료합니다.")
    exit()

# SHP 파일 읽기
gdf = gpd.read_file(input_file)

# 기준 필드 (행정구역 이름 필드)
field_name = "EMD_KOR_NM"

# 고유값 가져오기
unique_values = gdf[field_name].unique()

# 고유값별로 분리하고 저장
for value in unique_values:
    # 특정 값에 해당하는 데이터 필터링
    filtered_gdf = gdf[gdf[field_name] == value]
    
    # 파일 이름으로 사용할 안전한 이름 변환
    safe_value = "".join([c if c.isalnum() or c in " _-" else "_" for c in value])
    
    # 출력 파일 경로
    output_file = os.path.join(output_folder, f"{safe_value}.shp")
    
    # 파일 저장
    filtered_gdf.to_file(output_file, encoding="utf-8")
    print(f"Saved: {output_file}")

print("모든 행정구역 분리가 완료되었습니다!")
