"""Reproduce the manuscript's 17-grid centroid selection and period trends."""
from pathlib import Path
import argparse,csv,json,importlib.util,shapefile
from shapely.geometry import shape,Point
from shapely.ops import transform
from pyproj import Transformer

def run(root,out):
    spec=importlib.util.spec_from_file_location('fdr',Path(__file__).with_name('08_fdr_comparison.py'));fdr=importlib.util.module_from_spec(spec);spec.loader.exec_module(fdr)
    allresults=fdr.run(root,out)
    fc=json.loads((root/'derived_data/spatial_inputs/chungmugong_dong_2023.geojson').read_text(encoding='utf-8'))
    feature=fc['features'][0];assert feature['properties']['BASE_DATE']=='20230701'
    original=shapefile.Reader(str(root/'derived_data/spatial_inputs/chungmugong_dong_2023.shp'),encoding='utf-8').__geo_interface__['features'][0]
    assert shape(original['geometry']).equals(shape(feature['geometry']))
    assert original['properties']==feature['properties']
    tr=Transformer.from_crs(4326,32652,always_xy=True);polygon=transform(tr.transform,shape(feature['geometry']))
    grids=fdr.read(root/'derived_data/jinju_500m_grid.csv')
    selected={r['grid_id']:r for r in grids if polygon.intersects(Point(float(r['x_centroid']),float(r['y_centroid'])))}
    assert len(selected)==17 and all(r['area_type']=='urban' for r in selected.values())
    details=[];summ=[]
    for period in fdr.PERIODS:
        rr=[r for r in allresults if r['period']==period and r['grid_id'] in selected]
        for r in rr:
            g=selected[r['grid_id']]
            details.append(dict(grid_id=r['grid_id'],period=period,selection_rule='centroid',x_centroid=g['x_centroid'],y_centroid=g['y_centroid'],area_type=g['area_type'],theilsen_slope=r['theilsen_slope_original'],mk_pvalue=r['mk_pvalue_original'],fdr_pvalue_original=r['fdr_pvalue_original'],fdr_pvalue_recomputed=r['fdr_pvalue_recomputed_BH'],existing_declining_flag=r['declining_flag_original'],classification=r['recomputed_trend_class']))
        sig=sum(r['recomputed_trend_class']=='significant_increase' for r in rr)
        summ.append(dict(selection_rule='centroid',period=period,total_grids=len(rr),existing_declining_n=sum(int(r['declining_flag_original']) for r in rr),positive_slope_n=sum(float(r['theilsen_slope_original'])>0 for r in rr),negative_slope_n=sum(float(r['theilsen_slope_original'])<0 for r in rr),significant_increase_n=sig,significant_increase_pct=100*sig/len(rr),no_significant_trend_n=sum(r['recomputed_trend_class']=='no_significant_trend' for r in rr),significant_decline_n=sum(r['recomputed_trend_class']=='significant_decline' for r in rr)))
    fdr.save(out/'innovation_city_grid_details.csv',sorted(details,key=lambda r:(r['period'],int(r['grid_id']))));fdr.save(out/'innovation_city_trend_summary.csv',summ)
    assert [r['significant_increase_n'] for r in summ]==[17,15]
    assert all(r['significant_decline_n']==0 for r in summ)
    print('Innovation City: 17 centroid-selected grids; significant increases 17 and 15.')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path);a=p.parse_args();root=Path(__file__).resolve().parents[1]
    run(root,a.output_dir.resolve() if a.output_dir else root/'supplementary_outputs/revision')
