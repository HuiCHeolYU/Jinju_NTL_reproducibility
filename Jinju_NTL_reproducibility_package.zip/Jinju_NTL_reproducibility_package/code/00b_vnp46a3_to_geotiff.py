"""Convert explicitly selected VNP46A3 bands to QA-screened GeoTIFFs.

This is an input-preparation utility, not a claim to recover undocumented
historical settings. Select the collection, band, percentile extent and
percentile population explicitly. Radiance below 0.5 is excluded, not set to 0.
"""
import argparse
from datetime import datetime, timedelta
import hashlib
import json
import math
import os
from pathlib import Path
import re

BANDS = [a + '_Composite_' + s for a in ['AllAngle', 'NearNadir', 'OffNadir']
         for s in ['Snow_Free', 'Snow_Covered']]
NAME = re.compile(r'VNP46A3\.A(\d{4})(\d{3})\.(h\d{2}v\d{2})\.(001|002)\.\d{13}\.h5$')
EXCLUDED = {'2012-06', '2015-06', '2020-07', '2020-09', '2022-08'}


def dependencies():
    global np, h5py, rasterio, from_origin
    import numpy as np
    import h5py
    # Isolate the wheel runtime from unrelated desktop GIS installations.
    os.environ['GDAL_DRIVER_PATH'] = 'disable'
    for key in ['GDAL_DATA', 'PROJ_LIB', 'PROJ_DATA']:
        os.environ.pop(key, None)
    import rasterio
    rio = Path(rasterio.__file__).resolve().parent
    for key, sub in [('GDAL_DATA', 'gdal_data'), ('PROJ_LIB', 'proj_data'), ('PROJ_DATA', 'proj_data')]:
        if (rio / sub).is_dir():
            os.environ[key] = str(rio / sub)
    from rasterio.transform import from_origin


def metadata_value(attrs, key):
    value = attrs[key]
    if hasattr(value, 'size') and value.size == 1:
        value = value.reshape(-1)[0]
    if isinstance(value, bytes):
        return value.decode('utf-8')
    return value


def read_field(dataset, window, physical):
    row0, row1, col0, col1 = window
    raw = dataset[row0:row1, col0:col1]
    good = np.isfinite(raw)
    if '_FillValue' not in dataset.attrs:
        raise ValueError('Missing _FillValue metadata: ' + dataset.name)
    fill = np.asarray(metadata_value(dataset.attrs, '_FillValue'), dtype=raw.dtype).item()
    good &= raw != fill
    result = raw.astype('float64')
    if physical:
        if 'scale_factor' not in dataset.attrs:
            raise ValueError('Missing scale_factor metadata: ' + dataset.name)
        scale = float(metadata_value(dataset.attrs, 'scale_factor'))
        offsets = [float(metadata_value(dataset.attrs, k)) for k in ['offset', 'add_offset'] if k in dataset.attrs]
        if any(value != 0 for value in offsets):
            raise ValueError('Nonzero offsets require explicit product-convention review.')
        result *= scale
    good &= result >= 0
    return result, good


def datasets(h):
    found = {}
    def collect(name, obj):
        if isinstance(obj, h5py.Dataset):
            leaf = name.rsplit('/', 1)[-1]
            if leaf in found:
                raise ValueError('Ambiguous dataset name: ' + leaf)
            found[leaf] = obj
    h.visititems(collect)
    return found


def month_and_tile(path, collection):
    m = NAME.fullmatch(path.name)
    if not m or m.group(4) != collection:
        raise ValueError('Unexpected product/collection: ' + path.name)
    year, doy = int(m.group(1)), int(m.group(2))
    day = datetime(year, 1, 1) + timedelta(days=doy - 1)
    if day.year != year or day.day != 1:
        raise ValueError('Expected a monthly first-day granule: ' + path.name)
    return day.strftime('%Y-%m'), m.group(3)


def convert(path, out, a):
    month, tile = month_and_tile(path, a.collection)
    with h5py.File(path, 'r') as h:
        process = str(metadata_value(h.attrs, 'ProcessVersion')).zfill(3)
        if process != a.collection:
            raise ValueError('Filename and HDF collection disagree.')
        fields = datasets(h)
        names = [a.band, a.band+'_Num', a.band+'_Quality', a.band+'_Std']
        if any(n not in fields for n in names):
            raise ValueError('Requested composite or its QA fields are absent.')
        shape = fields[a.band].shape
        if len(shape) != 2 or any(fields[n].shape != shape for n in names):
            raise ValueError('Radiance and QA array dimensions differ.')
        west, south, east, north = [float(metadata_value(h.attrs, key)) for key in
                                   ['WestBoundingCoord','SouthBoundingCoord','EastBoundingCoord','NorthBoundingCoord']]
        height, width = shape
        dx, dy = (east-west)/width, (north-south)/height
        if not (np.isclose(dx, 1/240, rtol=0, atol=1e-8) and np.isclose(dy, 1/240, rtol=0, atol=1e-8)):
            raise ValueError('Expected native 15 arc-second VNP46A3 pixels.')
        xmin, ymin, xmax, ymax = a.bbox
        if not (west <= xmin < xmax <= east and south <= ymin < ymax <= north):
            raise ValueError('The selected percentile/processing extent must lie inside this single tile.')
        c0, c1 = max(0, math.floor((xmin-west)/dx)), min(width, math.ceil((xmax-west)/dx))
        r0, r1 = max(0, math.floor((north-ymax)/dy)), min(height, math.ceil((north-ymin)/dy))
        window = (r0, r1, c0, c1)
        rad, rv = read_field(fields[a.band], window, True)
        num, nv = read_field(fields[a.band+'_Num'], window, False)
        qa, qv = read_field(fields[a.band+'_Quality'], window, False)
        std, sv = read_field(fields[a.band+'_Std'], window, True)
        base = rv & nv & qv & sv & (qa == 0) & (num >= 3) & (rad >= 0.5)
        population = sv if a.std_population == 'all-valid-std' else base
        if not population.any():
            raise ValueError('No valid pixels for the selected monthly standard-deviation percentile.')
        threshold = float(np.percentile(std[population], 95, method='linear'))
        keep = base & (std < threshold)
        clean = np.where(keep, rad, -9999).astype('float32')
        transform = from_origin(west+c0*dx, north-r0*dy, dx, dy)
        target = out / (month.replace('-', '') + '_CleanNTL.tif')
        if target.exists():
            raise FileExistsError(target)
        with rasterio.open(target, 'w', driver='GTiff', width=clean.shape[1], height=clean.shape[0],
                           count=1, dtype='float32', crs='EPSG:4326', transform=transform,
                           nodata=-9999, compress='deflate') as dst:
            dst.write(clean, 1)
            dst.update_tags(product='VNP46A3', collection=a.collection, band=a.band, month=month,
                            units='nW/(cm^2 sr)', source_file=path.name, std_threshold=str(threshold),
                            qa_rule='Quality=0; Num>=3; radiance>=0.5; Std<monthly P95',
                            percentile_population=a.std_population,
                            percentile_extent='pixel-aligned bounding box',
                            historical_settings_verified='false')
        return {'month':month, 'source_file':path.name, 'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                'output_file':target.name, 'tile':tile, 'valid_pixels':int(keep.sum()),
                'std_p95':threshold, 'pixel_aligned_bounds':[transform.c,transform.f-clean.shape[0]*dy,
                                                          transform.c+clean.shape[1]*dx,transform.f]}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inspect', type=Path, help='List bands and metadata in one HDF5 file without conversion')
    p.add_argument('--input-dir', type=Path)
    p.add_argument('--output-dir', type=Path)
    p.add_argument('--collection', choices=['001','002'])
    p.add_argument('--band', choices=BANDS)
    p.add_argument('--bbox', nargs=4, type=float, metavar=('WEST','SOUTH','EAST','NORTH'))
    p.add_argument('--std-population', choices=['all-valid-std','quality-screened'])
    p.add_argument('--start', default='2012-01')
    p.add_argument('--end', default='2024-12')
    a = p.parse_args()
    if not a.inspect and any(getattr(a, k) is None for k in
                             ['input_dir','output_dir','collection','band','bbox','std_population']):
        p.error('Conversion requires input/output directories, collection, band, bbox and std-population.')
    dependencies()
    if a.inspect:
        with h5py.File(a.inspect,'r') as h:
            print('Collection:', metadata_value(h.attrs,'ProcessVersion'))
            for name, field in datasets(h).items():
                if name in BANDS:
                    print(name, field.shape, 'scale_factor=', metadata_value(field.attrs,'scale_factor'))
        return
    start, end = datetime.strptime(a.start,'%Y-%m'), datetime.strptime(a.end,'%Y-%m')
    if start > end:
        p.error('start must not follow end')
    selected = {}
    for path in sorted(a.input_dir.glob('VNP46A3*.h5')):
        month, tile = month_and_tile(path, a.collection)
        if a.start <= month <= a.end and month not in EXCLUDED:
            if month in selected:
                raise ValueError('More than one granule per month. Select one collection/production/tile explicitly.')
            selected[month] = path
    expected=[]; current=start
    while current <= end:
        key=current.strftime('%Y-%m')
        if key not in EXCLUDED: expected.append(key)
        current=current.replace(year=current.year+1,month=1) if current.month==12 else current.replace(month=current.month+1)
    if sorted(selected) != expected:
        raise ValueError('Missing retained months: '+', '.join(sorted(set(expected)-set(selected))))
    out=a.output_dir.resolve()
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('Choose a new or empty output directory.')
    out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for month,path in sorted(selected.items()):
        rows.append(convert(path,out,a));print(month, 'converted')
    manifest={'collection':a.collection,'band':a.band,'std_population':a.std_population,
              'requested_bbox':a.bbox,'excluded_months':sorted(EXCLUDED),'months':rows,
              'historical_settings_verified':False,'reported_results_reproduced':False}
    (out/'conversion_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')


if __name__ == '__main__':
    main()
