"""Reproduce final standard-MK FDR results and retain the original-value comparison."""
from pathlib import Path
import argparse,csv,json,math
PERIODS=['2012-2019','2019-2024']
TREND='grid_ntl_trend_results_by_period.csv'
DECLINE='grid_ntl_declining_grids_by_period.csv'
FINAL_NOTE='final_BH_all_3052_grids_per_period'
def bh(values):
    n=len(values);order=sorted(range(n),key=lambda i:values[i]);q=[None]*n;last=1.0
    for k in range(n-1,-1,-1):
        i=order[k];last=min(last,values[i]*n/(k+1));q[i]=last
    return q
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def save(p,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def calculate(root):
    historical=root/'derived_data/historical'
    allrows=read(historical/TREND);result=[];summary=[];final_by_key={}
    for period in PERIODS:
        rows=[r for r in allrows if r['period']==period]
        assert len(rows)==3052 and len({r['grid_id'] for r in rows})==3052
        p=[float(r['mk_pvalue']) for r in rows]
        assert all(math.isfinite(x) and 0<=x<=1 for x in p)
        qs=bh(p);different=0;filled=0;maxdiff=0;stored_ids=set();new_ids=set()
        for r,q in zip(rows,qs):
            raw=r['fdr_pvalue'];old=float(raw) if raw else None
            slope=float(r['theilsen_slope']);decl=int(r['declining_ntl_activity']);new=int(slope<0 and q<.05)
            delta=q-old if old is not None else None
            diff=old is not None and not math.isclose(old,q,rel_tol=1e-7,abs_tol=1e-10)
            filled+=int(old is not None);different+=int(diff);maxdiff=max(maxdiff,abs(delta) if delta is not None else 0)
            if decl:stored_ids.add(r['grid_id'])
            if new:new_ids.add(r['grid_id'])
            result.append(dict(grid_id=r['grid_id'],period=period,area_type=r['area_type'],theilsen_slope_original=r['theilsen_slope'],mk_pvalue_original=r['mk_pvalue'],fdr_pvalue_original=raw,fdr_pvalue_recomputed_BH=q,fdr_recomputed_minus_original='' if delta is None else delta,fdr_difference_beyond_tolerance='' if old is None else int(diff),original_fdr_status='stored' if raw else 'not_provided_in_original',original_fdr_note=r['fdr_pvalue_note'],declining_flag_original=r['declining_ntl_activity'],declining_flag_recomputed=new,declining_flag_agrees=int(decl==new),recomputed_trend_class='significant_decline' if new else 'significant_increase' if slope>0 and q<.05 else 'no_significant_trend',bh_family_size=len(rows)))
            final=dict(r);final.update(fdr_pvalue=str(q),fdr_pvalue_note=FINAL_NOTE,declining_ntl_activity=str(new),trend_class_fdr='declining' if new else 'non_declining')
            final_by_key[(period,r['grid_id'])]=final
        # Stop on a changed membership rather than forcing the published flags.
        assert stored_ids==new_ids, 'Decline membership changed: review the inputs before publishing.'
        summary.append(dict(period=period,bh_family_size=len(rows),original_fdr_populated_n=filled,original_fdr_missing_n=len(rows)-filled,different_beyond_tolerance_n=different,max_absolute_difference=maxdiff,declining_original_n=len(stored_ids),declining_recomputed_n=len(new_ids),declining_id_sets_identical=True))
    finalrows=[final_by_key[(r['period'],r['grid_id'])] for r in allrows]
    olddecl=read(historical/DECLINE)
    assert {(r['period'],r['grid_id']) for r in olddecl}=={k for k,r in final_by_key.items() if r['declining_ntl_activity']=='1'}
    finaldecl=[final_by_key[(r['period'],r['grid_id'])] for r in olddecl]
    return result,summary,finalrows,finaldecl
def run(root,out,write_final=False):
    out.mkdir(parents=True,exist_ok=True)
    result,summary,finalrows,finaldecl=calculate(root)
    save(out/'fdr_original_vs_recomputed.csv',result);save(out/'fdr_comparison_summary.csv',summary)
    (out/'fdr_comparison_summary.json').write_text(json.dumps(dict(method='Benjamini-Hochberg; independently per period across all 3052 raw MK p-values',relative_tolerance=1e-7,absolute_tolerance=1e-10,summary=summary),indent=2)+'\n',encoding='utf-8')
    if write_final:
        save(out/TREND,finalrows);save(out/DECLINE,finaldecl)
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path);a=p.parse_args();root=Path(__file__).resolve().parents[1]
    run(root,a.output_dir.resolve() if a.output_dir else root/'reproduced_fdr_results',write_final=True)
    print('Final FDR tables and historical comparison reproduced. Distributed source files were not modified.')
