# -*- coding: utf-8 -*-
"""
Mann-Kendall p-value에 Benjamini-Hochberg FDR 보정을 적용하고,
slope < 0 및 FDR-adjusted p-value < 0.05인 격자만 추출하는 코드

입력:
- 기존 Theil-Sen + Mann-Kendall 결과 CSV
- 필수 컬럼: id, left, top, right, bottom, slope, mk_pvalue

출력:
1) 전체 격자 + FDR 보정 결과 CSV
2) FDR 보정 후 감소 격자만 추출한 CSV
3) original p<0.05 기준과 FDR 기준의 결과 요약 CSV
"""

import pandas as pd
import numpy as np
from tkinter import Tk, filedialog, messagebox


def select_input_file():
    root = Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="Theil-Sen + Mann-Kendall 결과 CSV를 선택하세요",
        filetypes=[("CSV files", "*.csv")]
    )
    root.destroy()

    if not file_path:
        raise RuntimeError("입력 파일을 선택하지 않았습니다.")
    return file_path


def select_output_file(default_name):
    root = Tk()
    root.withdraw()
    file_path = filedialog.asksaveasfilename(
        title=f"{default_name} 저장 경로를 선택하세요",
        defaultextension=".csv",
        initialfile=default_name,
        filetypes=[("CSV files", "*.csv")]
    )
    root.destroy()

    if not file_path:
        raise RuntimeError("저장 경로를 지정하지 않았습니다.")
    return file_path


def benjamini_hochberg_fdr(pvalues):
    """
    Benjamini-Hochberg FDR 보정 함수.
    statsmodels 없이 동작하도록 직접 구현.

    Parameters
    ----------
    pvalues : array-like
        원래 p-value 배열. NaN 포함 가능.

    Returns
    -------
    adjusted_pvalues : np.ndarray
        FDR 보정 p-value 배열. NaN은 그대로 유지.
    """

    pvalues = np.asarray(pvalues, dtype=float)
    adjusted = np.full_like(pvalues, np.nan, dtype=float)

    valid_mask = np.isfinite(pvalues)
    valid_p = pvalues[valid_mask]

    m = len(valid_p)
    if m == 0:
        return adjusted

    # p-value 오름차순 정렬
    order = np.argsort(valid_p)
    sorted_p = valid_p[order]

    # BH adjusted p-value 계산: p_i * m / rank_i
    ranks = np.arange(1, m + 1)
    bh_values = sorted_p * m / ranks

    # 뒤에서 앞으로 누적 최소값 적용
    bh_values = np.minimum.accumulate(bh_values[::-1])[::-1]

    # adjusted p-value는 최대 1.0
    bh_values = np.minimum(bh_values, 1.0)

    # 원래 순서로 되돌리기
    adjusted_valid = np.empty_like(bh_values)
    adjusted_valid[order] = bh_values

    adjusted[valid_mask] = adjusted_valid
    return adjusted


def make_summary(df):
    """
    original p<0.05 기준과 FDR 보정 기준을 비교하는 요약표 생성.
    area_type 또는 area 컬럼이 있으면 urban/non-urban별 요약도 생성 가능.
    """

    total_n = len(df)

    summary_rows = []

    def add_summary(label, sub_df):
        n = len(sub_df)
        if n == 0:
            return

        original_declining = sub_df["declining_original"].sum()
        fdr_declining = sub_df["declining_fdr"].sum()

        summary_rows.append({
            "group": label,
            "total_grids": n,
            "original_declining_grids": int(original_declining),
            "original_declining_share_percent": round(original_declining / n * 100, 2),
            "fdr_declining_grids": int(fdr_declining),
            "fdr_declining_share_percent": round(fdr_declining / n * 100, 2)
        })

    # 전체 요약
    add_summary("total", df)

    # urban / non-urban 구분 컬럼이 있는 경우 자동 요약
    possible_group_cols = ["area_type", "urban_nonurban", "urban_type", "지역구분", "구분"]

    group_col = None
    for col in possible_group_cols:
        if col in df.columns:
            group_col = col
            break

    if group_col is not None:
        for group_name, sub_df in df.groupby(group_col):
            add_summary(str(group_name), sub_df)

    return pd.DataFrame(summary_rows)


def main():
    try:
        print("1️⃣ Theil-Sen + Mann-Kendall 결과 CSV를 선택하세요.")
        input_csv = select_input_file()
        print(f"[입력 파일] {input_csv}")

        df = pd.read_csv(input_csv)

        required_cols = {"id", "left", "top", "right", "bottom", "slope", "mk_pvalue"}
        missing = required_cols - set(df.columns)
        if missing:
            raise ValueError(f"필수 컬럼이 누락되었습니다: {missing}")

        # 숫자형 변환
        df["slope"] = pd.to_numeric(df["slope"], errors="coerce")
        df["mk_pvalue"] = pd.to_numeric(df["mk_pvalue"], errors="coerce")

        # Benjamini-Hochberg FDR 보정
        df["fdr_pvalue"] = benjamini_hochberg_fdr(df["mk_pvalue"].values)

        # 기존 기준: slope < 0 and mk_pvalue < 0.05
        df["declining_original"] = (df["slope"] < 0) & (df["mk_pvalue"] < 0.05)

        # FDR 보정 기준: slope < 0 and fdr_pvalue < 0.05
        df["declining_fdr"] = (df["slope"] < 0) & (df["fdr_pvalue"] < 0.05)

        # 보기 편한 판정 컬럼
        df["trend_class_fdr"] = np.where(
            df["declining_fdr"],
            "declining",
            "not_declining"
        )

        # 요약표 생성
        summary = make_summary(df)

        print("\n[요약]")
        print(summary.to_string(index=False))

        print("\n2️⃣ FDR 보정값이 포함된 전체 결과 CSV 저장 경로를 선택하세요.")
        full_output_csv = select_output_file("theilsen_mk_fdr_all_grids.csv")
        df.to_csv(full_output_csv, index=False, encoding="utf-8-sig")

        print("\n3️⃣ FDR 보정 후 감소 격자만 저장할 CSV 경로를 선택하세요.")
        declining_output_csv = select_output_file("declining_grids_fdr_only.csv")
        declining_df = df[df["declining_fdr"]].copy()
        declining_df.to_csv(declining_output_csv, index=False, encoding="utf-8-sig")

        print("\n4️⃣ original 기준과 FDR 기준 비교 요약 CSV 저장 경로를 선택하세요.")
        summary_output_csv = select_output_file("declining_grids_fdr_summary.csv")
        summary.to_csv(summary_output_csv, index=False, encoding="utf-8-sig")

        print("\n✅ 완료")
        print(f"- 전체 결과 저장: {full_output_csv}")
        print(f"- FDR 감소 격자 저장: {declining_output_csv}")
        print(f"- 요약표 저장: {summary_output_csv}")
        print(f"- FDR 감소 격자 수: {len(declining_df)}")

        messagebox.showinfo(
            "완료",
            f"FDR 보정 완료\n\n"
            f"전체 격자 수: {len(df)}\n"
            f"FDR 감소 격자 수: {len(declining_df)}"
        )

    except Exception as e:
        messagebox.showerror("오류", str(e))
        raise


if __name__ == "__main__":
    main()