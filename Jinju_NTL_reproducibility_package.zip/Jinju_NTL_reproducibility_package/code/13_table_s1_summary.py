"""Summarize existing grid-level results for Table S1; do not refit any model or test."""
from pathlib import Path
import argparse,csv
PERIODS=['2012-2019','2019-2024']
def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def build(root,out):
    trends=read(root/'derived_data/grid_ntl_trend_results_by_period.csv')
    source=out/'seasonal_mk_calendar_aligned_declining_grids.csv'
    if not source.exists():source=root/'supplementary_outputs/revision/seasonal_mk_calendar_aligned_declining_grids.csv'
    seasonal=read(source);summary=[]
    for period in PERIODS:
        rr=[r for r in trends if r['period']==period]
        assert len(rr)==3052 and len({r['grid_id'] for r in rr})==3052
        unadjusted={r['grid_id'] for r in rr if float(r['theilsen_slope'])<0 and float(r['mk_pvalue'])<.05}
        standard={r['grid_id'] for r in rr if float(r['theilsen_slope'])<0 and float(r['fdr_pvalue'])<.05}
        assert standard=={r['grid_id'] for r in rr if r['declining_ntl_activity']=='1'}
        ss=[r for r in seasonal if r['period']==period]
        assert len(ss)==len({r['id'] for r in ss})
        assert all(r['declining_seasonal_fdr'].lower()=='true' and float(r['theilsen_slope'])<0 and float(r['seasonal_fdr_pvalue'])<.05 for r in ss)
        seasonal_ids={r['id'] for r in ss}
        assert seasonal_ids<={r['grid_id'] for r in rr}
        inter=len(standard&seasonal_ids);union=len(standard|seasonal_ids)
        summary.append(dict(period=period,unadjusted_mk=len(unadjusted),mk_fdr=len(standard),seasonal_mk_fdr=len(seasonal_ids),intersection=inter,union=union,jaccard=inter/union))
    return summary
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path);a=p.parse_args()
    root=Path(__file__).resolve().parents[1];out=a.output_dir.resolve() if a.output_dir else root/'reproduced_s1_results'
    rows=build(root,out);out.mkdir(parents=True,exist_ok=True)
    with (out/'table_S1_summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('Table S1 summarized from existing stored results; no MK, seasonal MK or regression refit.')
if __name__=='__main__':main()
