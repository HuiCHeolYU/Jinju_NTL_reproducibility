from pathlib import Path
from zipfile import ZipFile
import sys,os,io,json,time,warnings
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
import argparse
parser=argparse.ArgumentParser(description='Re-estimate land-cover models and descriptive tables from included derived inputs.')
parser.add_argument('--output-dir',type=Path,default=ROOT/'reproduced/reanalysis_v7')
args=parser.parse_args();DATA=ROOT/'derived_data/revision_inputs';OUT=args.output_dir.resolve();OUT.mkdir(parents=True,exist_ok=True)
import numpy as np,pandas as pd
from scipy import stats,sparse
from scipy.sparse.linalg import splu
from scipy.optimize import minimize_scalar
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from libpysal.weights import W
from esda.moran import Moran
from spreg import ML_Lag
from threadpoolctl import threadpool_limits
threadpool_limits(limits=2)
CODES=[111,112,121,131,141,153,154,155,161,162,163];SEVEN=[111,112,121,131,141,162,163]
NAMES=['Detached housing','Multi-family housing','Industrial facilities','Commercial and business facilities','Amusement and leisure facilities','Railroads','Roads','Other transportation and communication facilities','Environmental infrastructure','Educational and administrative facilities','Other public facilities']
a=pd.read_csv(DATA/'grid_landcover_2012.csv').set_index('grid_id').sort_index();b=pd.read_csv(DATA/'grid_landcover_2024.csv').set_index('grid_id').loc[a.index]
m=pd.read_csv(DATA/'regression_sample_membership.csv').set_index('grid_id').loc[a.index]
g=pd.read_csv(DATA/'grid_coordinates.csv').set_index('grid_id').loc[a.index]
assert np.array_equal(a.common_valid_m2,b.common_valid_m2)
selected=m.in_regression_sample.eq(1)
assert selected.sum()==2422 and (selected&m.area_type.eq('urban')).sum()==340
xbase=g.left.min();ybase=g.bottom.min();col=np.rint((g.left-xbase)/500).astype(int);row=np.rint((g.bottom-ybase)/500).astype(int)
assert np.max(abs((g.left-xbase)/500-col))<1e-6 and np.max(abs((g.bottom-ybase)/500-row))<1e-6
# Queen neighbors are identified in the original regular grid, before projection and boundary clipping.
def weights(ids,region):
 pos={(int(col.loc[gid]),int(row.loc[gid])):int(gid) for gid in ids}
 neighbors={int(gid):[pos[(int(col.loc[gid])+dx,int(row.loc[gid])+dy)] for dx in [-1,0,1] for dy in [-1,0,1] if (dx or dy) and (int(col.loc[gid])+dx,int(row.loc[gid])+dy) in pos] for gid in ids}
 w=W(neighbors,id_order=[int(v) for v in ids],silence_warnings=True);w.transform='r'
 edge=[{'from_grid':gid,'to_grid':q,'weight':1/len(nei)} for gid,nei in neighbors.items() for q in nei]
 pd.DataFrame(edge).to_csv(OUT/f'weights_{region}.csv',index=False)
 return w,{'region':region,'n':w.n,'islands':list(map(int,w.islands)),'components':int(w.n_components),'directed_edges':int(w.sparse.nnz),'row_standardized':True,'s0':float(w.s0)}
def ols(ids,codes):
 y=m.loc[ids,'ntl_slope'].to_numpy(float)
 x=(b.loc[ids,[f'area_{c}_m2' for c in codes]]-a.loc[ids,[f'area_{c}_m2' for c in codes]]).to_numpy(float)
 mean=x.mean(0);sd=x.std(0);assert (sd>0).all()
 A=np.column_stack([np.ones(len(ids)),(x-mean)/sd]);q,r=np.linalg.qr(A,mode='reduced');theta=np.linalg.solve(r,q.T@y)
 T=np.eye(A.shape[1]);T[0,1:]=-mean/sd;T[1:,1:]=np.diag(1/sd)
 B=T@theta;u=y-A@theta;h=(q*q).sum(1);pinv=np.linalg.solve(r,q.T)
 cov=T@((pinv*(u/(1-h))**2)@pinv.T)@T.T;se=np.sqrt(np.diag(cov));df=len(y)-A.shape[1];p=2*stats.t.sf(abs(B/se),df)
 fit=sm.OLS(y,A).fit();hc=fit.get_robustcov_results(cov_type='HC3',use_t=True)
 assert np.allclose(theta,fit.params,rtol=1e-9,atol=1e-10)
 assert np.allclose(cov,T@hc.cov_params()@T.T,rtol=1e-7,atol=1e-12)
 f=float(B[1:]@np.linalg.solve(cov[1:,1:],B[1:])/len(codes));r2=1-u@u/((y-y.mean())@(y-y.mean()))
 vif=np.diag(np.linalg.inv(np.corrcoef(x,rowvar=False)))
 bp=het_breuschpagan(u,A,robust=True)
 aux=np.linalg.lstsq(A,u*u,rcond=None)[0];auxres=u*u-A@aux
 lm=len(y)*(1-auxres@auxres/((u*u-(u*u).mean())@(u*u-(u*u).mean())))
 assert abs(lm-bp[0])<1e-8
 frame=pd.DataFrame({'code':['const']+codes,'variable':['Constant']+[NAMES[CODES.index(c)] for c in codes],'B':B,'beta':np.r_[np.nan,B[1:]*x.std(0,ddof=1)/y.std(ddof=1)],'HC3_SE':se,'HC3_t':B/se,'HC3_p':p})
 summary={'n':len(y),'df_resid':df,'R2':float(r2),'adj_R2':float(1-(1-r2)*(len(y)-1)/df),'robust_F':f,'robust_F_p':float(stats.f.sf(f,len(codes),df)),'max_VIF':float(vif.max()),'mean_VIF':float(vif.mean()),'Koenker_BP_LM':float(bp[0]),'Koenker_BP_p':float(bp[1])}
 return frame,summary,(y,x,A,T,u,vif,mean,sd)
def moran(u,w,seed):
 np.random.seed(seed);mi=Moran(u,w,transformation='r',permutations=999)
 v=u-u.mean();manual=len(v)/w.s0*(v@(w.sparse@v))/(v@v)
 assert abs(manual-mi.I)<1e-12
 return {'I':float(mi.I),'p_sim':float(mi.p_sim),'permutations':999,'seed':seed}
coefs=[];fits=[];sarco=[];sarfit=[];vifs=[];ws=[];roads=[];roadfit=[]
for ri,(region,mask) in enumerate([('Citywide',selected),('Urban',selected&m.area_type.eq('urban')),('Nonurban',selected&m.area_type.eq('non-urban'))]):
 ids=a.index[mask];coef,fit,stuff=ols(ids,CODES);y,x,A,T,u,vif,mean,sd=stuff
 coef.insert(0,'region',region);coefs.append(coef)
 w,wm=weights(ids,region);ws.append(wm)
 om=moran(u,w,20261111+ri)
 fit.update({'region':region,'OLS_Moran_I':om['I'],'OLS_Moran_p':om['p_sim']});fits.append(fit)
 vifs.extend({'region':region,'code':c,'VIF':float(v)} for c,v in zip(CODES,vif))
 print('OLS',region,json.dumps(fit),flush=True)
 # Centered/scaled X for stable optimization. Coefficients and covariance are transformed back to per-m2 units.
 model=ML_Lag(y[:,None],A[:,1:],w=w,method='LU',epsilon=1e-9,spat_impacts=None,spat_diag=False,name_x=NAMES,name_y='Monthly_NTL_slope',name_w=region)
 theta=model.betas[:-1,0];rho=float(model.rho);B=T@theta
 J=np.eye(len(B)+1);J[:-1,:-1]=T;cov=J@model.vm@J.T;se=np.sqrt(np.diag(cov));coefall=np.r_[B,rho];p=2*stats.norm.sf(abs(coefall/se))
 wy=w.sparse@y;given=np.linalg.lstsq(A,y-rho*wy,rcond=None)[0]
 assert np.allclose(given,theta,rtol=1e-6,atol=1e-9)
 residual=y-rho*wy-A@theta;assert np.allclose(residual,model.u.ravel(),atol=1e-9)
 I=sparse.eye(len(y),format='csc')
 def concentrated(r):
  e=y-r*wy-A@np.linalg.lstsq(A,y-r*wy,rcond=None)[0]
  lu=splu(I-r*w.sparse.tocsc());ld=np.log(np.abs(lu.U.diagonal())).sum()
  return len(y)/2*np.log(e@e/len(y))-ld
 check=minimize_scalar(concentrated,bounds=(-.999,.999),method='bounded',options={'xatol':1e-9})
 assert check.success and abs(check.x-rho)<2e-5
 smi=moran(residual,w,20261211+ri)
 sarco.extend({'region':region,'code':c,'variable':v,'B':float(be),'SE':float(ss),'z':float(be/ss),'p':float(pp)} for c,v,be,ss,pp in zip(['const']+CODES+['rho'],['Constant']+NAMES+['Spatial lag coefficient'],coefall,se,p))
 sf={'region':region,'n':len(y),'rho':rho,'rho_p':float(p[-1]),'log_likelihood':float(model.logll),'AIC':float(model.aic),'pseudo_R2':float(model.pr2),'residual_Moran_I':smi['I'],'residual_Moran_p':smi['p_sim'],'independent_rho':float(check.x),'independent_rho_difference':float(abs(check.x-rho))};sarfit.append(sf)
 pd.DataFrame({'grid_id':ids,'y':y,'OLS_residual':u,'SAR_structural_residual':residual,'SAR_predicted':model.predy.ravel()}).to_csv(OUT/f'residuals_{region}.csv',index=False)
 print('SPATIAL_LAG',region,json.dumps(sf),flush=True)
 if region=='Urban':
  for tag,cs in [('with_road',CODES),('without_road',[c for c in CODES if c!=154])]:
   cf,ft,_=ols(ids,cs);cf.insert(0,'model',tag);roads.append(cf);roadfit.append({'model':tag,**ft})
pd.concat(coefs).to_csv(OUT/'ols_coefficients.csv',index=False);pd.DataFrame(fits).to_csv(OUT/'ols_diagnostics.csv',index=False)
pd.DataFrame(sarco).to_csv(OUT/'spatial_lag_coefficients.csv',index=False);pd.DataFrame(sarfit).to_csv(OUT/'spatial_lag_diagnostics.csv',index=False)
pd.DataFrame(vifs).to_csv(OUT/'vif.csv',index=False);pd.concat(roads).to_csv(OUT/'urban_road_coefficients.csv',index=False);pd.DataFrame(roadfit).to_csv(OUT/'urban_road_diagnostics.csv',index=False)
(OUT/'weights_metadata.json').write_text(json.dumps(ws,indent=2),encoding='utf-8')
# Tables 6-7 use all 3052 study grids and the seven specified facility categories.
areas=[]
for region,mask in [('Citywide',np.ones(len(a),dtype=bool)),('Urban',a.area_type.eq('urban')),('Nonurban',a.area_type.eq('non-urban'))]:
 v0=a.loc[mask,[f'area_{c}_m2' for c in SEVEN]].sum();v1=b.loc[mask,[f'area_{c}_m2' for c in SEVEN]].sum();delta=v1-v0;den=abs(delta).sum()
 for c in SEVEN:
  f=f'area_{c}_m2';areas.append({'region':region,'code':c,'variable':NAMES[CODES.index(c)],'area2012_m2':int(v0[f]),'area2024_m2':int(v1[f]),'delta_m2':int(delta[f]),'share2012_percent':float(v0[f]/v0.sum()*100),'share2024_percent':float(v1[f]/v1.sum()*100),'signed_contribution_percent':float(delta[f]/den*100)})
pd.DataFrame(areas).to_csv(OUT/'landcover_tables6_7.csv',index=False)
trend=pd.read_csv(ROOT/'derived_data/grid_ntl_trend_results_by_period.csv')
exp=[]
non=a.area_type.eq('non-urban')
for c in [121,131]:
 change=b[f'area_{c}_m2']-a[f'area_{c}_m2'];ex=change>0
 for period in ['2012-2019','2019-2024']:
  declining=set(trend.loc[(trend.period==period)&trend.declining_ntl_activity.eq(1),'grid_id'])
  for tag,mask in [('Expansion',non&ex),('No expansion',non&~ex)]:
   ids=a.index[mask];num=sum(int(v) in declining for v in ids);exp.append({'code':c,'period':period,'group':tag,'n':len(ids),'declining_n':num,'declining_percent':100*num/len(ids)})
pd.DataFrame(exp).to_csv(OUT/'nonurban_expansion_overlap.csv',index=False)
urban=selected&m.area_type.eq('urban');ce=(b.area_131_m2-a.area_131_m2)>0;negative=m.ntl_slope<0
case={'urban_commercial_expansion_regression_grids':int((urban&ce).sum()),'negative_full_period_slopes_among_these':[int(v) for v in a.index[urban&ce&negative]],'grid2144':{'commercial2012':int(a.loc[2144,'area_131_m2']),'commercial2024':int(b.loc[2144,'area_131_m2']),'roads2012':int(a.loc[2144,'area_154_m2']),'roads2024':int(b.loc[2144,'area_154_m2']),'industrial2012':int(a.loc[2144,'area_121_m2']),'industrial2024':int(b.loc[2144,'area_121_m2'])}}
(OUT/'case_selection.json').write_text(json.dumps(case,indent=2),encoding='utf-8')
import importlib.metadata as md
versions={n:md.version(n) for n in ['numpy','scipy','pandas','statsmodels','spreg','libpysal','esda','shapely','pyproj']}
summary={'software_versions':versions,'weights':ws,'OLS':fits,'SAR':sarfit,'road_sensitivity':roadfit,'case':case,'all_2422_original_regression_members_retained':True,'same_common_pixel_support_both_years':True,'independent_verification':'OLS QR versus statsmodels HC3; SAR conditional coefficients and separately optimized sparse-LU concentrated likelihood; Moran formula checked independently.','NoData_grid_exclusion_used':False}
(OUT/'model_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print('FINAL_SUMMARY',json.dumps(summary,ensure_ascii=False),flush=True)
