"""Calculate parcel-area benchmarks from the extracted official source values."""
from pathlib import Path
import csv,argparse

def run(root,out):
    out.mkdir(parents=True,exist_ok=True)
    with (root/'derived_data/revision_inputs/jinju_cadastral_2024_source_values.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    for r in rows:
        area=float(r['area_m2']);count=int(r['parcel_count']);assert area>0 and count>0
        r['arithmetic_mean_parcel_area_m2']=area/count;r['grid_area_m2']=250000;r['grid_area_to_mean_parcel_area_ratio']=250000/(area/count)
    with (out/'jinju_parcel_size_benchmarks.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('Cadastral benchmark calculation complete.')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path);a=p.parse_args();root=Path(__file__).resolve().parents[1]
    run(root,a.output_dir.resolve() if a.output_dir else root/'supplementary_outputs/revision')
