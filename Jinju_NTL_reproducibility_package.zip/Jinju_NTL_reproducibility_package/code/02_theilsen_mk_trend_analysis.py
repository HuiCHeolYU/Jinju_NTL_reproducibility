# .csv 파일명: ex) 201201~ 형태여야 함.
# 격자별 Theil–Sen 기울기 + Mann–Kendall p-value
# 입력 폴더와 결과 저장 경로를 모두 직접 지정하는 버전

import os, re, glob
import numpy as np
import pandas as pd
from scipy.stats import theilslopes
from tkinter import Tk, filedialog

# Mann–Kendall (사전 설치 필요: pip install pymannkendall)
try:
    import pymannkendall as mk
except Exception as e:
    raise RuntimeError(
        "pymannkendall가 필요합니다. 먼저 'pip install pymannkendall' 실행 후 다시 시도하세요."
    ) from e

def select_folder(title="폴더를 선택하세요"):
    root = Tk(); root.withdraw()
    folder = filedialog.askdirectory(title=title)
    root.destroy()
    if not folder:
        raise RuntimeError("폴더를 선택하지 않았습니다.")
    return folder

def save_file_dialog(default_name="theilsen_slope_mk.csv"):
    root = Tk(); root.withdraw()
    file_path = filedialog.asksaveasfilename(
        title="결과를 저장할 경로를 선택하세요",
        defaultextension=".csv",
        initialfile=default_name,
        filetypes=[("CSV files", "*.csv")],
    )
    root.destroy()
    if not file_path:
        raise RuntimeError("저장 경로를 지정하지 않았습니다.")
    return file_path

def yyyymm_from_path(path):
    base = os.path.basename(path)
    m = re.search(r"(\d{6})", base)
    if not m:
        return None
    return int(m.group(1)[:4]), int(m.group(1)[4:])

def month_index(dates: pd.Series) -> np.ndarray:
    y = dates.dt.year.to_numpy()
    m = dates.dt.month.to_numpy()
    abs_month = y * 12 + (m - 1)
    return abs_month - abs_month.min()

def theil_sen_slope(x, y):
    mask = np.isfinite(x) & np.isfinite(y)
    x2, y2 = x[mask], y[mask]
    if len(y2) < 2:
        return np.nan
    if np.nanstd(y2) == 0:
        return 0.0
    s, _, _, _ = theilslopes(y2, x2)
    return float(s)

def mk_pvalue(y):
    y2 = y[np.isfinite(y)]
    if len(y2) < 3:
        return np.nan
    try:
        res = mk.original_test(y2)
        return float(res.p)
    except Exception:
        return np.nan

def main():
    print("1️⃣ CSV 파일들이 있는 폴더를 선택하세요.")
    data_dir = select_folder("CSV 파일들이 있는 폴더를 선택하세요")
    print(f"[입력 폴더] {data_dir}")

    print("2️⃣ 결과를 저장할 파일 경로를 지정하세요.")
    out_csv = save_file_dialog("theilsen_slope_mk.csv")
    print(f"[저장 경로] {out_csv}")

    files = sorted(glob.glob(os.path.join(data_dir, "*.csv")))
    if not files:
        raise FileNotFoundError(f"CSV 파일을 찾지 못했습니다: {data_dir}")

    frames = []
    for fp in files:
        ym = yyyymm_from_path(fp)
        if ym is None:
            print(f"[건너뜀] 연월 패턴 없는 파일: {os.path.basename(fp)}")
            continue
        year, month = ym
        df = pd.read_csv(fp, encoding="utf-8-sig")
        required = {"id", "left", "top", "right", "bottom", "_mean"}
        miss = required - set(df.columns)
        if miss:
            raise ValueError(f"{os.path.basename(fp)}에 필요한 컬럼이 없습니다: {miss}")
        df["_mean"] = df["_mean"].astype(float).fillna(0.0)
        df["year"], df["month"] = year, month
        frames.append(df)

    if not frames:
        raise RuntimeError("YYYYMM 패턴의 CSV가 없습니다.")

    all_df = pd.concat(frames, ignore_index=True)
    all_df["date"] = pd.to_datetime(
        all_df["year"].astype(str) + "-" + all_df["month"].astype(str) + "-01"
    )
    all_df = all_df.sort_values(["id", "date"])

    out_rows = []
    for gid, g in all_df.groupby("id", sort=False):
        g = g.sort_values("date")
        x = month_index(g["date"])
        y = g["_mean"].to_numpy(float)

        slope = theil_sen_slope(x, y)
        pval = mk_pvalue(y)

        row = g.iloc[0][["id", "left", "top", "right", "bottom"]].to_dict()
        row["slope"] = slope
        row["mk_pvalue"] = pval
        out_rows.append(row)

    res = pd.DataFrame(out_rows, columns=["id", "left", "top", "right", "bottom", "slope", "mk_pvalue"])
    res.to_csv(out_csv, index=False, encoding="utf-8-sig")

    print(f"\n✅ [완료] 결과 저장: {out_csv}")
    print(f"총 {len(res)}개 격자 분석 완료.")
    print("열 구성: id, left, top, right, bottom, slope, mk_pvalue")

if __name__ == "__main__":
    main()

