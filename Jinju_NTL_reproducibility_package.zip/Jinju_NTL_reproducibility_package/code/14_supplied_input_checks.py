"""Derived-input checks for the staged revision. Statistical methods match the verified Stage4 calculation."""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from PIL import Image
import numpy as np,pandas as pd,json,math,hashlib
import argparse
parser=argparse.ArgumentParser(description='Recompute stored-input OLS, NoData sensitivity, case-area and regional-overlap checks. No monthly MK, population allocation or spatial-lag fit is performed.')
parser.add_argument('--output-dir',type=Path)
args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[1]
W=args.output_dir.resolve() if args.output_dir else ROOT/'reproduced_supplied_inputs'
for protected in ['derived_data','supplementary_outputs','processing_notes','code']:
    assert not W.is_relative_to(ROOT/protected), 'Output must not replace distributed reference material.'
assert W != ROOT, 'Use a separate output directory.'
W.mkdir(parents=True,exist_ok=True)
PREFIX=''
class PackageFiles:
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def read(self,name):
        p=(ROOT/name).resolve()
        assert p.is_relative_to(ROOT)
        return p.read_bytes()
CODES=[111,112,121,131,141,153,154,155,161,162,163]
NAMES=['Detached housing','Multi-family housing','Industrial facilities','Commercial and business facilities','Amusement and leisure facilities','Railroads','Roads','Other transport and communication','Environmental infrastructure','Educational and administrative facilities','Other public facilities']
SEVEN=[111,112,121,131,141,162,163]
sources=[]
def read(z,n):
 raw=z.read(PREFIX+n);sources.append({'member':PREFIX+n,'sha256':hashlib.sha256(raw).hexdigest()});return raw
def csv(z,n):return pd.read_csv(BytesIO(read(z,n)),float_precision='round_trip')
with PackageFiles() as z:
 a=csv(z,'derived_data/revision_inputs/grid_landcover_2012.csv').set_index('grid_id',verify_integrity=True)
 b=csv(z,'derived_data/revision_inputs/grid_landcover_2024.csv').set_index('grid_id',verify_integrity=True)
 m=csv(z,'derived_data/revision_inputs/regression_sample_membership.csv').set_index('grid_id',verify_integrity=True)
 road=csv(z,'supplementary_outputs/revision/urban_road_sensitivity_coefficients.csv')
 maps=csv(z,'supplementary_outputs/revision/grid2144_map_landcover_area.csv')
 mc=json.loads(read(z,'supplementary_outputs/revision/grid2144_map_change.json'))
 meta=json.loads(read(z,'derived_data/spatial_inputs/grid2144_metadata.json'))
 rasters=[];rmeta=[]
 for year in [2012,2024]:
  im=Image.open(BytesIO(read(z,f'derived_data/spatial_inputs/grid2144_landcover_{year}.tif')))
  arr=np.asarray(im);rasters.append(arr);rmeta.append({'year':year,'shape':list(arr.shape),'mode':im.mode,'nodata_tag':str(im.tag_v2.get(42113)),'pixel_scale':list(im.tag_v2.get(33550,()))})
 innovation=csv(z,'supplementary_outputs/revision/innovation_city_grid_details.csv')
assert set(a.index)==set(b.index)==set(m.index) and len(m)==3052
b=b.loc[a.index];m=m.loc[a.index]
assert (a.area_type==b.area_type).all() and (a.area_type==m.area_type).all()
assert a.notna().all().all() and b.notna().all().all()
flag=(a.nodata_m2>0)|(b.nodata_m2>0);non=m.area_type=='non-urban';selected=m.in_regression_sample==1
assert flag.sum()==392 and (flag&selected).sum()==278 and not (flag&~non).any()
summary=[]
for year,data in [(2012,a),(2024,b)]:
 for region,mask in [('Citywide',np.ones(len(m),dtype=bool)),('Urban',~non),('Non-urban',non)]:
  summary.append({'year':year,'area':region,'n':int(np.sum(mask)),'recorded_nodata_grids':int((data.nodata_m2[mask]>0).sum()),'recorded_nodata_m2':int(data.nodata_m2[mask].sum())})
cols7=[f'area_{c}_m2' for c in SEVEN];d7=b[cols7].sum(axis=1)-a[cols7].sum(axis=1)
areas=[]
for label,mask in [('All non-urban',non),('No recorded NoData in either year',non&~flag),('Recorded NoData in at least one year',non&flag)]:
 areas.append({'cohort':label,'n':int(mask.sum()),'seven_categories_2012_m2':int(a.loc[mask,cols7].sum().sum()),'seven_categories_2024_m2':int(b.loc[mask,cols7].sum().sum()),'change_m2':int(d7[mask].sum())})
assert [r['change_m2'] for r in areas]==[-2395973,-1836600,-559373]
share=float(d7[non&flag].sum()/d7[non].sum()*100)

def betacf(a,b,x):
 tiny=1e-300;qab=a+b;qap=a+1;qam=a-1;c=1.;d=1.-qab*x/qap
 if abs(d)<tiny:d=tiny
 d=1/d;h=d
 for j in range(1,2001):
  j2=2*j;aa=j*(b-j)*x/((qam+j2)*(a+j2));d=1+aa*d
  if abs(d)<tiny:d=tiny
  c=1+aa/c
  if abs(c)<tiny:c=tiny
  d=1/d;h*=d*c;aa=-(a+j)*(qab+j)*x/((a+j2)*(qap+j2));d=1+aa*d
  if abs(d)<tiny:d=tiny
  c=1+aa/c
  if abs(c)<tiny:c=tiny
  d=1/d;delta=d*c;h*=delta
  if abs(delta-1)<2e-14:return h
 raise ArithmeticError('Incomplete beta did not converge')
def ibeta(a,b,x):
 if x<=0:return 0.
 if x>=1:return 1.
 bt=math.exp(math.lgamma(a+b)-math.lgamma(a)-math.lgamma(b)+a*math.log(x)+b*math.log1p(-x))
 if x<(a+1)/(a+b+2):return bt*betacf(a,b,x)/a
 return 1-bt*betacf(b,a,1-x)/b
def tp(t,df):return ibeta(df/2,.5,df/(df+t*t))
def quad_p(t,df):
 nodes,weights=np.polynomial.legendre.leggauss(96);u=abs(t);xx=(nodes+1)*u/2
 dens=np.exp(math.lgamma((df+1)/2)-math.lgamma(df/2)-.5*math.log(df*math.pi)-(df+1)/2*np.log1p(xx*xx/df))
 return 1-u*np.dot(weights,dens)
def model(ids,codes=CODES):
 y=m.loc[ids,'ntl_slope'].to_numpy(float);x=(b.loc[ids,[f'area_{c}_m2' for c in codes]]-a.loc[ids,[f'area_{c}_m2' for c in codes]]).to_numpy(float)
 assert np.isfinite(y).all() and np.isfinite(x).all()
 means=x.mean(0);sd=x.std(0);assert (sd>0).all()
 design=np.column_stack([np.ones(len(y)),(x-means)/sd]);q,r=np.linalg.qr(design,mode='reduced');k=design.shape[1]
 assert np.linalg.matrix_rank(r)==k
 theta=np.linalg.solve(r,q.T@y);trans=np.eye(k);trans[0,1:]=-means/sd;trans[1:,1:]=np.diag(1/sd)
 B=trans@theta;e=y-design@theta;lev=np.sum(q*q,axis=1);pinv=np.linalg.solve(r,q.T)
 cov=trans@((pinv*(e/(1-lev))**2)@pinv.T)@trans.T;se=np.sqrt(np.diag(cov));ts=B/se;df=len(y)-k
 ps=np.array([tp(v,df) for v in ts]);assert np.all((ps>=0)&(ps<=1))
 for t,p in zip(ts,ps):
  if p>1e-7:assert abs(p-quad_p(t,df))<2e-10
 raw=np.column_stack([np.ones(len(y)),x]);B2,_,rank,_=np.linalg.lstsq(raw,y,rcond=None)
 assert rank==k and np.allclose(B,B2,atol=2e-10,rtol=1e-9)
 # Independently form the HC3 covariance from the unscaled design pseudoinverse.
 pi=np.linalg.pinv(raw);res2=y-raw@B2;h2=np.einsum('ij,ji->i',raw,pi);cov2=(pi*(res2/(1-h2))**2)@pi.T
 assert np.allclose(se,np.sqrt(np.diag(cov2)),rtol=2e-7,atol=1e-10)
 beta=np.r_[np.nan,B[1:]*x.std(0,ddof=1)/y.std(ddof=1)]
 r2=1-e@e/((y-y.mean())@(y-y.mean()))
 return pd.DataFrame({'code':['const']+codes,'variable':['Constant']+[NAMES[CODES.index(c)] for c in codes],'B':B,'beta':beta,'HC3_SE':se,'HC3_t':ts,'HC3_p':ps}),{'n':len(y),'df_resid':df,'r2':float(r2),'adjusted_r2':float(1-(1-r2)*(len(y)-1)/df),'max_leverage':float(lev.max()),'rank':int(rank),'max_solver_difference':float(abs(B-B2).max())}

coefs=[];fits=[]
for region,mask in [('Citywide',selected),('Urban',selected&~non),('Non-urban',selected&non)]:
 for cohort,kept in [('Baseline',mask),('Exclude recorded NoData',mask&~flag)]:
  frame,fit=model(m.index[kept]);frame.insert(0,'cohort',cohort);frame.insert(0,'area',region);coefs.append(frame)
  fits.append({'area':region,'cohort':cohort,'removed_n':int(mask.sum()-kept.sum()),**fit})
coef=pd.concat(coefs,ignore_index=True);fit=pd.DataFrame(fits)
urban=coef[(coef.area=='Urban')&(coef.cohort=='Baseline')]
ref=road[road.model=='with_road'].copy();ref['code']=ref['code'].map(lambda c:'const' if pd.isna(c) else int(c))
join=urban.merge(ref,on='code',suffixes=('_new','_stored'),validate='one_to_one')
assert len(join)==12
for c in ['B','beta','HC3_SE','HC3_t','HC3_p']:
 assert np.allclose(join[c+'_new'],join[c+'_stored'],rtol=1e-7,atol=1e-10,equal_nan=True),c
assert fit.n.tolist()==[2422,2144,340,340,2082,1804]
urban2=coef[(coef.area=='Urban')&(coef.cohort=='Exclude recorded NoData')]
assert np.array_equal(urban.B.values,urban2.B.values)

ids=m.index[selected&~non];expand=(b.loc[ids,'area_131_m2']-a.loc[ids,'area_131_m2'])>0
negative=m.loc[ids,'ntl_slope']<0
assert expand.sum()==201 and ids[expand&negative].tolist()==[2144]
assert [a.loc[2144,'area_131_m2'],b.loc[2144,'area_131_m2']]==[7998,9677]
assert a.loc[2144,'area_121_m2']==b.loc[2144,'area_121_m2']==0
for arr in rasters:assert (arr==131).sum() in [7987,9594]
map2012=int((rasters[0]==131).sum());map2024=int((rasters[1]==131).sum())
valid2012=rasters[0]!=int(rmeta[0]['nodata_tag']);valid2024=rasters[1]!=int(rmeta[1]['nodata_tag'])
assert np.array_equal(valid2012,valid2024) and int(valid2012.sum())==250213
assert map2024-map2012==1607
assert int(((rasters[0]!=131)&(rasters[1]==131)).sum())==4683
assert int(((rasters[0]==131)&(rasters[1]!=131)).sum())==3076
case={'selection':'Unique negative stored full-period slope among 201 commercially expanding urban regression grids; purposive',
 'regression_commercial_2012_m2':7998,'regression_commercial_2024_m2':9677,'regression_change_m2':1679,
 'map_commercial_2012_m2':map2012,'map_commercial_2024_m2':map2024,'map_change_m2':1607,'difference_between_changes_m2':72,
 'map_valid_pixels':250213,'raster_metadata':rmeta,'mask_area_m2':250213,
 'map_crs_from_metadata':meta['map_crs'],'adopted_grid_crs_from_metadata':meta['grid_crs'],'crs_status':meta['crs_status'],
 'exact_cause_of_72_m2_difference_not_established':True,'industrial_area_both_years_m2':0,'monthly_slope_not_reestimated':True}
audit={'inputs':sources,'nodata_by_year_area':summary,'nonurban_area_groups':areas,'share_of_net_decrease_in_nodata_grids_percent':share,
 'recorded_nodata_union_grids':392,'included_in_baseline_regression':278,'urban_recorded_zero_not_completeness_validation':True,
 'model_method':'OLS with intercept and unchanged 11 area-difference predictors, including roads; stored full-period NTL slope; HC3 with Student-t n-k degrees of freedom; baseline and excluded models are different samples',
 'original_model_reproduced_to_reported_precision':True,'independent_qr_vs_lstsq_and_hc3_checks_passed':True,
 'pvalue_check':'Regularized incomplete beta evaluated via continued fraction; compared with 96-node Student-t density quadrature where p>1e-7 and with 12 stored urban HC3 results',
 'spatial_model_reestimated':False,'NoData_causal_effect_identified':False,'case':case}
for filename,data in [('nodata_summary.csv',pd.DataFrame(summary)),('nodata_seven_class_areas.csv',pd.DataFrame(areas)),('nodata_ols_coefficients.csv',coef),('nodata_ols_fit.csv',fit)]:data.to_csv(W/filename,index=False,encoding='utf-8-sig',float_format='%.17g')
pd.DataFrame({'grid_id':m.index,'area_type':m.area_type.values,'nodata_2012_m2':a.nodata_m2.values,'nodata_2024_m2':b.nodata_m2.values,'recorded_nodata_either_year':flag.astype(int).values,'baseline_regression_member':selected.astype(int).values,'retained_sensitivity_member':(selected&~flag).astype(int).values}).to_csv(W/'nodata_sample_membership.csv',index=False,encoding='utf-8-sig')
(W/'calculation_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')

# Independently check the road-excluded model against the retained reference.
road_rows=[];road_fits=[]
for label,codes in [('with_road',CODES),('without_road',[c for c in CODES if c!=154])]:
    rr,ff=model(m.index[selected&~non],codes)
    rr.insert(0,'model',label);road_rows.append(rr);road_fits.append({'model':label,**ff})
    ref=road[road.model==label].copy();ref['code']=ref['code'].map(lambda c:'const' if pd.isna(c) else int(c))
    cmp=rr.merge(ref,on='code',suffixes=('_new','_stored'),validate='one_to_one')
    for col in ['B','beta','HC3_SE','HC3_t','HC3_p']:
        assert np.allclose(cmp[col+'_new'],cmp[col+'_stored'],rtol=1e-7,atol=1e-10,equal_nan=True),col
pd.concat(road_rows,ignore_index=True).to_csv(W/'urban_road_coefficients_checked.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
pd.DataFrame(road_fits).to_csv(W/'urban_road_fit_checked.csv',index=False,encoding='utf-8-sig',float_format='%.17g')

trend=pd.read_csv(ROOT/'derived_data/grid_ntl_trend_results_by_period.csv',float_precision='round_trip')
seas=pd.read_csv(ROOT/'supplementary_outputs/revision/standard_seasonal_membership.csv')
assert not trend.duplicated(['period','grid_id']).any() and not seas.duplicated(['period','grid_id']).any()
joined=trend.merge(seas[['period','grid_id','standard_declining','seasonal_declining']],on=['period','grid_id'],validate='one_to_one')
assert len(joined)==6104 and (joined.declining_ntl_activity==joined.standard_declining).all()
regions=[]
for period in ['2012-2019','2019-2024']:
    for area in ['all','urban','non-urban']:
        rr=joined[(joined.period==period)&((joined.area_type==area) if area!='all' else True)]
        aa=set(rr.loc[rr.standard_declining==1,'grid_id']);bb=set(rr.loc[rr.seasonal_declining==1,'grid_id'])
        regions.append(dict(period=period,area_type=area,study_grids=len(rr),standard_n=len(aa),seasonal_n=len(bb),intersection_n=len(aa&bb),union_n=len(aa|bb),jaccard=len(aa&bb)/len(aa|bb),standard_only_n=len(aa-bb),seasonal_only_n=len(bb-aa)))
pd.DataFrame(regions).to_csv(W/'regional_overlap_checked.csv',index=False,encoding='utf-8-sig',float_format='%.17g')

# Recompute expansion/decline counts for both supplied cohorts.
expansion=pd.read_csv(ROOT/'supplementary_outputs/revision/expansion_decline_comparison.csv')
exp_checks=[]
for _,r in expansion.iterrows():
    cohort=non if r.cohort=='all_nonurban' else non&~flag
    ids=m.index[cohort];expanded=(b.loc[ids,f'area_{int(r.landcover_code)}_m2']>a.loc[ids,f'area_{int(r.landcover_code)}_m2'])
    declines=set(trend.loc[(trend.period==r.period)&(trend.declining_ntl_activity==1),'grid_id'])
    ex=set(ids[expanded]);ne=set(ids)-ex
    observed={'total_n':len(ids),'declining_n':len(set(ids)&declines),'expansion_n':len(ex),'expansion_declining_n':len(ex&declines),'nonexpansion_n':len(ne),'nonexpansion_declining_n':len(ne&declines)}
    for k,value in observed.items():assert int(r[k])==value,(r.cohort,r.period,k)
    for k,value in [('expansion_decline_pct',100*len(ex&declines)/len(ex)),('nonexpansion_decline_pct',100*len(ne&declines)/len(ne))]:assert math.isclose(r[k],value,abs_tol=1e-10)
    exp_checks.append({'cohort':r.cohort,'landcover_code':int(r.landcover_code),'period':r.period,**observed})
pd.DataFrame(exp_checks).to_csv(W/'expansion_counts_checked.csv',index=False,encoding='utf-8-sig')

# Check recorded selected IDs; original spatial CRS and legal boundary remain unverified.
ic=[]
for period in ['2012-2019','2019-2024']:
    chosen=innovation[(innovation.period==period)&(innovation.selection_rule=='centroid')]
    assert chosen.grid_id.nunique()==17
    rr=trend[(trend.period==period)&trend.grid_id.isin(chosen.grid_id)]
    ic.append({'period':period,'selected_n':len(rr),'significant_positive_n':int(((rr.theilsen_slope>0)&(rr.fdr_pvalue<.05)).sum()),'positive_nonsignificant_n':int(((rr.theilsen_slope>0)&(rr.fdr_pvalue>=.05)).sum()),'declining_n':int(rr.declining_ntl_activity.sum())})
assert [x['significant_positive_n'] for x in ic]==[17,15]
pd.DataFrame(ic).to_csv(W/'innovation_stored_selection_checked.csv',index=False,encoding='utf-8-sig')
audit['execution_scope']='Supplied derived inputs only. No monthly trend test, SGIS allocation, or spatial-lag estimation rerun.'
audit['regional_overlap']=regions
audit['road_sensitivity_matches_retained_outputs']=True
audit['expansion_counts_match_retained_outputs']=True
audit['innovation_stored_selection_checked']=ic
(W/'calculation_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print('Supplied-input checks completed: OLS, recorded-NoData sensitivity, road sensitivity, regional overlap, case-area checks, expansion counts and stored Innovation City selection.')
