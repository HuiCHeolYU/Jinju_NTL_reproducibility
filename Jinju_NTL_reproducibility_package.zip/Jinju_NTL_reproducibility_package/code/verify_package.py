"""Verify optional checksums, packaged result consistency, and optional v2 rerun CSVs."""
from pathlib import Path
import argparse,csv,math,hashlib,json

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f);return r.fieldnames,list(r)
def matches(a,b,key):
    if a==b:return True
    if a=='' or b=='':return False
    try:
        x,y=float(a),float(b)
    except ValueError:return False
    if not (math.isfinite(x) and math.isfinite(y)):return False
    exact=key in ['grid_id','code','year','valid_months','n','predictor_count','df_model','df_resid','bh_family_size'] or key.endswith('_n') or key.startswith('declining_flag')
    return x==y if exact else math.isclose(x,y,rel_tol=1e-8,abs_tol=1e-12)
def verify_final_fdr(root):
    _,main=read(root/'derived_data/grid_ntl_trend_results_by_period.csv')
    _,decl=read(root/'derived_data/grid_ntl_declining_grids_by_period.csv')
    _,old=read(root/'derived_data/historical/grid_ntl_trend_results_by_period.csv')
    _,side=read(root/'supplementary_outputs/revision/fdr_original_vs_recomputed.csv')
    key=lambda r:(r['period'],r['grid_id'])
    mm={key(r):r for r in main};oo={key(r):r for r in old};ss={key(r):r for r in side}
    assert len(main)==len(mm)==6104 and mm.keys()==oo.keys()==ss.keys()
    for k,r in mm.items():
        prev=oo[k];s=ss[k];q=float(r['fdr_pvalue']);p=float(r['mk_pvalue'])
        assert math.isfinite(q) and 0<=p<=q+1e-12 and q<=1
        assert r['mk_pvalue']==prev['mk_pvalue']==s['mk_pvalue_original']
        assert r['theilsen_slope']==prev['theilsen_slope']==s['theilsen_slope_original']
        assert s['fdr_pvalue_original']==prev['fdr_pvalue']
        assert math.isclose(q,float(s['fdr_pvalue_recomputed_BH']),rel_tol=1e-12,abs_tol=1e-15)
        flag=str(int(float(r['theilsen_slope'])<0 and q<.05))
        assert r['declining_ntl_activity']==flag==prev['declining_ntl_activity']
        assert r['trend_class_fdr']==('declining' if flag=='1' else 'non_declining')
        assert r['fdr_pvalue_note']=='final_BH_all_3052_grids_per_period'
    assert {key(r) for r in decl}=={k for k,r in mm.items() if r['declining_ntl_activity']=='1'}
    assert all(r==mm[key(r)] for r in decl)
    for period,count in [('2012-2019',378),('2019-2024',80)]:
        rr=sorted((r for r in main if r['period']==period),key=lambda r:float(r['mk_pvalue']))
        assert len(rr)==3052
        last=1.0
        for i in range(len(rr)-1,-1,-1):
            last=min(last,float(rr[i]['mk_pvalue'])*len(rr)/(i+1))
            assert math.isclose(last,float(rr[i]['fdr_pvalue']),rel_tol=1e-12,abs_tol=1e-15)
        assert sum(r['declining_ntl_activity']=='1' for r in rr)==count
    return dict(grid_period_rows=6104,declining_counts=[378,80],historical_values_preserved=True,final_values_match_BH=True)

def verify_s1_summary(root,actual=None):
    reference=root/'supplementary_outputs/revision/table_S1_summary.csv'
    fields,rows=read(reference if actual is None else actual)
    assert fields==['period','unadjusted_mk','mk_fdr','seasonal_mk_fdr','intersection','union','jaccard']
    assert len(rows)==2 and {r['period'] for r in rows}=={'2012-2019','2019-2024'}
    _,trends=read(root/'derived_data/grid_ntl_trend_results_by_period.csv')
    _,members=read(root/'supplementary_outputs/revision/standard_seasonal_membership.csv')
    for r in rows:
        period=r['period'];tt=[x for x in trends if x['period']==period];mm=[x for x in members if x['period']==period]
        assert len(tt)==len(mm)==3052
        unadjusted=sum(float(x['theilsen_slope'])<0 and float(x['mk_pvalue'])<.05 for x in tt)
        standard={x['grid_id'] for x in tt if x['declining_ntl_activity']=='1'}
        other_standard={x['grid_id'] for x in mm if x['standard_declining']=='1'}
        seasonal={x['grid_id'] for x in mm if x['seasonal_declining']=='1'}
        assert standard==other_standard
        values=(unadjusted,len(standard),len(seasonal),len(standard&seasonal),len(standard|seasonal))
        assert tuple(int(r[k]) for k in ['unadjusted_mk','mk_fdr','seasonal_mk_fdr','intersection','union'])==values
        assert math.isclose(float(r['jaccard']),values[3]/values[4],rel_tol=1e-12,abs_tol=1e-15)
    return {'unadjusted_MK_counts':[int(r['unadjusted_mk']) for r in rows],'standard_FDR_counts':[int(r['mk_fdr']) for r in rows],'seasonal_FDR_counts':[int(r['seasonal_mk_fdr']) for r in rows],'all_S1_fields_match_stored_grid_results':True}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--results',type=Path);p.add_argument('--seasonal-results',type=Path);p.add_argument('--fdr-results',type=Path);p.add_argument('--s1-results',type=Path);a=p.parse_args();root=Path(__file__).resolve().parents[1]
    checksum_file=root/'SHA256SUMS.txt'
    checksum_present=checksum_file.is_file()
    hashed=[]
    if checksum_present:
        for line in checksum_file.read_text(encoding='utf-8').splitlines():
            digest,name=line.split('  ',1);file=(root/name).resolve();assert file.is_relative_to(root),name
            assert file.is_file() and hashlib.sha256(file.read_bytes()).hexdigest()==digest,name
            hashed.append(name)
        assert len(hashed)==len(set(hashed))
    else:
        print('Checksum verification not performed: checksum manifest is not distributed.')
    result=dict(checksum_verification='performed' if checksum_present else 'not_performed_manifest_absent',distributed_files_verified=len(hashed),reference_csvs_compared=0)
    result['final_standard_MK_FDR']=verify_final_fdr(root)
    seasonal_names={
        'table_S1_summary.csv',
        'seasonal_mk_calendar_aligned_all_grids.csv',
        'seasonal_mk_calendar_aligned_declining_grids.csv',
        'seasonal_mk_calendar_aligned_summary.csv',
        'seasonal_mk_calendar_alignment_comparison.csv',
        'seasonal_mk_calendar_months.csv',
        'table_S1_panel_B_overlap.csv','standard_seasonal_membership.csv'}
    reference=root/'supplementary_outputs/revision'
    for name in seasonal_names:assert (reference/name).is_file(),name
    # Validate current published sets, unchanged standard flags, and S1 counts.
    _,allrows=read(reference/'seasonal_mk_calendar_aligned_all_grids.csv')
    _,members=read(reference/'standard_seasonal_membership.csv')
    _,mainrows=read(root/'derived_data/grid_ntl_trend_results_by_period.csv')
    mainflags={(r['period'],r['grid_id']):int(r['declining_ntl_activity']) for r in mainrows}
    memberflags={(r['period'],r['grid_id']):(int(r['standard_declining']),int(r['seasonal_declining'])) for r in members}
    assert len(allrows)==len(members)==len(mainflags)==len(memberflags)==6104
    for r in allrows:
        key=(r['period'],r['grid_id']);current=int(r['seasonal_declining_calendar_aligned'])
        assert current==int(float(r['theilsen_slope_preserved'])<0 and float(r['seasonal_q_calendar_aligned'])<.05)
        assert memberflags[key]==(mainflags[key],current)
        assert int(r['standard_declining_preserved'])==mainflags[key]
        assert r['seasonal_declining_original']==r['seasonal_declining_baseline_reproduced']
    _,overlap=read(reference/'table_S1_panel_B_overlap.csv')
    for period,expected_values in [('2012-2019',(378,413,366,425)),('2019-2024',(80,62,62,80))]:
        rr=[r for r in members if r['period']==period]
        aa={r['grid_id'] for r in rr if int(r['standard_declining'])}
        bb={r['grid_id'] for r in rr if int(r['seasonal_declining'])}
        assert (len(aa),len(bb),len(aa&bb),len(aa|bb))==expected_values
        row=next(r for r in overlap if r['period']==period and r['area_type']=='all')
        assert tuple(int(row[k]) for k in ['standard_n','seasonal_n','intersection_n','union_n'])==expected_values
        assert math.isclose(float(row['jaccard']),len(aa&bb)/len(aa|bb),abs_tol=1e-12)
    result['seasonal_current_counts_and_standard_flags_verified']=True
    result['table_S1_summary']=verify_s1_summary(root)
    if a.s1_results:
        result['table_S1_reproduction']=verify_s1_summary(root,a.s1_results/'table_S1_summary.csv')
    fdr_results=a.fdr_results or a.results
    if fdr_results:
        paths=['derived_data/grid_ntl_trend_results_by_period.csv','derived_data/grid_ntl_declining_grids_by_period.csv','supplementary_outputs/revision/fdr_original_vs_recomputed.csv','supplementary_outputs/revision/fdr_comparison_summary.csv']
        for rel in paths:
            expected=root/rel;actual=fdr_results/expected.name
            fields,x=read(expected);other,y=read(actual)
            assert fields==other and len(x)==len(y),(rel,'shape')
            for i,(xx,yy) in enumerate(zip(x,y),2):
                for k in fields:assert matches(xx[k],yy[k],k),(rel,i,k)
        assert json.loads((reference/'fdr_comparison_summary.json').read_text())==json.loads((fdr_results/'fdr_comparison_summary.json').read_text())
        result['fdr_reproduction_files_compared']=5
    selected_results=a.seasonal_results or a.results
    if selected_results:
        for expected in sorted((root/'supplementary_outputs/revision').glob('*.csv')):
            if a.seasonal_results and expected.name not in seasonal_names:continue
            fields,x=read(expected);actual=selected_results/expected.name;assert actual.is_file(),actual.name
            other,y=read(actual);assert fields==other,(expected.name,'columns');assert len(x)==len(y),(expected.name,'rows')
            for i,(xx,yy) in enumerate(zip(x,y),2):
                for k in fields:assert matches(xx[k],yy[k],k),(expected.name,i,k,xx[k],yy[k])
            result['reference_csvs_compared']+=1
    if a.results and not a.seasonal_results:
        from PIL import Image
        with Image.open(a.results/'Figure6_Grid2144.png') as img:assert img.size==(4800,1800)
        result['figure_dimensions_verified']=True
        result['figure_note']='The distributed accepted PNG is preserved; pixel equality with a new rendering is not required. Map source values are checked in the CSV comparison.'
    if a.seasonal_results:
        baseline=json.loads((reference/'revision_results.json').read_text(encoding='utf-8'))
        actual=json.loads((a.seasonal_results/'revision_results.json').read_text(encoding='utf-8'))
        assert actual==baseline,'Seasonal-only runner changed other stored result fields'
        result['nonseasonal_result_fields_preserved']=True
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
