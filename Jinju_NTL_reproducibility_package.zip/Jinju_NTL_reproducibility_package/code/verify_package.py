from pathlib import Path
import hashlib,json,csv,math,argparse
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--reproduced',type=Path);args=p.parse_args()
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
 sha,name=line.split('  ',1);assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
print('All package checksums match.')
if args.reproduced:
 reference=root/'supplementary_outputs/reanalysis_v7'
 targets=['ols_coefficients.csv','ols_diagnostics.csv','spatial_lag_coefficients.csv','spatial_lag_diagnostics.csv','urban_road_coefficients.csv','urban_road_diagnostics.csv','landcover_tables6_7.csv','nonurban_expansion_overlap.csv','vif.csv']
 for name in targets:
  a=list(csv.DictReader((reference/name).open(newline='',encoding='utf-8-sig')));b=list(csv.DictReader((args.reproduced/name).open(newline='',encoding='utf-8-sig')));assert len(a)==len(b),name
  for x,y in zip(a,b):
   assert x.keys()==y.keys(),name
   for key in x:
    try:
     u,v=float(x[key]),float(y[key]);assert (math.isnan(u) and math.isnan(v)) or math.isclose(u,v,rel_tol=2e-5,abs_tol=2e-8),(name,key,u,v)
    except ValueError:assert x[key]==y[key],(name,key)
 print('All reproduced outputs match within numerical tolerance.')
