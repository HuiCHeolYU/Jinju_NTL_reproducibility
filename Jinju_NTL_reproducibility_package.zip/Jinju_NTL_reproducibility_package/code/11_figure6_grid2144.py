"""Recreate the accepted Figure 6 from its packaged raster clips and OSM snapshot.
Map totals and original regression areas are intentionally kept separate.
"""
from pathlib import Path
import argparse,json,csv,os,xml.etree.ElementTree as ET
import numpy as np
# This script needs only the built-in GeoTIFF driver.
os.environ['GDAL_DRIVER_PATH']='disable'
import rasterio
# Use the installed wheel data instead of unrelated system GIS settings.
_rio=Path(rasterio.__file__).resolve().parent
for _key,_sub in [("GDAL_DATA","gdal_data"),("PROJ_LIB","proj_data"),("PROJ_DATA","proj_data")]:
    if (_rio/_sub).is_dir():os.environ[_key]=str(_rio/_sub)
from pyproj import Transformer
from shapely.geometry import shape
from shapely.ops import transform
from scipy.ndimage import label, distance_transform_edt
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Polygon,Patch
from matplotlib.lines import Line2D
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output-dir',type=Path);args=parser.parse_args()
root=Path(__file__).resolve().parents[1];inp=root/'derived_data/spatial_inputs'
out=args.output_dir.resolve() if args.output_dir else root/'supplementary_outputs/revision';out.mkdir(parents=True,exist_ok=True)
j=json.loads((inp/'grid2144_metadata.json').read_text(encoding='utf-8'))
tr=Transformer.from_crs(4326,5186,always_xy=True);cx,cy=tr.transform(*j['center_wgs84'])
grid=transform(tr.transform,shape(j['boundary_wgs84']));border=np.asarray(grid.exterior.coords)-[cx,cy]
osm=ET.fromstring((inp/'grid2144_osm_reference_2026-10-23.osm').read_bytes())
nodes={n.attrib['id']:(float(n.attrib['lon']),float(n.attrib['lat'])) for n in osm.findall('node')};ways=[]
for w in osm.findall('way'):
    coords=[nodes.get(n.attrib['ref']) for n in w.findall('nd')]
    if None in coords:continue
    tags={t.attrib['k']:t.attrib['v'] for t in w.findall('tag')};xy=np.array([tr.transform(*p) for p in coords])-[cx,cy]
    ways.append(dict(id=w.attrib['id'],tags=tags,xy=xy,closed=coords[0]==coords[-1]))
gas=next(w for w in ways if w['id']=='477487066')
with rasterio.open(inp/'grid2144_landcover_2012.tif') as ds:
    a=ds.read(1);gt=ds.transform.to_gdal();crs=ds.crs;nodata=ds.nodata
with rasterio.open(inp/'grid2144_landcover_2024.tif') as ds:
    b=ds.read(1);assert ds.transform.to_gdal()==gt and ds.crs==crs and ds.nodata==nodata
assert crs.to_epsg()==5186 and abs(gt[1]*gt[5])==1
mask=(a!=nodata)&(b!=nodata);assert int(mask.sum())==j['mask_pixels']
gain=mask&(a!=131)&(b==131);loss=mask&(a==131)&(b!=131);keep=mask&(a==131)&(b==131)
assert [int(gain.sum()),int(loss.sum()),int(keep.sum())]==[4683,3076,4911]
extent=[gt[0]-cx,gt[0]+a.shape[1]*gt[1]-cx,gt[3]+a.shape[0]*gt[5]-cy,gt[3]-cy]
change=np.zeros(a.shape,dtype=np.int8);change[keep]=1;change[gain]=2;change[loss]=3;change=np.ma.masked_where(~mask,change)
change_colors=['#f4f5f6','#93a0b5','#e54158','#287fa3']
labels,n=label(gain);sizes=np.bincount(labels.ravel());order=np.argsort(sizes[1:])[::-1]+1;patches={}
for tag,l in zip('ABC',order[:3]):
    rr,cc=np.where(labels==l);xx=gt[0]+(cc+0.5)*gt[1]-cx;yy=gt[3]+(rr+0.5)*gt[5]-cy
    patches[tag]=dict(label=int(l),xy=[float(xx.mean()),float(yy.mean())],area_m2=int(len(rr)))
# Editorial correction 2026-11-10: choose arrow tips inside the existing
# connected gain patches. Patch membership, counts and stored centroids are unchanged.
annotation_points={}
for tag, patch in patches.items():
    component=labels==patch['label']
    distance=distance_transform_edt(component)
    rr,cc=np.where(distance==distance.max())
    centre=np.argwhere(component).mean(axis=0)
    k=int(np.argmin((rr-centre[0])**2+(cc-centre[1])**2))
    r,c=int(rr[k]),int(cc[k])
    assert component[r,c]
    if tag in 'AB':assert a[r,c]==154 and b[r,c]==131
    annotation_points[tag]=[float(gt[0]+(c+0.5)*gt[1]-cx),float(gt[3]+(r+0.5)*gt[5]-cy)]

def boundary(ax):ax.plot(border[:,0],border[:,1],color='#152c42',lw=1.4,zorder=20)
def show_change(ax):ax.imshow(change,extent=extent,origin='upper',cmap=ListedColormap(change_colors),vmin=0,vmax=3,interpolation='nearest',zorder=2)

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.unicode_minus':False})
fig,axs=plt.subplots(1,4,figsize=(12,4.5))
fig.subplots_adjust(left=.015,right=.992,top=.91,bottom=.24,wspace=.08)
def decor(ax):
 boundary(ax);ax.set_xlim(-267,267);ax.set_ylim(-267,267);ax.set_aspect('equal')
 ax.set_xticks([]);ax.set_yticks([])
 ax.annotate('N',xy=(231,224),xytext=(231,164),ha='center',fontsize=10,arrowprops={'arrowstyle':'-|>','color':'black','lw':1},zorder=30)
 ax.plot([120,220],[-238,-238],color='#152c42',lw=2,zorder=30)
 ax.text(170,-219,'100 m',ha='center',fontsize=9,zorder=31,bbox={'fc':'white','ec':'none','alpha':.85,'pad':.5})
def arrow(ax,txt,xy,pos,size=9,col='#222',shrinkB=2):
 ax.annotate(txt,xy=xy,xytext=pos,ha='center',fontsize=size,color=col,bbox={'fc':'white','ec':'none','alpha':.94,'pad':1},arrowprops={'arrowstyle':'->','color':col,'lw':.8,'shrinkB':shrinkB},zorder=40)
ax=axs[0];ax.set_facecolor('#fafafa')
for w in ways:
 xy,t=w['xy'],w['tags']
 if w['closed'] and len(xy)>3 and 'building' in t:ax.add_patch(Polygon(xy,closed=True,facecolor='#d9dde0',edgecolor='#aab0b4',lw=.2,zorder=2))
for w in ways:
 xy,t=w['xy'],w['tags']
 if 'highway' in t:
  width=1.8 if t['highway'] in ['tertiary','secondary','primary'] else .7
  ax.plot(xy[:,0],xy[:,1],color='#aeb5bb',lw=width+.6,zorder=3);ax.plot(xy[:,0],xy[:,1],color='white',lw=width,zorder=4)
 if 'waterway' in t:ax.plot(xy[:,0],xy[:,1],color='#78b4cb',lw=2,zorder=5)
ax.plot(gas['xy'][:,0],gas['xy'][:,1],color='#235ba8',lw=1.4,ls='--',zorder=21)
ax.plot([0],[0],'+',color='black',ms=4,zorder=30)
arrow(ax,'Jinju Seobu Nonghyup\nfuel station / supplies centre',(-177,-199),(-18,-95),9,'#235ba8')
arrow(ax,'Nabulcheon Stream',(15,60),(32,130),9,'#286d88')
ax.text(-218,219,'Ihyeon-dong',fontsize=10,zorder=30)
ax.text(30,-209,'Seojangdae-ro',fontsize=8.6,rotation=13,zorder=30,bbox={'fc':'white','ec':'none','pad':.5})
ax.set_title('(a) Location',loc='left',fontsize=12,pad=8);decor(ax)
ax.text(.5,-.09,'35.192536째N, 128.058887째E\nAddress: 215 Seojangdae-ro',transform=ax.transAxes,ha='center',fontsize=8.5)
spec=[('Detached housing',[111],'#ebb267'),('Multi-family housing',[112],'#f0d782'),('Commercial / business',[131],'#e44d78'),('Roads',[154],'#9da5ab'),('Other built-up classes',[121,141,153,155,161,162,163],'#b8a5d0'),('Agriculture',[211,212,221,222,231,241,251,252],'#d0ce85'),('Forest',[311,321,331],'#468a6b'),('Grassland',[411,421,422,423],'#a2bf75'),('Wetland',[511,512,521,522],'#91c3b6'),('Bare land',[611,612,621,622,623],'#dacbb0'),('Water',[711,712,721],'#64a8c8')]
for ax,arr,title in [(axs[1],a,'(b) Land cover in 2012'),(axs[2],b,'(c) Land cover in 2024')]:
 c=np.zeros(arr.shape,dtype=int)
 for i,(_,values,_) in enumerate(spec,1):c[np.isin(arr,values)]=i
 assert not (mask&(c==0)).any()
 ax.imshow(np.ma.masked_where(~mask,c),extent=extent,origin='upper',cmap=ListedColormap(['white']+[s[2] for s in spec]),vmin=0,vmax=len(spec),interpolation='nearest')
 decor(ax);ax.set_title(title,loc='left',fontsize=12,pad=8)
 for k,pos in [('A',(-95,-202)),('B',(-95,-130))]:arrow(ax,k,annotation_points[k],pos,10,shrinkB=0)
ax=axs[3];show_change(ax);decor(ax);ax.set_title('(d) Commercial change',loc='left',fontsize=12,pad=8)
for k,pos in [('A',(-70,-202)),('B',(-70,-120))]:arrow(ax,k,annotation_points[k],pos,10,shrinkB=0)
ax.legend(handles=[Patch(facecolor=change_colors[2],label='Newly classified'),Patch(facecolor=change_colors[3],label='No longer classified'),Patch(facecolor=change_colors[1],label='Retained')],loc='upper left',bbox_to_anchor=(0,-.02),frameon=False,ncol=1,fontsize=8.5,handlelength=1)
fig.legend(handles=[Patch(facecolor=c,label=l) for l,v,c in spec],loc='lower left',bbox_to_anchor=(.018,.015),ncol=4,frameon=False,fontsize=9,columnspacing=1.1,handlelength=1)
fig.savefig(out/'Figure6_Grid2144.png',dpi=400,facecolor='white')
print(str(out/'Figure6_Grid2144.png'))



plt.close(fig)
rows=[]
for year,arr in [(2012,a),(2024,b)]:
    codes,counts=np.unique(arr[mask],return_counts=True)
    for c,n in zip(codes,counts):rows.append(dict(grid_id=2144,year=year,landcover_code=int(c),map_area_m2=int(n),source='Figure6_clipped_raster_EPSG5186'))
with (out/'grid2144_map_landcover_area.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
original_areas={}
for year in [2012,2024]:
    with (root/f'derived_data/revision_inputs/grid_landcover_{year}.csv').open(encoding='utf-8-sig',newline='') as f:
        record=next(r for r in csv.DictReader(f) if r['grid_id']=='2144');original_areas[year]=float(record['area_131_m2'])
assert original_areas=={2012:7998.0,2024:9677.0}
changes=dict(grid_id=2144,commercial_map_2012_m2=int((mask&(a==131)).sum()),commercial_map_2024_m2=int((mask&(b==131)).sum()),newly_classified_m2=int(gain.sum()),no_longer_classified_m2=int(loss.sum()),retained_m2=int(keep.sum()),net_map_change_m2=int(gain.sum()-loss.sum()),regression_input_2012_m2=original_areas[2012],regression_input_2024_m2=original_areas[2024],regression_input_change_m2=original_areas[2024]-original_areas[2012],patches=patches)
(out/'grid2144_map_change.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8')
