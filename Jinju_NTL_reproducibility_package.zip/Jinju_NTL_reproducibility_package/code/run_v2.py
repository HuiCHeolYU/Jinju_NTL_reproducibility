"""Run v2 additions without overwriting distributed reference results."""
from pathlib import Path
import argparse,subprocess,sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output-dir',type=Path)
p.add_argument('--monthly-ntl',type=Path,help='Locally prepared monthly input CSV; see monthly_ntl_source_workflow.txt')
p.add_argument('--seasonal-only',action='store_true',help='Reproduce only the corrected seasonal test and overlap')
a=p.parse_args();root=Path(__file__).resolve().parents[1]
monthly=a.monthly_ntl.resolve() if a.monthly_ntl else root/'derived_data/grid_monthly_ntl_2012_2024.csv'
if not monthly.is_file():
    p.error('Monthly NTL CSV is not distributed. Prepare it from NASA Earthdata using processing_notes/monthly_ntl_source_workflow.txt, then pass --monthly-ntl PATH.')
out=a.output_dir.resolve() if a.output_dir else root/('reproduced_seasonal_results' if a.seasonal_only else 'reproduced_results')
out.mkdir(parents=True,exist_ok=True)
names=['12_seasonal_mk_calendar_aligned.py','07_revision_analyses.py','13_table_s1_summary.py']
if not a.seasonal_only:names.insert(0,'08_fdr_comparison.py')
if not a.seasonal_only:names+=['09_innovation_city.py','10_cadastral_benchmarks.py','11_figure6_grid2144.py']
for name in names:
    cmd=[sys.executable,str(root/'code'/name),'--output-dir',str(out)]
    if name in ['12_seasonal_mk_calendar_aligned.py','07_revision_analyses.py']:cmd+=['--monthly-ntl',str(monthly)]
    if a.seasonal_only and name=='07_revision_analyses.py':cmd.append('--seasonal-only')
    subprocess.run(cmd,check=True)
print('Completed '+('seasonal correction only' if a.seasonal_only else 'v2 analyses')+': '+str(out))
