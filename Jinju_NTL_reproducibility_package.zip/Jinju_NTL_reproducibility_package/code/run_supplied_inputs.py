"""Run only calculations supported by the supplied package, without monthly NTL input."""
from pathlib import Path
import argparse,subprocess,sys
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-dir',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
out=a.output_dir.resolve() if a.output_dir else root/'reproduced_supplied_inputs'
if out==root or any(out.is_relative_to(root/d) for d in ['code','derived_data','processing_notes','supplementary_outputs']):p.error('Choose a separate output directory outside the distributed input/reference folders.')
for name in ['08_fdr_comparison.py','13_table_s1_summary.py','10_cadastral_benchmarks.py','14_supplied_input_checks.py']:
    subprocess.run([sys.executable,str(root/'code'/name),'--output-dir',str(out)],check=True)
print('Completed supplied-input calculations only. Monthly MK/seasonal MK, population assignment and original spatial-lag estimation were not rerun.')
