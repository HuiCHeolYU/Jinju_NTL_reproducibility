Jinju nighttime light reproducibility package
v2 input-access update, 26 October 2026

Analyzing Declining Urban Activity Using Nighttime Light and Land-Use Change:
An Urban-Non-Urban Comparative Case Study
Repository: https://github.com/HuiCHeolYU/Jinju_NTL_reproducibility

1. Scope and preservation
This package preserves selected derived inputs and historical analytical records. Final standard-MK FDR values are provided in the current trend-result tables; their previous versions are retained in derived_data/historical/.
The grid-overlay workflow note has been clarified to distinguish regression-sample
selection from period-specific declining-grid classification.
It adds derived inputs, code and outputs for the analyses used in the v2
revision. Reported declining-grid counts, regression samples and results,
unadjusted standard-MK p-values, slopes and declining-grid membership are preserved. The former illustrative
grids 2829/2704 are replaced by the accepted grid 2144 illustration.
The revision scripts use retained derived data, raster clips and a locally prepared monthly input. They
do not rebuild the entire paper from raw satellite imagery or rerun the
original spatial lag estimation. Original scripts 01-06 are retained as
upstream workflow records and may require external raw files and GUI selection.

The regression sample comprises 2,422 grid cells (340 urban and 2,082 non-urban) with significant 2012–2024 NTL trends under the standard Mann–Kendall test (unadjusted p < 0.05), including both increasing and decreasing trends. Sample membership is recorded in derived_data/revision_inputs/regression_sample_membership.csv.

The unadjusted standard Mann–Kendall p-values, slopes, declining-grid membership, regression sample and regression results are unchanged. The seasonal Mann–Kendall analysis has been corrected to retain excluded months in their original calendar positions. The retained seasonal reference outputs report 413 declining grids for 2012–2019 and 62 for 2019–2024, with Jaccard indices of 0.861 and 0.775 against the unchanged standard declining-grid sets. The original all-grid seasonal results are retained as historical records. The two superseded seasonal summary/subset files are archived separately in the pre-cleanup ZIP and are not the results reported in the revised Supplementary Table S1.

Monthly input distribution
The derived grid-level monthly NTL CSV is not distributed. Download the original
VNP46A3 granules from NASA Earthdata Search (https://search.earthdata.nasa.gov/)
and prepare the input locally using code/00a, 00b and 00c. See
processing_notes/monthly_ntl_source_workflow.txt for the complete instructions,
required source settings, spatial inputs and verification scope.
The original product collection, band and spatial processing choices must be
confirmed before claiming exact reproduction of the reported results.
No generated monthly observations are embedded in this distribution.

Two superseded seasonal output CSVs remain excluded; their historical copies
are in the separately retained pre-cleanup ZIP. The original all-grid seasonal
input and existing result tables remain preserved.

2. Directory structure
  code/                  Input utilities 00a-00c, original 01-06 and revision 07-13
  derived_data/          Final standard-MK trend results and grids; monthly NTL input prepared locally
    historical/          Previous standard-MK result tables, retained unchanged
    revision_inputs/     Land-cover areas, fixed sample and cadastral source values
    spatial_inputs/      Grid 2144 raster clips/OSM reference and boundary data
  processing_notes/      Methods, sources, FDR explanation and validation
  supplementary_outputs/ Original diagnostic and spatial lag outputs
    revision/         Reference outputs corresponding to the v2 revision
  requirements-revision.txt
  requirements-input-preparation.txt

Historical notes may refer to supplementary_outputs/revision_v2/. In this
distribution the corresponding retained files are in supplementary_outputs/revision/.

All added tabular files are plain UTF-8 CSV, with one header row and no styles,
merged cells, macros or formulas. Identifiers and periods should be imported
as text. Missing entries in the added CSV files remain blank and must not be automatically converted to zero. During the original NTL processing, missing grid-level monthly radiance values within retained monthly files were replaced with zero before annual averaging and trend analysis. Entire excluded monthly files were not imputed; details are provided in processing_notes/qa_thresholds.txt.

3. Run the v2 additions
Use Python 3.12. From the extracted package directory:
  python -m pip install -r requirements-revision.txt
  python code/run_v2.py --monthly-ntl PATH_TO_PREPARED_MONTHLY_CSV
The default output is reproduced_results/; supplied reference results are
preserved. To choose another output directory:
  python code/run_v2.py --monthly-ntl PATH_TO_PREPARED_MONTHLY_CSV --output-dir path/to/rerun
Internet access and NASA Earthdata authentication are needed to obtain the original monthly granules. After local input preparation, revision analysis does not need network access.
Revision output paths resolve relative to the package or the explicit output directory. The monthly input path is supplied with --monthly-ntl. Original source grid geometry and confirmed preprocessing settings are required for input preparation; see the input workflow note.
Verify packaged result consistency and compare a completed rerun:
  python code/verify_package.py --results reproduced_results

For the corrected seasonal MK and overlap only (without main or regression analyses):
  pip install -r requirements-seasonal.txt
  python code/run_v2.py --seasonal-only --monthly-ntl PATH_TO_PREPARED_MONTHLY_CSV --output-dir reproduced_seasonal_results
  python code/verify_package.py --seasonal-results reproduced_seasonal_results
This separate environment profile records the versions used for the seasonal check.
The full v2 requirements remain available in requirements-revision.txt.

For final standard-MK FDR tables and the historical-value comparison only:
  python code/08_fdr_comparison.py --output-dir reproduced_fdr_results
  python code/verify_package.py --fdr-results reproduced_fdr_results
Code 08 defaults to reproduced_fdr_results/ and does not overwrite distributed
files. Other individual revision scripts may replace their generated reference
files when run without --output-dir. Prefer run_v2.py for routine use.

4. Manuscript and output mapping
All files listed below are under supplementary_outputs/revision/.

Comment 2, urban road-variable sensitivity in the Methods/Results:
  urban_340_fixed_sample.csv
  urban_road_sensitivity_coefficients.csv
  urban_road_sensitivity_model_fit.csv
The same 340 cells, stored response and HC3 t inference are used in both
models. Only road-area change is removed. These files replace earlier S4
filenames: the current v2 supplement contains S1-S3 and has no Table S4.

Comment 3, Figure 6 and Table 11, grid 2144:
  grid2144_selection.csv
  grid2144_landcover_original_analysis.csv
  grid2144_annual_ntl.csv
  table11_panel_A.csv / table11_panel_B.csv
  grid2144_case_area_table11.json
  Figure6_Grid2144.png
  grid2144_map_landcover_area.csv / grid2144_map_change.json
The case is deliberately selected for commercial expansion and a negative
full-period trend. It does not validate a regression coefficient. Table 11
Panel A reports the original regression input areas from
grid2144_landcover_original_analysis.csv. The commercial-business case areas
presented in the manuscript and Table 11 are 7,998 m2 in 2012 and 9,677 m2 in
2024, an increase of 1,679 m2. Figure 6 shows location and land-cover distribution.
grid2144_case_area_table11.json provides these reported commercial-business
case-area values with their Table 11 source and the Figure 6 illustration role.
The accepted Figure 6 PNG is preserved byte-for-byte. A new rendering can
have small layout or font-rendering differences across software versions;
its map classifications, area totals and feature locations use the same inputs.

Comment 4, Table 10 and Supplementary Table S3:
  ../spatial_lag_robustness_results.csv
  ../regression_diagnostic_tests.csv
These original files retain the spatial lag/diagnostic evidence. Table 10
is a condensed presentation of existing results; no new spatial model is
introduced by this package update.

Comment 5, Supplementary Table S1 (counts and spatial overlap):
  table_S1_summary.csv
  table_S1_panel_B_overlap.csv / standard_seasonal_membership.csv
  seasonal_mk_calendar_aligned_all_grids.csv
  seasonal_mk_calendar_aligned_declining_grids.csv
  seasonal_mk_calendar_aligned_summary.csv
  seasonal_mk_calendar_alignment_comparison.csv
  seasonal_mk_calendar_months.csv
The all-area rows give the corrected manuscript Jaccard/count results; the
area-specific rows use the same corrected membership. The filename containing
panel_B is retained for compatibility; S1 is a single table.
Code 12 retains the five excluded months as missing calendar positions and
preserves the original zero treatment for missing grid values in retained files.
It reads unchanged slopes and historical seasonal p/q values from
  derived_data/revision_inputs/seasonal_mk_original_all_grids_by_period.csv.
Original code 04 and the original all-grid seasonal input remain historical
records (348 and 58 declining grids), not current S1 outputs. The superseded
seasonal subset and summary CSVs are retained only in the separate pre-cleanup ZIP.
Original, baseline-reproduced and corrected seasonal p/q values are separate
columns. The standard-MK FDR comparison below is a distinct, preserved output.

In the historical seasonal_mk_summary.csv archived in the separate pre-cleanup ZIP, the 2019–2024 unadjusted_mk count of 223 matches the number of negative-slope grids regardless of significance. Applying the stated criterion of a negative Theil–Sen slope and an unadjusted Mann–Kendall p-value below 0.05 to the current packaged results yields 82 grids. The current comparison is provided in revision/table_S1_summary.csv.
Code 13 summarizes existing grid-level results without rerunning any trend
test or regression. For Table S1 only (standard Python library, no extra
dependencies):
  python code/13_table_s1_summary.py --output-dir reproduced_s1_results
  python code/verify_package.py --s1-results reproduced_s1_results

Comment 7, Figure 5 comparison with land-cover expansion:
  expansion_decline_membership.csv
  expansion_decline_comparison.csv / expansion_category_counts.csv
The main comparison uses all 2693 non-urban grids and original period flags.
The no_recorded_nodata cohort is retained supporting detail, not a replacement
for the manuscript population. Percentages describe co-occurrence, not causation.

Comment 11, Innovation City clarification:
  innovation_city_grid_details.csv / innovation_city_trend_summary.csv
The supplied 2023 Chungmugong-dong administrative boundary and centroid rule
select 17 grids. It has not been verified as the legal project boundary.

Comment 12, parcel-size scale benchmarks and reference [33]:
  jinju_parcel_size_benchmarks.csv
Original official source values, cell references and download URL are included.
Comments introducing only wording or literature do not require new data files.

FDR transparency:
  fdr_original_vs_recomputed.csv
  fdr_comparison_summary.csv / fdr_comparison_summary.json
Discrepancies in the stored standard Mann–Kendall FDR-adjusted p-values were corrected by applying the Benjamini–Hochberg procedure to the existing unadjusted p-values separately for each analytical period. The declining-grid sets (378 and 80 cells) and regression results remain unchanged.
The fdr_pvalue columns in the two current derived_data/ trend-result tables
contain the final BH values across all 3,052 grids per period. Previous tables
are retained unchanged in derived_data/historical/. The comparison file retains
original values and the adopted fdr_pvalue_recomputed_BH values. See
processing_notes/fdr_comparison_notes.txt for the correction record.

5. Sources, limitations and verification
revision_methods.txt defines samples, denominators, units and spatial handling.
revision_data_dictionary.txt explains fields and missing values.
revision_input_provenance.json records preserved inputs and source hashes.
cadastral_source.json records the official statistical source and extraction.
revision_validation.json distinguishes historical execution records from the current input-utility software checks. Current study-wide raw-data reproduction has not been performed.
A checksum manifest is not distributed. The verifier explicitly reports checksum
verification as not performed when the manifest is absent; result-consistency
checks remain enabled.
The raw VIIRS Black Marble VNP46A3 product is available from NASA Earthdata,
and original detailed land-cover maps from Korea's Ministry of Environment
Environmental Spatial Information Service. Citywide raw source products are
not included. The small Figure 6 raster clips retain their supplied values.
Current OSM snapshot: copyright OpenStreetMap contributors, accessed 23 October
2026. OSM data are available under ODbL; see https://www.openstreetmap.org/copyright.
Current features are orientation references, not historical or cadastral evidence.
The original 500 m SHP/PRJ is unavailable; the adopted reconstruction and CRS
are documented without presenting them as recovered original metadata.

This is a local prepared release. Creating this ZIP does not upload it to GitHub.
