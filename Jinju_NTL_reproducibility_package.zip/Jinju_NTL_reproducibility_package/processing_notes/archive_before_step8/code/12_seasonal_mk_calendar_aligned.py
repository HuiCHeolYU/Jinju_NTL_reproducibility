"""Reproduce the corrected seasonal MK test, retaining omitted calendar months.
Original slopes and standard decline flags are read without re-estimation.
Original seasonal p/q values are retained separately for transparent comparison.
"""
from pathlib import Path
import argparse,json,sys
import numpy as np
import pandas as pd
from scipy import stats
import pymannkendall as mk
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path)
parser.add_argument('--monthly-ntl',type=Path,help='Locally prepared monthly input CSV')
args=parser.parse_args()
P=Path(__file__).resolve().parents[1]
OLD=P/'derived_data/revision_inputs/seasonal_mk_original_all_grids_by_period.csv'
OUTPUT=args.output_dir.resolve() if args.output_dir else P/'reproduced_seasonal_results'
OUTPUT.mkdir(parents=True,exist_ok=True)
monthly_path=args.monthly_ntl.resolve() if args.monthly_ntl else P/'derived_data/grid_monthly_ntl_2012_2024.csv'
if not monthly_path.is_file():
 parser.error('Monthly input is not distributed. See processing_notes/monthly_ntl_source_workflow.txt and pass --monthly-ntl.')
monthly=pd.read_csv(monthly_path,float_precision='round_trip')
assert not monthly.duplicated(['grid_id','date']).any()
monthly['date']=pd.to_datetime(monthly['date'],format='%Y-%m')
assert (monthly['year']==monthly['date'].dt.year).all() and (monthly['month']==monthly['date'].dt.month).all()
ids=np.array(sorted(monthly.grid_id.unique()))
assert len(ids)==3052
assert (monthly.groupby('grid_id').size()==151).all()
assert (monthly.groupby('date').size()==3052).all()
raw_blank_count=int(monthly['ntl_mean'].isna().sum())
monthly['processed_ntl']=monthly['ntl_mean'].fillna(0.0)
wide=monthly.pivot(index='grid_id',columns='date',values='processed_ntl').reindex(ids).sort_index(axis=1)
assert not wide.isna().any().any()
calendar=pd.date_range('2012-01-01','2024-12-01',freq='MS')
missing=calendar.difference(wide.columns)
assert list(missing.strftime('%Y-%m'))==['2012-06','2015-06','2020-07','2020-09','2022-08']
old=pd.read_csv(OLD,float_precision='round_trip');old['period']=old['period'].str.replace('_','-')
assert not old.duplicated(['id','period']).any() and len(old)==6104
standard=pd.read_csv(P/'derived_data/grid_ntl_trend_results_by_period.csv',float_precision='round_trip')

def bh(p):
 assert np.isfinite(p).all()
 order=np.argsort(p);ordered=p[order];n=len(p)
 adj=np.minimum.accumulate((ordered*n/np.arange(1,n+1))[::-1])[::-1]
 out=np.empty_like(adj);out[order]=np.minimum(adj,1.0)
 assert np.allclose(out,stats.false_discovery_control(p,method='bh'),rtol=1e-13,atol=1e-15)
 return out

def independent_test(y):
 # Each column is one real calendar month, missing months skipped within its column.
 mat=y.reshape((-1,12));S=0.;var=0.
 for j in range(12):
  x=mat[:,j];x=x[np.isfinite(x)];n=len(x)
  upper=np.triu_indices(n,k=1)
  S+=np.sign(x[None,:]-x[:,None])[upper].sum()
  _,counts=np.unique(x,return_counts=True)
  var+=(n*(n-1)*(2*n+5)-np.sum(counts*(counts-1)*(2*counts+5)))/18
 z=(S-np.sign(S))/np.sqrt(var) if S!=0 else 0.
 pv=2*(1-stats.norm.cdf(abs(z)))
 return S,var,z,pv

rows=[];summaries=[];calendar_rows=[];validation={}
for period,start,end in [('2012-2019','2012-01-01','2019-12-01'),('2019-2024','2019-01-01','2024-12-01')]:
 full_dates=pd.date_range(start,end,freq='MS')
 retained=wide.loc[:,(wide.columns>=start)&(wide.columns<=end)]
 aligned=retained.reindex(columns=full_dates)
 assert aligned.columns.equals(full_dates)
 assert aligned.isna().sum(axis=1).nunique()==1
 vals=aligned.to_numpy();compressed=retained.to_numpy()
 assert np.array_equal(vals[:,~aligned.isna().all(axis=0)],compressed)
 o=old[old.period==period].set_index('id').reindex(ids)
 std=standard[standard.period==period].set_index('grid_id').reindex(ids)
 m=std.rename(columns={'declining_ntl_activity':'standard_declining'})
 assert not o['theilsen_slope'].isna().any()
 assert np.array_equal(m.standard_declining.to_numpy(),std.declining_ntl_activity.to_numpy())
 oldflag=o['declining_seasonal_fdr'].astype(str).str.lower().eq('true').to_numpy()
 baseline=[];corrected=[];manual_max=np.zeros(4)
 print(f'Running {period}: {len(ids)} grids; {compressed.shape[1]} observed monthly files; {vals.shape[1]} calendar positions',flush=True)
 for k,gid in enumerate(ids):
  b=mk.seasonal_test(compressed[k],period=12)
  c=mk.seasonal_test(vals[k],period=12)
  baseline.append([b.p,b.z,b.s,b.var_s])
  corrected.append([c.p,c.z,c.s,c.var_s])
  manual=np.array(independent_test(vals[k]))
  manual_max=np.maximum(manual_max,np.abs(manual-np.array([c.s,c.var_s,c.z,c.p])))
  if (k+1)%1000==0:print(f'  {k+1}/{len(ids)} checked',flush=True)
 b=np.array(baseline);c=np.array(corrected)
 bq=bh(b[:,0]);cq=bh(c[:,0]);slope=o['theilsen_slope'].to_numpy()
 bf=(slope<0)&(bq<.05);cf=(slope<0)&(cq<.05);sf=m.standard_declining.to_numpy().astype(bool)
 err={'baseline_count':int(bf.sum()),'stored_count':int(oldflag.sum()),'baseline_flag_disagreement':int((bf!=oldflag).sum()),'baseline_max_abs_p_vs_stored':float(np.max(np.abs(b[:,0]-o.seasonal_pvalue.to_numpy()))),'baseline_max_abs_q_vs_stored':float(np.max(np.abs(bq-o.seasonal_fdr_pvalue.to_numpy()))),'baseline_max_abs_S_vs_stored':float(np.max(np.abs(b[:,2]-o.seasonal_s.to_numpy()))),'baseline_max_abs_variance_vs_stored':float(np.max(np.abs(b[:,3]-o.seasonal_var_s.to_numpy()))),'corrected_independent_max_abs_S_var_z_p':manual_max.tolist()}
 validation[period]=err
 print('VALIDATION',period,json.dumps(err),flush=True)
 assert np.array_equal(bf,oldflag),'Original classification not reproduced; investigate inputs before drawing conclusions.'
 assert np.allclose(b[:,0],o.seasonal_pvalue.to_numpy(),rtol=1e-6,atol=5e-9),'Original raw p-values differ beyond serialization tolerance.'
 assert manual_max[0]==0 and manual_max[1]<1e-9 and manual_max[2]<1e-10 and manual_max[3]<1e-10
 old_inter=int((sf&oldflag).sum());old_union=int((sf|oldflag).sum())
 new_inter=int((sf&cf).sum());new_union=int((sf|cf).sum())
 summaries.append({'period':period,'total_grids':len(ids),'standard_declining_n_preserved':int(sf.sum()),'seasonal_declining_n_original':int(oldflag.sum()),'seasonal_declining_n_calendar_aligned':int(cf.sum()),'seasonal_count_change':int(cf.sum()-oldflag.sum()),'seasonal_count_change_pct':100*(cf.sum()-oldflag.sum())/oldflag.sum(),'intersection_original':old_inter,'union_original':old_union,'jaccard_original':old_inter/old_union,'intersection_calendar_aligned':new_inter,'union_calendar_aligned':new_union,'jaccard_calendar_aligned':new_inter/new_union,'jaccard_change':new_inter/new_union-old_inter/old_union,'jaccard_change_percentage_points':100*(new_inter/new_union-old_inter/old_union),'seasonal_retained_n':int((oldflag&cf).sum()),'seasonal_removed_n':int((oldflag&~cf).sum()),'seasonal_added_n':int((~oldflag&cf).sum()),'observed_monthly_files':compressed.shape[1],'calendar_positions':vals.shape[1],'excluded_months':','.join(aligned.columns[aligned.isna().all(axis=0)].strftime('%Y-%m'))})
 for k,gid in enumerate(ids):
  rows.append({'grid_id':int(gid),'period':period,'area_type':m.area_type.iloc[k],'theilsen_slope_preserved':float(slope[k]),'standard_declining_preserved':int(sf[k]),'seasonal_declining_original':int(oldflag[k]),'seasonal_declining_baseline_reproduced':int(bf[k]),'seasonal_declining_calendar_aligned':int(cf[k]),'change_status':'added' if cf[k] and not oldflag[k] else 'removed' if oldflag[k] and not cf[k] else 'retained_declining' if cf[k] else 'retained_nondeclining','seasonal_p_original':float(o.seasonal_pvalue.iloc[k]),'seasonal_q_original':float(o.seasonal_fdr_pvalue.iloc[k]),'seasonal_p_baseline_reproduced':float(b[k,0]),'seasonal_q_baseline_reproduced':float(bq[k]),'seasonal_p_calendar_aligned':float(c[k,0]),'seasonal_q_calendar_aligned':float(cq[k]),'seasonal_S_calendar_aligned':float(c[k,2]),'seasonal_varS_calendar_aligned':float(c[k,3]),'seasonal_z_calendar_aligned':float(c[k,1])})
 for d in full_dates:calendar_rows.append({'period':period,'calendar_month':d.strftime('%Y-%m'),'retained_monthly_file':int(d in retained.columns),'treatment':'original_monthly_values_with_original_grid_NaN_to_zero' if d in retained.columns else 'NaN_placeholder_no_imputation'})
 print('SUMMARY',json.dumps(summaries[-1]),flush=True)

results=pd.DataFrame(rows);summary=pd.DataFrame(summaries)
def save(frame,name):
 frame.to_csv(OUTPUT/name,index=False,encoding='utf-8-sig',float_format='%.17g')
save(results,'seasonal_mk_calendar_aligned_all_grids.csv')
declining=results.loc[results.seasonal_declining_calendar_aligned==1,['grid_id','period','area_type','theilsen_slope_preserved','seasonal_p_calendar_aligned','seasonal_q_calendar_aligned']].rename(columns={'grid_id':'id','theilsen_slope_preserved':'theilsen_slope','seasonal_p_calendar_aligned':'seasonal_pvalue','seasonal_q_calendar_aligned':'seasonal_fdr_pvalue'})
declining['declining_seasonal_fdr']=True
save(declining,'seasonal_mk_calendar_aligned_declining_grids.csv')
current=summary[['period','total_grids','standard_declining_n_preserved','seasonal_declining_n_calendar_aligned','intersection_calendar_aligned','union_calendar_aligned','jaccard_calendar_aligned','observed_monthly_files','calendar_positions','excluded_months']].copy()
save(current,'seasonal_mk_calendar_aligned_summary.csv')
save(summary,'seasonal_mk_calendar_alignment_comparison.csv')
save(pd.DataFrame(calendar_rows),'seasonal_mk_calendar_months.csv')
(OUTPUT/'seasonal_reproduction_validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
print('Completed corrected seasonal MK outputs: '+str(OUTPUT))
