Jinju nighttime light reproducibility package
Editorially corrected submission package, 10 November 2026

1. What this version establishes
This local package accompanies the cumulative revised manuscript, response,
Supplementary Tables S1-S4 and declaration. It preserves the previously distributed analytical inputs and tabulated outputs
byte-for-byte. Figure 6 arrow placement is corrected as described in Section 8. The 3,052 study grids, standard
declining sets (378/80), supplied seasonal declining sets (413/62), baseline
regression sample (2,422, including both trend directions), and stored spatial
lag outputs are retained. The citywide Table 8 constant is 0.0097 at the
manuscript's precision; its recalculated baseline value is recorded in
staged_revision/nodata_ols_coefficients.csv.

The present run starts from supplied derived inputs. It does NOT reconstruct
monthly observations from satellite products, rerun monthly MK/seasonal MK,
reproduce SGIS population allocation, recover the original CRS/weights, or
re-estimate the original spatial-lag models. Checksum agreement proves file
integrity, not the correctness of every scientific claim.

2. Directory structure
code/                     Historical/upstream scripts, v2 scripts and supplied-input checks
  provided_scripts_20261028/ Four additional supplied helper copies, unchanged
derived_data/             Retained trends, grids, land-cover and sample inputs
  historical/             Previous standard-FDR records, unchanged
  revision_inputs/        Land-cover CSVs, recorded regression membership, cadastral extract
  spatial_inputs/         Case 2144 raster clips/OSM and administrative boundary
supplementary_outputs/    Original diagnostic/spatial-lag outputs
  revision/               Retained v2 reference results and accepted Figure 6
  staged_revision/        Newly executed supplied-input checks, including Table S4
processing_notes/         Methods, input limits, crosswalk and execution record
  archive_before_step8/   Exact pre-update README, methods note and scripts 07/12
SHA256SUMS.txt             SHA-256 manifest for all other package files

3. Recommended execution using supplied inputs only
Python 3.12 was used. Package versions tested in the current run are recorded
in processing_notes/step8_environment.json and requirements-supplied-inputs.txt.
From the extracted package directory:
  python -m pip install -r requirements-supplied-inputs.txt
  python code/run_supplied_inputs.py --output-dir reproduced_supplied_inputs
  python code/15_verify_supplied_inputs.py --results reproduced_supplied_inputs

The runner invokes:
08: BH correction of STORED unadjusted p-values, with retained historical comparison;
13: Table S1 citywide counts from STORED standard and seasonal results;
10: cadastral arithmetic from the supplied extracted values;
14: OLS/HC3, recorded-NoData exclusion, road exclusion, regional overlap,
    case-area checks, expansion counts, and the recorded 17-grid selection.
No source observations or p-values are invented. New outputs are written to
a separate directory; reference inputs/results are protected by the runner.

4. What still requires unavailable input
Monthly NTL CSV is not distributed. run_v2.py and scripts 07/12 explain the
missing input before trying to run the monthly-dependent analysis. Script 07
with --seasonal-only summarizes stored records; it does not refit seasonal MK.
The complete v2 workflow requires a locally prepared input:
  python code/run_v2.py --monthly-ntl PATH_TO_PREPARED_MONTHLY_CSV --output-dir reproduced_v2
Its dependencies remain in requirements-revision.txt / requirements-seasonal.txt.
Scripts 00a-00c and monthly_ntl_source_workflow.txt describe preparation options,
but the original collection, exact band/scale, P95 domain, grid geometry/CRS,
aggregation settings and exclusion decisions still need confirmation for an
exact reproduction claim. No NASA download or authentication was performed.
Original scripts 01-06 are upstream workflow records, not a tested single-command
reproduction route for this distribution. Do not run them expecting all raw inputs.

The seasonal reference counts are retained historical results. Current checks
verify stored classification/overlap consistency, not seasonal p-values from
monthly observations. Within-retained-file missing grid radiance was documented
as zero-filled; five whole monthly files were excluded. Neither seasonal MK nor
BH alone corrects serial dependence. The periods use 94/69 retained months and
share 2019; equal-length/non-overlapping tests were not run.

SGIS original data, final grid-population values and allocation/crosswalk code
are absent. Tables 4-5 are reported comparisons, not independently reproduced
population assignment or classification accuracy. Original spatial weights
and complete spatial-lag estimation code are absent. Stored coefficients are
not decomposed direct/indirect effects; HC3 is not a spatial correction.

5. Manuscript / response mapping
Comment 1 / Tables 4-5: population comparisons retained, linkage unverified.
Comment 2 / Table 8: urban road sensitivity in revision/ and rechecked in
  staged_revision/urban_road_coefficients_checked.csv and urban_road_fit_checked.csv.
Comments 3 / Figure 6 / Table 11: revision/grid2144_* and table11_panel_A/B.csv.
  Table 11 commercial area change is +1,679 m2; map clips yield +1,607 m2.
  The source of the 72 m2 discrepancy is unresolved. The PNG arrow placement is corrected; quantitative input files are unchanged. Current OSM features are context,
  not verified construction history or parcel attribution. The original
  facility-completion assertion is archived, not used as current evidence.
Comment 4 / Table 10 / S3: spatial_lag_robustness_results.csv and diagnostics,
  retained only; original spatial-lag estimation was not rerun.
Comment 5 / Table S1: revision/table_S1_summary.csv is Panel A;
  staged_revision/regional_overlap_checked.csv supports Panel B.
  Later urban overlap is 2 of 6 standard grids (Jaccard 0.333), despite the
  citywide Jaccard of 0.775. Regional subsets use citywide FDR adjustment.
Comments 6-7 / Tables 6-7: seven-category totals and signed contributions;
  expansion counts are rechecked in staged_revision/expansion_counts_checked.csv.
Table S4 and Sections 3.2/4.5/5.5: staged_revision/nodata_* files.
  392 non-urban grids have recorded NoData in either year, including 278
  baseline regression members. Exclusion samples are 2,144 citywide and 1,804
  non-urban; the urban sample remains 340. Urban encoded NoData=0 does not prove
  complete raster coverage. This changes the sample and does not identify a
  causal missing-data effect or validate a common spatial mask.
Comment 8: descriptive temporal interpretation; no new event-study data.
Comment 9: this README and processing_notes/stage8_execution_record.json.
Comment 10: cross-sectional population correlations and trend OLS have different meanings.
Comment 11: stored selection checked in staged_revision/innovation_stored_selection_checked.csv.
  Chungmugong-dong is an administrative proxy; adopted EPSG:32652 is not
  recovered original CRS metadata. Legal project boundaries were not verified.
Comment 12 / reference [33]: revision/jinju_parcel_size_benchmarks.csv and
  derived_data/revision_inputs/jinju_cadastral_2024_source_values.csv.
  Arithmetic is checked; the original official statistical workbook is absent.
Comments 13-14: manuscript wording and retained literature references.
processing_notes/reviewer_response_crosswalk.json connects all 14 comments
to the current manuscript passages. Other background-source uncertainties
remain as documented in the staged revision records.

6. Preservation and public release status
Existing numerical data/results are unchanged. Figure 6 arrow placement is corrected as described in Section 8. Historical execution claims
in preserved metadata refer to earlier work, not to the current limited run.
Use revision_methods.txt and stage8_execution_record.json for current scope.
SHA256SUMS.txt covers all package files except itself. verify_package.py checks
the manifest and retained FDR/S1 consistency; 15_verify_supplied_inputs.py also
compares the supplied-input rerun with the staged reference CSVs.
The public repository URL recorded in the manuscript is
https://github.com/HuiCHeolYU/Jinju_NTL_reproducibility.
This local update has not been uploaded, and its identity with the public
release has not been checked. This is not a finding that the repository is
inaccessible. Public-release verification is a separate remaining step.

Current OSM snapshot: copyright OpenStreetMap contributors, recorded access
23 October 2026, ODbL (https://www.openstreetmap.org/copyright).


7. Official sources and code delivery update
See processing_notes/data_sources_and_code_guide.txt for official NASA, EGIS
and SGIS download/application routes, required input identifiers and code
execution boundaries. processing_notes/source_code_inventory.json maps the
nine relevant supplied scripts: five are identical to existing package code
and four are added as unmodified helper copies. The added helpers have been
statically inspected; this update did not execute them on original inputs.

The supplied 1.py is identical to code/04_seasonal_mk_robustness_check.py. Its
actual use in producing the final results could not be confirmed. Code 04 does
not restore excluded calendar months. Code 12 provides calendar alignment
when the required monthly input is available; do not direct readers to Code 04
alone for the current S1 workflow. No monthly test was rerun in this update.

Except for the annotation-only Figure 6 script/PNG changes in Section 8, earlier scripts, data and tabulated analysis outputs remain byte-identical, including
Tables 4-5 population records and Table 10/S3 spatial-lag outputs. The added
source guide does not convert missing inputs into verified observations.
Additional retained study materials may be requested from the corresponding
author, subject to availability and source-provider access conditions.

The preceding README and checksum manifest are preserved under
processing_notes/archive_before_source_code_update/. The root SHA256SUMS.txt
now covers the complete updated package except itself. The public repository
has not been updated as part of this local operation.


8. Editorial corrections, 10 November 2026
This submission update corrects Figure 1(b)'s duplicate legend label in the
manuscript and Figure 6's A/B arrow tips. Code 11 now selects actual interior
pixels of the same connected gain patches and uses zero tip shrinkage for A/B.
Stored patch centroids, raster classifications, areas, all existing CSV/JSON
analytical values, and statistical results are unchanged. Only the corrected
Figure 6 PNG replaces the earlier figure asset.

The citywide discussion in Section 4.5 refers to mapped land-cover area
associations without inferring residential densification or facility use.
The reviewer response describes these editorial corrections.
No monthly trend tests, population allocation, regression models or spatial-lag
models were re-estimated. Existing limitations, including the unresolved
P95 boundary convention and the 72 m2 case-area difference, remain disclosed.

processing_notes/editorial_corrections_20261110.json records scope and preservation.
requirements-figure-editorial.txt records the isolated figure-rendering versions.
These versions concern this annotation render only, not the original statistical
analysis environment. No public repository upload was performed by this update.
