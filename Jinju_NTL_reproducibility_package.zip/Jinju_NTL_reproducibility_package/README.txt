Jinju NTL and land-cover reproducibility package
11 November 2026 common-pixel reanalysis v7

This release replaces earlier land-cover areas, OLS/spatial-lag models, road sensitivity and case areas using the adopted TIFFs. Original NTL results, population summaries and regression membership are retained. Older land-cover checks and whole-grid NoData exclusions are superseded.

Directories
code/: upstream NTL preparation, pixel reaggregation, current model estimation, figures and verification.
derived_data/: current class areas, membership, NTL results, coordinates, boundary, case clips and figure assets.
processing_notes/: source checksums, methods and provenance.
supplementary_outputs/reanalysis_v7/: current model/table outputs and spatial weights.
supplementary_outputs/retained_ntl/: unchanged seasonal, Innovation City, cadastral and annual case records.

Python 3.12 was used. Install requirements.txt in a separate environment.

Verify the distribution (standard library only):
python code/verify_package.py

Reproduce models and tables from included derived data:
python code/02_reestimate_landcover_models.py --output-dir reproduced/models
python code/verify_package.py --reproduced reproduced/models

This re-estimates OLS/HC3, VIF, Koenker-BP, spatial lag maximum likelihood, Moran tests, road sensitivity, Tables 6-7 and expansion overlap. All 2422 original regression members remain. Small solver tolerances are allowed. The SAR likelihood is also independently optimized.

Reproduce Figures 1 and 6:
python code/03_figure6.py --output-dir reproduced/figures
python code/04_figure1.py --output-dir reproduced/figures

Full pixel reaggregation additionally requires the large author-retained TIFFs identified in processing_notes/source_manifest.json:
python code/01_reaggregate_landcover.py --raster-2012 "PATH/2012_세분류토지피복도_진주시.tif" --raster-2024 "PATH/2024_세분류토지피복도_진주시.tif" --output-dir reproduced/landcover

The TIFFs are not embedded in this ZIP. Their hashes identify the adopted inputs and are checked after aggregation. Access may be requested from the corresponding author, subject to source-provider conditions. Both years use identical within-city common valid pixels; grid cells are retained.

Manuscript mappings (supplementary_outputs/reanalysis_v7/)
Tables 6-7: landcover_tables6_7.csv.
Table 8: ols_coefficients.csv, ols_diagnostics.csv.
Table 9/S2: ols_diagnostics.csv, vif.csv, weights_*.csv.
Table 10/S3: spatial_lag_coefficients.csv, spatial_lag_diagnostics.csv and OLS files.
S4: urban_road_coefficients.csv, urban_road_diagnostics.csv.
Table 11/Figure 6: case_selection.json, grid2144_map_change.json.
Expansion comparison: nonurban_expansion_overlap.csv.
S1 and unchanged NTL summaries: supplementary_outputs/retained_ntl/.

Limits
Monthly NTL observations and SGIS allocation records are absent and were not reconstructed. Stored NTL/population results and upstream scripts do not establish full independent raw-data reproduction. The original grid PRJ is not retained; the adopted reconstruction is documented. Associations do not establish causality or facility use. Spatial lag parameters are not decomposed impacts; residual spatial dependence remains.
